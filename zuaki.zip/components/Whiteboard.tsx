import React, { useRef, useState, useEffect, useCallback } from 'react';
import { Eraser, Pen, Download, Trash2, Square, Circle as CircleIcon, Minus, Type, Layers, Plus, Eye, EyeOff, Highlighter, X, MousePointer2 } from 'lucide-react';

type Tool = 'pen' | 'eraser' | 'rect' | 'circle' | 'line' | 'text';
type BrushType = 'marker' | 'highlighter';

interface Layer {
  id: string;
  name: string;
  visible: boolean;
}

interface Point {
  x: number;
  y: number;
}

export const Whiteboard: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const layerRefs = useRef<{ [key: string]: HTMLCanvasElement | null }>({});
  const previewCanvasRef = useRef<HTMLCanvasElement>(null);

  // State
  const [layers, setLayers] = useState<Layer[]>([
    { id: 'layer-1', name: 'Background', visible: true }
  ]);
  const [activeLayerId, setActiveLayerId] = useState<string>('layer-1');
  const [showLayersPanel, setShowLayersPanel] = useState(false);
  
  const [tool, setTool] = useState<Tool>('pen');
  const [brushType, setBrushType] = useState<BrushType>('marker');
  const [color, setColor] = useState('#00f3ff');
  const [lineWidth, setLineWidth] = useState(3);
  
  const [isDrawing, setIsDrawing] = useState(false);
  const [startPoint, setStartPoint] = useState<Point | null>(null);

  // Text Input State
  const [textInput, setTextInput] = useState<{ x: number; y: number; text: string; visible: boolean }>({ 
    x: 0, y: 0, text: '', visible: false 
  });

  // Canvas Sizing
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

  // Initialize and Handle Resize
  const updateDimensions = useCallback(() => {
    if (!containerRef.current) return;
    const { clientWidth, clientHeight } = containerRef.current;
    
    // Store current content
    const snapshots: { [key: string]: HTMLCanvasElement } = {};
    layers.forEach(layer => {
        const canvas = layerRefs.current[layer.id];
        if (canvas && canvas.width > 0) {
            const temp = document.createElement('canvas');
            temp.width = canvas.width;
            temp.height = canvas.height;
            const tCtx = temp.getContext('2d');
            tCtx?.drawImage(canvas, 0, 0);
            snapshots[layer.id] = temp;
        }
    });

    setDimensions({ width: clientWidth, height: clientHeight });

    // Restore content after React updates DOM (use setTimeout to wait for render)
    setTimeout(() => {
        layers.forEach(layer => {
            const canvas = layerRefs.current[layer.id];
            const snapshot = snapshots[layer.id];
            if (canvas && snapshot) {
                const ctx = canvas.getContext('2d');
                ctx?.drawImage(snapshot, 0, 0);
            }
        });
        // Also ensure preview canvas is sized
        if (previewCanvasRef.current) {
            previewCanvasRef.current.width = clientWidth;
            previewCanvasRef.current.height = clientHeight;
        }
    }, 0);
  }, [layers]);

  useEffect(() => {
    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    return () => window.removeEventListener('resize', updateDimensions);
  }, []);

  // Helpers
  const getActiveCtx = () => layerRefs.current[activeLayerId]?.getContext('2d');
  const getPreviewCtx = () => previewCanvasRef.current?.getContext('2d');

  // Drawing Handlers
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (textInput.visible) {
        commitText(); // Commit previous text if clicking elsewhere
        return;
    }

    if (tool === 'text') {
        const rect = previewCanvasRef.current!.getBoundingClientRect();
        setTextInput({ 
            x: e.clientX - rect.left, 
            y: e.clientY - rect.top, 
            text: '', 
            visible: true 
        });
        return;
    }

    setIsDrawing(true);
    const rect = previewCanvasRef.current!.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    setStartPoint({ x, y });

    if (tool === 'pen' || tool === 'eraser') {
        const ctx = getActiveCtx();
        if (!ctx) return;
        ctx.beginPath();
        ctx.moveTo(x, y);
        
        // Brush Styles
        ctx.lineCap = brushType === 'highlighter' ? 'square' : 'round';
        ctx.lineJoin = 'round';
        ctx.strokeStyle = tool === 'eraser' ? 'rgba(0,0,0,1)' : color;
        ctx.lineWidth = brushType === 'highlighter' ? lineWidth * 4 : lineWidth;
        
        if (tool === 'eraser') {
            ctx.globalCompositeOperation = 'destination-out';
            ctx.globalAlpha = 1;
        } else {
            ctx.globalCompositeOperation = brushType === 'highlighter' ? 'screen' : 'source-over';
            ctx.globalAlpha = brushType === 'highlighter' ? 0.5 : 1;
        }
    }
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !startPoint) return;
    const rect = previewCanvasRef.current!.getBoundingClientRect();
    const currentX = e.clientX - rect.left;
    const currentY = e.clientY - rect.top;

    if (tool === 'pen' || tool === 'eraser') {
        const ctx = getActiveCtx();
        if (!ctx) return;
        ctx.lineTo(currentX, currentY);
        ctx.stroke();
    } else {
        // Shape Preview
        const ctx = getPreviewCtx();
        if (!ctx) return;
        
        ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
        ctx.beginPath();
        ctx.strokeStyle = color;
        ctx.lineWidth = lineWidth;
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        ctx.globalAlpha = 1;

        if (tool === 'line') {
            ctx.moveTo(startPoint.x, startPoint.y);
            ctx.lineTo(currentX, currentY);
        } else if (tool === 'rect') {
            ctx.strokeRect(startPoint.x, startPoint.y, currentX - startPoint.x, currentY - startPoint.y);
        } else if (tool === 'circle') {
            const radius = Math.sqrt(Math.pow(currentX - startPoint.x, 2) + Math.pow(currentY - startPoint.y, 2));
            ctx.arc(startPoint.x, startPoint.y, radius, 0, 2 * Math.PI);
        }
        
        if (tool !== 'rect') ctx.stroke();
    }
  };

  const stopDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    setIsDrawing(false);

    if (tool !== 'pen' && tool !== 'eraser' && startPoint) {
        // Commit shape
        const rect = previewCanvasRef.current!.getBoundingClientRect();
        const currentX = e.clientX - rect.left;
        const currentY = e.clientY - rect.top;

        const activeCtx = getActiveCtx();
        const previewCtx = getPreviewCtx();
        if (!activeCtx || !previewCtx) return;

        activeCtx.strokeStyle = color;
        activeCtx.lineWidth = lineWidth;
        activeCtx.lineCap = 'round';
        activeCtx.lineJoin = 'round';
        activeCtx.globalCompositeOperation = 'source-over';
        activeCtx.globalAlpha = 1;

        activeCtx.beginPath();
        if (tool === 'line') {
            activeCtx.moveTo(startPoint.x, startPoint.y);
            activeCtx.lineTo(currentX, currentY);
        } else if (tool === 'rect') {
            activeCtx.strokeRect(startPoint.x, startPoint.y, currentX - startPoint.x, currentY - startPoint.y);
        } else if (tool === 'circle') {
            const radius = Math.sqrt(Math.pow(currentX - startPoint.x, 2) + Math.pow(currentY - startPoint.y, 2));
            activeCtx.arc(startPoint.x, startPoint.y, radius, 0, 2 * Math.PI);
        }
        if (tool !== 'rect') activeCtx.stroke();

        previewCtx.clearRect(0, 0, previewCtx.canvas.width, previewCtx.canvas.height);
    }
    setStartPoint(null);
  };

  // Text Handling
  const commitText = () => {
    if (textInput.text.trim()) {
        const ctx = getActiveCtx();
        if (ctx) {
            ctx.font = `bold ${lineWidth * 4 + 12}px 'Rajdhani'`;
            ctx.fillStyle = color;
            ctx.textBaseline = 'top';
            ctx.fillText(textInput.text, textInput.x, textInput.y);
        }
    }
    setTextInput({ ...textInput, visible: false, text: '' });
  };

  // Layer Management
  const addLayer = () => {
      const newId = `layer-${Date.now()}`;
      setLayers([...layers, { id: newId, name: `Layer ${layers.length + 1}`, visible: true }]);
      setActiveLayerId(newId);
  };

  const toggleLayer = (id: string) => {
      setLayers(layers.map(l => l.id === id ? { ...l, visible: !l.visible } : l));
  };

  const deleteLayer = (id: string) => {
      if (layers.length <= 1) return;
      const newLayers = layers.filter(l => l.id !== id);
      setLayers(newLayers);
      if (activeLayerId === id) setActiveLayerId(newLayers[newLayers.length - 1].id);
  };

  const clearCanvas = () => {
      const ctx = getActiveCtx();
      ctx?.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  };

  return (
    <div className="flex flex-col h-full w-full gap-4 p-4 relative">
      {/* Top Toolbar */}
      <div className="h-16 rounded-2xl glass-panel neon-border-purple flex items-center justify-between px-4 sm:px-6 relative z-30 shrink-0">
        <div className="flex items-center gap-2 sm:gap-4 overflow-x-auto no-scrollbar">
            <h2 className="text-white font-display font-bold tracking-widest uppercase text-lg hidden sm:block">HOLO_BOARD</h2>
            
            {/* Tools Group */}
            <div className="flex items-center bg-black/40 rounded-lg p-1 border border-white/10">
                {[
                    { id: 'pen', icon: Pen, type: 'tool' },
                    { id: 'highlighter', icon: Highlighter, type: 'brush' },
                    { id: 'eraser', icon: Eraser, type: 'tool' },
                ].map((item) => (
                    <button 
                        key={item.id}
                        onClick={() => {
                            if (item.type === 'brush') {
                                setTool('pen');
                                setBrushType('highlighter');
                            } else {
                                setTool(item.id as Tool);
                                setBrushType('marker');
                            }
                        }}
                        className={`p-2 rounded-md transition-all ${
                            (tool === item.id && brushType === 'marker') || (item.id === 'highlighter' && brushType === 'highlighter')
                            ? 'bg-cyber-purple text-white shadow-[0_0_10px_#9d00ff]' 
                            : 'text-slate-400 hover:text-white hover:bg-white/5'
                        }`}
                    >
                        <item.icon size={18} />
                    </button>
                ))}
            </div>

            {/* Shapes Group */}
            <div className="flex items-center bg-black/40 rounded-lg p-1 border border-white/10">
                {[
                    { id: 'rect', icon: Square },
                    { id: 'circle', icon: CircleIcon },
                    { id: 'line', icon: Minus },
                    { id: 'text', icon: Type },
                ].map((item) => (
                    <button 
                        key={item.id}
                        onClick={() => setTool(item.id as Tool)}
                        className={`p-2 rounded-md transition-all ${
                            tool === item.id
                            ? 'bg-cyber-cyan text-black shadow-[0_0_10px_#00f3ff]' 
                            : 'text-slate-400 hover:text-white hover:bg-white/5'
                        }`}
                    >
                        <item.icon size={18} />
                    </button>
                ))}
            </div>
            
            {/* Colors */}
            <div className="flex items-center gap-2 pl-2 border-l border-white/10 hidden sm:flex">
                {['#00f3ff', '#ff003c', '#9d00ff', '#fcee0a', '#ffffff'].map(c => (
                    <button 
                        key={c}
                        onClick={() => setColor(c)}
                        className={`w-5 h-5 rounded-full transition-all duration-300 ${color === c ? 'scale-125 ring-2 ring-white' : 'hover:scale-110'}`}
                        style={{ backgroundColor: c, boxShadow: `0 0 10px ${c}` }}
                    />
                ))}
            </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-4 text-slate-400">
             <input 
                type="range" 
                min="1" 
                max="20" 
                value={lineWidth} 
                onChange={(e) => setLineWidth(Number(e.target.value))}
                className="w-20 accent-cyber-purple h-1 bg-white/10 rounded-lg appearance-none cursor-pointer hidden sm:block"
            />
            <button 
                onClick={() => setShowLayersPanel(!showLayersPanel)}
                className={`p-2 rounded transition-all ${showLayersPanel ? 'text-cyber-yellow bg-cyber-yellow/10' : 'hover:text-white'}`}
            >
                <Layers size={20} />
            </button>
            <button onClick={clearCanvas} className="p-2 hover:text-cyber-pink transition-colors"><Trash2 size={20} /></button>
        </div>
      </div>

      {/* Main Canvas Area */}
      <div 
        ref={containerRef}
        className="flex-1 rounded-2xl glass-panel border border-white/5 relative overflow-hidden cursor-crosshair bg-[#050818]"
      >
        {/* Grid Background */}
        <div className="absolute inset-0 pointer-events-none opacity-20" 
             style={{ backgroundImage: 'radial-gradient(circle, #475569 1px, transparent 1px)', backgroundSize: '30px 30px' }}>
        </div>

        {/* Layers */}
        {layers.map(layer => (
            <canvas
                key={layer.id}
                ref={(el) => { layerRefs.current[layer.id] = el; }}
                width={dimensions.width}
                height={dimensions.height}
                className={`absolute inset-0 transition-opacity duration-200 ${!layer.visible ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}
            />
        ))}

        {/* Preview / Interaction Canvas */}
        <canvas
            ref={previewCanvasRef}
            width={dimensions.width}
            height={dimensions.height}
            onMouseDown={startDrawing}
            onMouseMove={draw}
            onMouseUp={stopDrawing}
            onMouseLeave={stopDrawing}
            className="absolute inset-0 z-10"
        />

        {/* Text Input Overlay */}
        {textInput.visible && (
            <input
                autoFocus
                type="text"
                value={textInput.text}
                onChange={(e) => setTextInput({ ...textInput, text: e.target.value })}
                onKeyDown={(e) => e.key === 'Enter' && commitText()}
                onBlur={commitText}
                style={{ 
                    left: textInput.x, 
                    top: textInput.y,
                    fontSize: `${lineWidth * 4 + 12}px`,
                    color: color,
                    fontFamily: 'Rajdhani',
                    fontWeight: 'bold',
                    textShadow: `0 0 10px ${color}`
                }}
                className="absolute z-20 bg-transparent border border-white/30 rounded px-1 outline-none min-w-[100px]"
            />
        )}
      </div>

      {/* Layers Panel Floating */}
      {showLayersPanel && (
          <div className="absolute top-20 right-6 w-64 glass-panel bg-black/90 backdrop-blur-xl border border-white/10 rounded-xl p-4 z-40 shadow-2xl animate-in fade-in slide-in-from-right-5">
              <div className="flex justify-between items-center mb-4 pb-2 border-b border-white/10">
                  <h3 className="text-white font-bold font-display uppercase tracking-widest text-sm">Layers</h3>
                  <button onClick={addLayer} className="p-1 hover:bg-white/10 rounded text-cyber-cyan"><Plus size={16} /></button>
              </div>
              
              <div className="space-y-2 max-h-60 overflow-y-auto custom-scrollbar">
                  {[...layers].reverse().map(layer => (
                      <div 
                        key={layer.id}
                        onClick={() => setActiveLayerId(layer.id)}
                        className={`flex items-center gap-2 p-2 rounded cursor-pointer border transition-all ${
                            activeLayerId === layer.id 
                            ? 'bg-cyber-purple/20 border-cyber-purple/50' 
                            : 'bg-transparent border-transparent hover:bg-white/5'
                        }`}
                      >
                          <button 
                            onClick={(e) => { e.stopPropagation(); toggleLayer(layer.id); }}
                            className={`p-1 rounded ${layer.visible ? 'text-cyber-cyan' : 'text-slate-600'}`}
                          >
                              {layer.visible ? <Eye size={14} /> : <EyeOff size={14} />}
                          </button>
                          
                          <span className={`flex-1 text-xs font-mono truncate ${activeLayerId === layer.id ? 'text-white' : 'text-slate-400'}`}>
                              {layer.name}
                          </span>
                          
                          <button 
                            onClick={(e) => { e.stopPropagation(); deleteLayer(layer.id); }}
                            className="p-1 text-slate-600 hover:text-cyber-pink"
                          >
                              <X size={12} />
                          </button>
                      </div>
                  ))}
              </div>
          </div>
      )}
    </div>
  );
};