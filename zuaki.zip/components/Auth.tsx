
import React, { useState } from 'react';
import { User, Lock, Mail, ArrowRight, AlertCircle, CheckCircle, ShieldCheck } from 'lucide-react';
import { firebase } from '../services/backend';
import { UserProfile } from '../types';

interface AuthProps {
    onLoginSuccess: (user: Partial<UserProfile>, isNewUser?: boolean) => void;
    initialMode?: 'LOGIN' | 'SIGNUP';
}

export const Auth: React.FC<AuthProps> = ({ onLoginSuccess, initialMode = 'LOGIN' }) => {
    // Modes: LOGIN, SIGNUP_DETAILS, FORGOT
    const [view, setView] = useState<'LOGIN' | 'SIGNUP_DETAILS' | 'FORGOT'>(initialMode === 'SIGNUP' ? 'SIGNUP_DETAILS' : 'LOGIN');
    
    // UI States
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [successMsg, setSuccessMsg] = useState<string | null>(null);

    // Data States
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        password: '',
    });

    // --- LOGIC ---

    const handleInputChange = (field: string, value: string) => {
        setFormData(prev => ({ ...prev, [field]: value }));
        setError(null);
    };

    // 1. Google Login (Simulated)
    const handleGoogleLogin = async () => {
        setLoading(true);
        setError(null);
        try {
            const res = await firebase.auth().signInWithGoogle();
            
            // Store Google specific details in local storage for sync
            if (res.googleUid) localStorage.setItem('zuaki_google_uid', res.googleUid);
            if (res.email) localStorage.setItem('zuaki_email', res.email);
            if (res.photoUrl) localStorage.setItem('zuaki_photo_url', res.photoUrl);

            completeLogin(res.user, res.token, res.isNewUser);
        } catch (err: any) {
            setError("Google Sign-In failed. Please try again.");
            setLoading(false);
        }
    };

    // 2. Email Login
    const handleEmailLogin = async () => {
        if (!formData.email || !formData.password) return setError("Please enter email and password.");
        setLoading(true);
        try {
            const res = await firebase.auth().signInWithCredentials(formData.email, formData.password);
            completeLogin(res.user, res.token, false);
        } catch (err: any) {
            setError(err.message || "Invalid credentials.");
            setLoading(false);
        }
    };

    // 3. Signup (Full)
    const handleSignup = async () => {
        if (!formData.name || !formData.email || !formData.password) return setError("Please fill all fields.");
        if (formData.password.length < 6) return setError("Password must be 6+ chars.");
        
        setLoading(true);
        try {
            // Provide a default avatar, user will change it in Onboarding
            const defaultAvatar = `https://ui-avatars.com/api/?name=${formData.name}&background=00f3ff&color=000&bold=true`;
            
            const res = await firebase.auth().signUp({
                name: formData.name,
                email: formData.email,
                password: formData.password,
                avatar: defaultAvatar
            });
            completeLogin(res.user, res.token, true); // Signup implies new user
        } catch (err: any) {
            setError(err.message || "Signup failed.");
            setLoading(false);
        }
    };

    const completeLogin = (user: Partial<UserProfile>, token: string, isNewUser?: boolean) => {
        localStorage.setItem('zuaki_auth_token', token);
        localStorage.setItem('zuaki_user_id', user.userId || '');
        setSuccessMsg("Access Granted.");
        setTimeout(() => {
            onLoginSuccess(user, isNewUser);
        }, 800);
    };

    // --- RENDER ---

    return (
        <div className="h-screen w-screen bg-[#020617] flex items-center justify-center relative overflow-hidden font-sans text-white p-4">
            
            {/* Background Ambience */}
            <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 brightness-150 contrast-150 pointer-events-none"></div>
            {/* Moving Particles */}
            {[...Array(15)].map((_, i) => (
              <div 
                key={i}
                className="absolute rounded-full bg-cyber-cyan/20 blur-md animate-pulse"
                style={{
                    width: `${Math.random() * 6 + 2}px`,
                    height: `${Math.random() * 6 + 2}px`,
                    top: `${Math.random() * 100}%`,
                    left: `${Math.random() * 100}%`,
                    animationDuration: `${Math.random() * 5 + 3}s`
                }}
              />
            ))}
            <div className="absolute top-[-20%] left-[-20%] w-[500px] h-[500px] bg-blue-900/10 rounded-full blur-[120px] pointer-events-none animate-pulse-slow"></div>

            {/* Main Card */}
            <div className="z-20 glass-panel border border-white/10 rounded-[32px] max-w-md w-full shadow-[0_0_60px_rgba(0,0,0,0.5)] relative overflow-hidden flex flex-col">
                
                {/* Top Neon Line */}
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-cyber-cyan to-transparent"></div>

                {/* --- HEADER --- */}
                <div className="p-8 pb-4 text-center">
                    {/* Logo/Icon */}
                    <div className="w-16 h-16 mx-auto mb-4 relative">
                        <div className="absolute inset-0 bg-cyber-cyan blur-xl opacity-20 rounded-full animate-pulse"></div>
                        <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-[0_0_10px_#00f3ff] relative z-10">
                            <path d="M20 20 L 80 20 L 20 80 L 80 80" stroke="#00f3ff" strokeWidth="8" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                        </svg>
                    </div>
                    
                    <h2 className="text-2xl font-display font-bold text-white tracking-widest uppercase mb-1">
                        {view === 'LOGIN' ? 'Welcome Back' : view === 'FORGOT' ? 'Recovery' : 'Join Zuaki'}
                    </h2>
                    <p className="text-slate-400 text-xs font-mono tracking-widest">
                        {view === 'LOGIN' ? 'Access your neural hub' : view === 'SIGNUP_DETAILS' ? 'Initialize Profile' : 'Reset Protocol'}
                    </p>
                </div>

                <div className="px-8 pb-8 space-y-5">
                    
                    {/* Messages */}
                    {error && (
                        <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl flex items-center gap-3 text-red-400 text-xs font-bold animate-in slide-in-from-top-2">
                            <AlertCircle size={16} /> {error}
                        </div>
                    )}
                    {successMsg && (
                        <div className="p-3 bg-green-500/10 border border-green-500/30 rounded-xl flex items-center gap-3 text-green-400 text-xs font-bold animate-in slide-in-from-top-2">
                            <CheckCircle size={16} /> {successMsg}
                        </div>
                    )}

                    {/* --- VIEW: LOGIN --- */}
                    {view === 'LOGIN' && (
                        <div className="space-y-5 animate-in fade-in slide-in-from-right-4 duration-300">
                            {/* Google Button */}
                            <button 
                                onClick={handleGoogleLogin}
                                disabled={loading}
                                className="w-full py-3 bg-white hover:bg-gray-100 text-black rounded-xl font-bold flex items-center justify-center gap-3 transition-all shadow-[0_0_15px_rgba(255,255,255,0.1)] active:scale-95"
                            >
                                {loading ? (
                                    <div className="w-5 h-5 border-2 border-slate-300 border-t-black rounded-full animate-spin"></div>
                                ) : (
                                    <>
                                        <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-5 h-5" alt="Google" />
                                        <span>Continue with Google</span>
                                    </>
                                )}
                            </button>

                            {/* Divider */}
                            <div className="flex items-center gap-3">
                                <div className="h-px bg-white/10 flex-1"></div>
                                <span className="text-[10px] text-slate-500 uppercase tracking-widest">or continue with email</span>
                                <div className="h-px bg-white/10 flex-1"></div>
                            </div>

                            {/* Fields */}
                            <div className="space-y-3">
                                <div className="relative group">
                                    <Mail className="absolute left-4 top-3.5 text-slate-500 group-focus-within:text-cyber-cyan transition-colors" size={16} />
                                    <input 
                                        type="email" 
                                        value={formData.email}
                                        onChange={e => handleInputChange('email', e.target.value)}
                                        className="w-full bg-black/40 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white focus:border-cyber-cyan focus:shadow-[0_0_15px_rgba(0,243,255,0.1)] outline-none transition-all text-sm placeholder-slate-600"
                                        placeholder="Email Address"
                                    />
                                </div>
                                <div className="relative group">
                                    <Lock className="absolute left-4 top-3.5 text-slate-500 group-focus-within:text-cyber-cyan transition-colors" size={16} />
                                    <input 
                                        type="password" 
                                        value={formData.password}
                                        onChange={e => handleInputChange('password', e.target.value)}
                                        className="w-full bg-black/40 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white focus:border-cyber-cyan focus:shadow-[0_0_15px_rgba(0,243,255,0.1)] outline-none transition-all text-sm placeholder-slate-600"
                                        placeholder="Password"
                                    />
                                </div>
                            </div>

                            <button 
                                onClick={handleEmailLogin}
                                disabled={loading}
                                className="w-full py-4 bg-gradient-to-r from-green-400 to-blue-600 rounded-xl font-bold text-white uppercase tracking-widest hover:shadow-[0_0_20px_rgba(0,243,255,0.3)] transition-all flex items-center justify-center gap-2 active:scale-[0.98]"
                            >
                                {loading ? 'Accessing...' : 'Login'}
                            </button>

                            <div className="flex justify-between items-center text-xs mt-2">
                                <button onClick={() => setView('FORGOT')} className="text-slate-400 hover:text-white transition-colors">Forgot Password?</button>
                                <button onClick={() => setView('SIGNUP_DETAILS')} className="text-cyber-cyan font-bold hover:underline">Create Account</button>
                            </div>
                        </div>
                    )}

                    {/* --- VIEW: SIGNUP DETAILS --- */}
                    {view === 'SIGNUP_DETAILS' && (
                        <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
                            <div className="relative group">
                                <User className="absolute left-4 top-3.5 text-slate-500 group-focus-within:text-cyber-cyan transition-colors" size={16} />
                                <input 
                                    type="text" 
                                    value={formData.name}
                                    onChange={e => handleInputChange('name', e.target.value)}
                                    className="w-full bg-black/40 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white focus:border-cyber-cyan outline-none transition-all text-sm placeholder-slate-600"
                                    placeholder="Full Name"
                                />
                            </div>
                            <div className="relative group">
                                <Mail className="absolute left-4 top-3.5 text-slate-500 group-focus-within:text-cyber-cyan transition-colors" size={16} />
                                <input 
                                    type="email" 
                                    value={formData.email}
                                    onChange={e => handleInputChange('email', e.target.value)}
                                    className="w-full bg-black/40 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white focus:border-cyber-cyan outline-none transition-all text-sm placeholder-slate-600"
                                    placeholder="Email Address"
                                />
                            </div>
                            <div className="relative group">
                                <Lock className="absolute left-4 top-3.5 text-slate-500 group-focus-within:text-cyber-cyan transition-colors" size={16} />
                                <input 
                                    type="password" 
                                    value={formData.password}
                                    onChange={e => handleInputChange('password', e.target.value)}
                                    className="w-full bg-black/40 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white focus:border-cyber-cyan outline-none transition-all text-sm placeholder-slate-600"
                                    placeholder="Create Password"
                                />
                            </div>

                            <button 
                                onClick={handleSignup}
                                className="w-full py-4 bg-gradient-to-r from-green-400 to-blue-600 rounded-xl font-bold text-white uppercase tracking-widest hover:shadow-[0_0_20px_rgba(0,243,255,0.3)] transition-all flex items-center justify-center gap-2 mt-4"
                            >
                                {loading ? 'Initializing...' : <>Initialize Setup <ShieldCheck size={18} /></>}
                            </button>

                            <div className="text-center mt-4">
                                <button onClick={() => setView('LOGIN')} className="text-xs text-slate-400 hover:text-white">Already have an account? Login</button>
                            </div>
                        </div>
                    )}

                    {/* --- VIEW: FORGOT PASSWORD --- */}
                    {view === 'FORGOT' && (
                        <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
                            <p className="text-slate-400 text-xs text-center mb-2">Enter your email to receive a recovery link.</p>
                            <div className="relative group">
                                <Mail className="absolute left-4 top-3.5 text-slate-500 group-focus-within:text-cyber-cyan transition-colors" size={16} />
                                <input 
                                    type="email" 
                                    className="w-full bg-black/40 border border-white/10 rounded-xl py-3 pl-12 pr-4 text-white focus:border-cyber-cyan outline-none transition-all text-sm placeholder-slate-600"
                                    placeholder="Email Address"
                                />
                            </div>
                            <button 
                                onClick={() => {
                                    setLoading(true);
                                    setTimeout(() => { setLoading(false); setSuccessMsg("Reset link sent!"); setTimeout(() => setView('LOGIN'), 2000); }, 1500);
                                }}
                                disabled={loading}
                                className="w-full py-4 bg-white/10 border border-white/20 text-white rounded-xl font-bold uppercase tracking-widest hover:bg-white/20 transition-all"
                            >
                                {loading ? 'Sending...' : 'Send Link'}
                            </button>
                            <button onClick={() => setView('LOGIN')} className="w-full text-center text-xs text-slate-500 hover:text-white">Back to Login</button>
                        </div>
                    )}

                </div>
            </div>
        </div>
    );
};
