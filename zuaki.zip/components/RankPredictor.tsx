
import React, { useState } from 'react';
import { TrendingUp, Award, BarChart } from 'lucide-react';

export const RankPredictor: React.FC = () => {
  const [score, setScore] = useState('');
  const [prediction, setPrediction] = useState<any>(null);

  const handlePredict = () => {
      setPrediction({
          rank: 14205,
          percentile: '98.4 - 98.8',
          confidence: 'High'
      });
  };

  return (
    <div className="h-full w-full bg-[#020617] flex items-center justify-center p-6">
        <div className="max-w-md w-full glass-panel p-8 rounded-[32px] border border-cyber-yellow/30 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-cyber-yellow/10 rounded-full blur-[60px] pointer-events-none"></div>
            
            <div className="mb-8 text-center">
                <div className="w-16 h-16 mx-auto rounded-full bg-cyber-yellow/10 border border-cyber-yellow flex items-center justify-center text-cyber-yellow mb-4 shadow-[0_0_15px_#fcee0a]">
                    <TrendingUp size={28} />
                </div>
                <h1 className="text-2xl font-display font-bold text-white uppercase tracking-wider">JEE Rank Predictor</h1>
                <p className="text-slate-500 text-xs">Based on Vercel AI Models</p>
            </div>

            {!prediction ? (
                <div className="space-y-6">
                    <div>
                        <label className="text-xs font-bold text-white uppercase tracking-widest mb-2 block">Mock Test Score (0-300)</label>
                        <input 
                            type="number" 
                            value={score}
                            onChange={(e) => setScore(e.target.value)}
                            className="w-full bg-black/40 border border-white/10 rounded-xl px-4 py-4 text-white text-center text-xl font-mono focus:border-cyber-yellow focus:shadow-[0_0_15px_rgba(252,238,10,0.3)] outline-none transition-all"
                            placeholder="e.g. 180"
                        />
                    </div>
                    
                    <div>
                        <label className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2 block">Paper Difficulty</label>
                        <div className="flex gap-2">
                            {['Easy', 'Medium', 'Hard'].map(d => (
                                <button key={d} className="flex-1 py-2 rounded-lg border border-white/10 bg-white/5 text-xs text-slate-300 hover:bg-cyber-yellow/20 hover:text-cyber-yellow hover:border-cyber-yellow transition-all">
                                    {d}
                                </button>
                            ))}
                        </div>
                    </div>

                    <button 
                        onClick={handlePredict}
                        disabled={!score}
                        className="w-full py-4 bg-cyber-yellow text-black font-bold rounded-xl uppercase tracking-widest shadow-[0_0_20px_rgba(252,238,10,0.4)] hover:scale-[1.02] transition-all"
                    >
                        Predict Rank
                    </button>
                </div>
            ) : (
                <div className="text-center animate-in zoom-in duration-300">
                    <p className="text-slate-400 text-xs uppercase tracking-widest mb-2">Predicted Rank Range</p>
                    <h2 className="text-5xl font-display font-bold text-white mb-2 drop-shadow-[0_0_10px_rgba(255,255,255,0.5)]">
                        {prediction.rank.toLocaleString()}
                    </h2>
                    <div className="inline-block px-4 py-1 rounded-full bg-white/10 border border-white/20 text-cyber-yellow text-sm font-mono mb-8">
                        {prediction.percentile} %ile
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                            <p className="text-[10px] text-slate-500 uppercase">Confidence</p>
                            <p className="text-green-400 font-bold">{prediction.confidence}</p>
                        </div>
                        <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                            <p className="text-[10px] text-slate-500 uppercase">Trend</p>
                            <p className="text-cyber-cyan font-bold flex items-center justify-center gap-1"><TrendingUp size={12} /> Upwards</p>
                        </div>
                    </div>
                    
                    <button onClick={() => setPrediction(null)} className="mt-6 text-xs text-slate-500 hover:text-white underline">
                        Reset Prediction
                    </button>
                </div>
            )}
        </div>
    </div>
  );
};
