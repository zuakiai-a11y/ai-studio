
import React, { useState, useEffect } from 'react';
import { Bell, ArrowUpRight, Users, Bot, FileText, Calculator, BookOpen, PenTool, Trophy, Quote, HelpCircle, Activity, Zap, Hexagon, Star } from 'lucide-react';
import { ViewState, UserProfile } from '../types';
import { statsService } from '../services/statsService';
import { firebase } from '../services/backend';

interface DashboardProps {
    onChangeView: (view: ViewState) => void;
    onOpenCalc: () => void;
    userProfileProp?: Partial<UserProfile>;
}

const QUOTES = [
    "The only way to do great work is to love what you do.",
    "Success is the sum of small efforts, repeated day in and day out.",
    "Believe you can and you're halfway there.",
    "Your future is created by what you do today, not tomorrow."
];

export const Dashboard: React.FC<DashboardProps> = ({ onChangeView, onOpenCalc, userProfileProp }) => {
  const [quote, setQuote] = useState(QUOTES[0]);
  const [streak, setStreak] = useState(0);
  const [userProfile, setUserProfile] = useState<Partial<UserProfile>>(userProfileProp || {});
  const [hasData, setHasData] = useState(false);

  useEffect(() => {
      setQuote(QUOTES[Math.floor(Math.random() * QUOTES.length)]);
      
      const stats = statsService.getStats();
      setStreak(stats.dailyStreak);
      setHasData(stats.totalTime > 0);
      
      // If props updated or missing, use props as truth
      if (userProfileProp) {
          setUserProfile(userProfileProp);
      }
  }, [userProfileProp]);

  const todayStr = new Date().toLocaleDateString('en-US', { weekday: 'long', day: 'numeric', month: 'long' });

  return (
    <div className="h-full w-full overflow-y-auto custom-scrollbar p-6 pb-28 relative bg-[#020617] perspective-1000">
      
      {/* 1. Neon Particle Background & Ambient Lighting */}
      <div className="fixed inset-0 pointer-events-none z-0">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,_#0f172a_0%,_#020617_70%)]"></div>
          {/* Subtle Particles (CSS based) */}
          {[...Array(20)].map((_, i) => (
              <div 
                key={i}
                className="absolute rounded-full bg-cyber-cyan/20 blur-md animate-pulse"
                style={{
                    width: `${Math.random() * 4 + 2}px`,
                    height: `${Math.random() * 4 + 2}px`,
                    top: `${Math.random() * 100}%`,
                    left: `${Math.random() * 100}%`,
                    animationDuration: `${Math.random() * 3 + 2}s`,
                    animationDelay: `${Math.random() * 2}s`
                }}
              />
          ))}
          {/* Moving Gradient Blobs */}
          <div className="absolute top-[-10%] right-[-10%] w-[500px] h-[500px] bg-cyber-purple/10 rounded-full blur-[120px] animate-pulse-slow"></div>
          <div className="absolute bottom-[-10%] left-[-10%] w-[500px] h-[500px] bg-cyber-cyan/10 rounded-full blur-[120px] animate-pulse-slow" style={{animationDelay: '1.5s'}}></div>
      </div>

      <div className="relative z-10 max-w-5xl mx-auto">
      
        {/* Header Section */}
        <div className="flex justify-between items-center mb-2 animate-in slide-in-from-top-5 duration-700">
            <div className="flex items-center gap-4">
                <div className="relative group cursor-pointer" onClick={() => onChangeView(ViewState.PROFILE)}>
                    <div className="absolute inset-0 bg-gradient-to-tr from-cyber-cyan to-cyber-purple rounded-full blur-md opacity-60 group-hover:opacity-100 transition-opacity animate-spin-slow"></div>
                    <div className="w-16 h-16 rounded-full border-2 border-cyber-cyan/50 shadow-[0_0_20px_rgba(0,243,255,0.4)] p-0.5 relative z-10 bg-black overflow-hidden">
                        <img 
                            src={userProfile.avatar || "https://ui-avatars.com/api/?name=St&background=050818&color=00f3ff"} 
                            className="w-full h-full rounded-full object-cover transform group-hover:scale-110 transition-transform duration-500" 
                            alt="User" 
                        />
                    </div>
                </div>
                <div>
                    <div className="flex items-center gap-2 mb-1">
                        <h1 className="text-2xl font-display font-bold text-transparent bg-clip-text bg-gradient-to-r from-white via-cyber-cyan to-white tracking-wide drop-shadow-[0_0_10px_rgba(0,243,255,0.5)]">
                            ZUAKI HUB
                        </h1>
                        <div className="px-2 py-0.5 rounded border border-cyber-purple/30 bg-cyber-purple/10 text-[10px] text-cyber-purple font-mono tracking-widest animate-pulse">
                            ONLINE
                        </div>
                    </div>
                    <div className="flex items-center gap-2">
                        <span className="text-white font-bold text-sm">{userProfile.name}</span>
                        <div className="w-1 h-1 bg-slate-500 rounded-full"></div>
                        <p className="text-cyber-yellow text-xs tracking-[0.1em] font-bold uppercase flex items-center gap-1 animate-bounce duration-[2000ms]">
                            <Zap size={10} fill="currentColor" /> {streak} Day Streak
                        </p>
                    </div>
                </div>
            </div>
            
            <div className="flex flex-col items-center gap-2">
                <button onClick={() => onChangeView(ViewState.NOTIFICATIONS)} className="w-12 h-12 rounded-2xl glass-panel border border-white/10 flex items-center justify-center text-white hover:border-cyber-cyan hover:text-cyber-cyan hover:shadow-[0_0_20px_rgba(0,243,255,0.3)] transition-all relative group">
                    <Bell size={20} className="group-hover:rotate-12 transition-transform" />
                    <span className="absolute top-3 right-3 w-2 h-2 bg-cyber-pink rounded-full animate-ping"></span>
                    <span className="absolute top-3 right-3 w-2 h-2 bg-cyber-pink rounded-full shadow-[0_0_5px_#ff003c]"></span>
                </button>
                {/* Floating Calc Trigger */}
                <button 
                    onClick={onOpenCalc}
                    className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyber-cyan to-blue-600 text-black flex items-center justify-center shadow-[0_0_20px_rgba(0,243,255,0.4)] hover:scale-110 hover:shadow-[0_0_30px_rgba(0,243,255,0.6)] transition-all"
                >
                    <Calculator size={20} />
                </button>
            </div>
        </div>

        <div className="text-slate-500 text-xs font-mono mb-8 uppercase tracking-[0.2em] pl-2 border-l-2 border-cyber-purple/50 ml-1 animate-in fade-in duration-1000">
            {todayStr} • System Active
        </div>

        {/* Quote Card */}
        <div className="glass-panel p-6 rounded-[24px] border border-white/10 mb-8 relative overflow-hidden group hover:border-cyber-cyan/30 transition-all duration-500 animate-in slide-in-from-bottom-6">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000"></div>
            <Quote size={32} className="absolute top-4 left-4 text-white/5 rotate-180 group-hover:text-cyber-cyan/10 transition-colors" />
            <p className="text-white/90 font-display text-lg italic text-center relative z-10 drop-shadow-md">"{quote}"</p>
            <Quote size={32} className="absolute bottom-4 right-4 text-white/5 group-hover:text-cyber-cyan/10 transition-colors" />
        </div>

        {/* Neon Separator */}
        <div className="h-px w-full bg-gradient-to-r from-transparent via-cyber-cyan/50 to-transparent mb-8 shadow-[0_0_10px_#00f3ff] opacity-50"></div>

        {/* Feature Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
            
            {/* Weekly Analysis - Featured Large Card */}
            <div onClick={() => onChangeView(ViewState.ANALYSIS)} className="col-span-2 row-span-1 lg:row-span-2 glass-panel p-6 rounded-[30px] border border-white/10 relative overflow-hidden group cursor-pointer hover:border-cyber-cyan/50 hover:shadow-[0_0_30px_rgba(0,243,255,0.15)] transition-all duration-300 animate-in zoom-in-95 delay-100">
                <div className="absolute inset-0 bg-cyber-cyan/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div className="absolute -right-10 -top-10 w-40 h-40 bg-cyber-cyan/20 rounded-full blur-[50px] group-hover:bg-cyber-cyan/30 transition-all"></div>
                
                <div className="flex justify-between items-center mb-4 relative z-10">
                    <h3 className="text-white font-bold text-lg flex items-center gap-2 uppercase tracking-wide">
                        <Activity size={20} className="text-cyber-cyan animate-pulse"/> Weekly Insight
                    </h3>
                    <div className="p-2 rounded-full border border-white/10 bg-black/20 group-hover:bg-cyber-cyan group-hover:text-black transition-all">
                        <ArrowUpRight size={18} />
                    </div>
                </div>
                
                {hasData ? (
                    <div className="h-40 w-full relative z-10 flex items-end justify-between gap-3 px-2 pb-2">
                        {[40, 60, 30, 80, 50, 90, 70].map((h, i) => (
                            <div key={i} className="w-full bg-black/40 rounded-t-lg relative overflow-hidden group-hover:shadow-[0_0_15px_rgba(0,243,255,0.2)]">
                                <div style={{height: `${h}%`}} className="absolute bottom-0 w-full bg-gradient-to-t from-cyber-cyan to-blue-500 rounded-t-lg transition-all duration-1000"></div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="h-40 flex flex-col items-center justify-center text-center relative z-10">
                        <p className="text-slate-400 text-sm mb-3 font-mono">No neural data available</p>
                        <span className="text-xs text-cyber-cyan border border-cyber-cyan/30 bg-cyber-cyan/10 px-4 py-2 rounded-full font-bold uppercase tracking-widest hover:bg-cyber-cyan hover:text-black transition-colors">Start Studying</span>
                    </div>
                )}
            </div>

            {/* GenZ Chat - Hologram Effect */}
            <div onClick={() => onChangeView(ViewState.CHAT)} className="col-span-2 glass-panel p-6 rounded-[30px] border border-white/10 relative overflow-hidden group cursor-pointer hover:border-cyber-purple/50 hover:shadow-[0_0_30px_rgba(157,0,255,0.15)] transition-all duration-300 animate-in zoom-in-95 delay-150 h-full flex flex-col justify-between">
                 <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-10"></div>
                 <div className="absolute -left-10 -bottom-10 w-40 h-40 bg-cyber-purple/20 rounded-full blur-[50px] group-hover:bg-cyber-purple/30 transition-all"></div>
                 
                 <div className="flex justify-between items-start relative z-10">
                     <div className="p-3 rounded-2xl bg-cyber-purple/10 border border-cyber-purple/30 text-cyber-purple group-hover:scale-110 group-hover:shadow-[0_0_15px_#9d00ff] transition-transform duration-300">
                         <Bot size={28} />
                     </div>
                     <span className="text-[10px] font-bold bg-cyber-purple/20 text-cyber-purple px-2 py-1 rounded border border-cyber-purple/30">AI ACTIVE</span>
                 </div>
                 <div className="relative z-10">
                     <h4 className="text-xl font-display font-bold text-white mb-1 group-hover:text-cyber-purple transition-colors">GenZ Chat</h4>
                     <p className="text-slate-400 text-xs">Ask doubts, generate images.</p>
                 </div>
            </div>

            <FeatureCard title="Quick Quiz" icon={HelpCircle} color="purple" delay={200} onClick={() => onChangeView(ViewState.QUIZ_GENERATOR)} />
            <FeatureCard title="Planner" icon={FileText} color="pink" delay={250} onClick={() => onChangeView(ViewState.PLANNER)} />
            <FeatureCard title="Leaderboard" icon={Trophy} color="yellow" delay={300} onClick={() => onChangeView(ViewState.LEADERBOARD)} />
            <FeatureCard title="Flashcards" icon={BookOpen} color="white" delay={350} onClick={() => onChangeView(ViewState.FLASHCARDS)} />
            <FeatureCard title="Shortcuts" icon={Zap} color="blue" delay={400} onClick={() => {}} />
            <FeatureCard title="Formula Vault" icon={Hexagon} color="cyan" delay={450} onClick={() => onChangeView(ViewState.FORMULA_VAULT)} />

        </div>
      </div>
    </div>
  );
};

const FeatureCard = ({ title, icon: Icon, color, onClick, delay }: any) => {
    const colorMap: any = {
        purple: 'text-cyber-purple bg-cyber-purple/10 border-cyber-purple/30 group-hover:border-cyber-purple group-hover:shadow-[0_0_20px_#9d00ff]',
        pink: 'text-cyber-pink bg-cyber-pink/10 border-cyber-pink/30 group-hover:border-cyber-pink group-hover:shadow-[0_0_20px_#ff003c]',
        yellow: 'text-cyber-yellow bg-cyber-yellow/10 border-cyber-yellow/30 group-hover:border-cyber-yellow group-hover:shadow-[0_0_20px_#fcee0a]',
        white: 'text-white bg-white/10 border-white/30 group-hover:border-white group-hover:shadow-[0_0_20px_#ffffff]',
        blue: 'text-blue-400 bg-blue-400/10 border-blue-400/30 group-hover:border-blue-400 group-hover:shadow-[0_0_20px_#60a5fa]',
        cyan: 'text-cyber-cyan bg-cyber-cyan/10 border-cyber-cyan/30 group-hover:border-cyber-cyan group-hover:shadow-[0_0_20px_#00f3ff]'
    };

    return (
        <div 
            onClick={onClick} 
            className={`glass-panel p-5 rounded-[24px] border border-white/10 hover:bg-white/5 cursor-pointer group transition-all duration-300 relative overflow-hidden h-40 flex flex-col justify-between animate-in zoom-in-95`}
            style={{ animationDelay: `${delay}ms` }}
        >
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center border transition-all duration-300 ${colorMap[color]}`}>
                <Icon size={20} className="group-hover:scale-110 transition-transform" />
            </div>
            <div>
                <h4 className="text-white font-bold text-sm mb-1 group-hover:tracking-wide transition-all">{title}</h4>
                <div className="w-6 h-1 rounded-full bg-white/10 group-hover:w-full transition-all duration-500 bg-gradient-to-r from-transparent via-white/30 to-transparent"></div>
            </div>
            
            <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-x-2 group-hover:translate-x-0">
                <ArrowUpRight size={14} className="text-white" />
            </div>
        </div>
    );
};
