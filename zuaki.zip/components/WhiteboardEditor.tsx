
import React, { useRef, useState, useEffect, useCallback } from 'react';
import { 
    ArrowLeft, Save, Undo, Redo, Trash2, Plus, 
    ChevronLeft, ChevronRight, Pen, Eraser, Highlighter, 
    Download, Layers, Maximize, Minimize, MousePointer2
} from 'lucide-react';
import { Note, WhiteboardPage, WhiteboardStroke, StrokePoint } from '../types';

interface WhiteboardEditorProps {
    note: Note | null;
    onSave: (note: Note) => void;
    onExit: () => void;
}

const COLORS = [
    '#ffffff', // White
    '#00f3ff', // Cyan
    '#9d00ff', // Purple
    '#fcee0a', // Yellow
    '#ff003c', // Red
    '#22c55e', // Green
];

const THICKNESSES = [2, 5, 10];

export const WhiteboardEditor: React.FC<WhiteboardEditorProps> = ({ note, onSave, onExit }) => {
    // --- STATE ---
    const [title, setTitle] = useState(note?.title || 'New Whiteboard');
    const [pages, setPages] = useState<WhiteboardPage[]>(note?.whiteboardPages || [{ id: 'p1', strokes: [] }]);
    const [activePageIndex, setActivePageIndex] = useState(0);
    
    // Tool State
    const [tool, setTool] = useState<'pen' | 'highlighter' | 'eraser'>('pen');
    const [color, setColor] = useState('#00f3ff');
    const [thickness, setThickness] = useState(2);
    
    // History for Undo/Redo (Per Page)
    // We store snapshots of strokes array. Not ultra-efficient for huge apps, but fine for notes.
    const [history, setHistory] = useState<Record<string, WhiteboardStroke[][]>>({});
    const [historyStep, setHistoryStep] = useState<Record<string, number>>({});

    // Drawing State
    const canvasRef = useRef<HTMLCanvasElement>(null);
    const [isDrawing, setIsDrawing] = useState(false);
    const currentStroke = useRef<WhiteboardStroke | null>(null);
    const containerRef = useRef<HTMLDivElement>(null);

    // --- CANVAS MANAGEMENT ---

    const getActivePage = () => pages[activePageIndex];

    const resizeCanvas = () => {
        if (canvasRef.current && containerRef.current) {
            const { clientWidth, clientHeight } = containerRef.current;
            canvasRef.current.width = clientWidth;
            canvasRef.current.height = clientHeight;
            redraw();
        }
    };

    useEffect(() => {
        window.addEventListener('resize', resizeCanvas);
        resizeCanvas();
        return () => window.removeEventListener('resize', resizeCanvas);
    }, [activePageIndex, pages]); // Redraw when page or data changes

    const redraw = () => {
        const canvas = canvasRef.current;
        const ctx = canvas?.getContext('2d');
        if (!canvas || !ctx) return;

        // Clear Canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        const page = getActivePage();
        if (!page) return;

        // Draw Strokes
        page.strokes.forEach(stroke => {
            drawStroke(ctx, stroke);
        });
    };

    const drawStroke = (ctx: CanvasRenderingContext2D, stroke: WhiteboardStroke) => {
        if (stroke.points.length < 2) return;

        ctx.beginPath();
        ctx.lineCap = 'round';
        ctx.lineJoin = 'round';
        
        if (stroke.type === 'eraser') {
            ctx.globalCompositeOperation = 'destination-out';
            ctx.lineWidth = stroke.width * 2; // Eraser slightly bigger
            ctx.strokeStyle = 'rgba(0,0,0,1)';
        } else if (stroke.type === 'highlighter') {
            ctx.globalCompositeOperation = 'source-over'; // Changed to source-over with alpha for better saving
            ctx.lineWidth = stroke.width * 3;
            // Parse hex to rgba for highlighter transparency
            const hex = stroke.color.replace('#', '');
            const r = parseInt(hex.substring(0,2), 16);
            const g = parseInt(hex.substring(2,4), 16);
            const b = parseInt(hex.substring(4,6), 16);
            ctx.strokeStyle = `rgba(${r},${g},${b}, 0.3)`;
        } else {
            ctx.globalCompositeOperation = 'source-over';
            ctx.lineWidth = stroke.width;
            ctx.strokeStyle = stroke.color;
        }

        ctx.moveTo(stroke.points[0].x, stroke.points[0].y);
        for (let i = 1; i < stroke.points.length; i++) {
            ctx.lineTo(stroke.points[i].x, stroke.points[i].y);
        }
        ctx.stroke();
    };

    // --- INTERACTION HANDLERS ---

    const getPoint = (e: React.MouseEvent | React.TouchEvent): StrokePoint => {
        const rect = canvasRef.current!.getBoundingClientRect();
        const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
        const clientY = 'touches' in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;
        return {
            x: clientX - rect.left,
            y: clientY - rect.top
        };
    };

    const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
        // Prevent touch scrolling
        if (e.type === 'touchstart') document.body.style.overflow = 'hidden';

        setIsDrawing(true);
        const point = getPoint(e);
        
        currentStroke.current = {
            points: [point],
            color: color,
            width: thickness,
            type: tool
        };

        // Instant visual feedback
        const ctx = canvasRef.current?.getContext('2d');
        if (ctx) {
            ctx.beginPath();
            ctx.arc(point.x, point.y, thickness / 2, 0, Math.PI * 2);
            ctx.fillStyle = tool === 'eraser' ? '#fff' : color; // Visual only
            // Don't fill eraser for real drawing logic, just for user cursor feedback if we had one
        }
    };

    const draw = (e: React.MouseEvent | React.TouchEvent) => {
        if (!isDrawing || !currentStroke.current) return;
        
        const point = getPoint(e);
        currentStroke.current.points.push(point);

        // Draw live segment (optimization: don't redraw full canvas while dragging)
        const ctx = canvasRef.current?.getContext('2d');
        if (ctx) {
            const points = currentStroke.current.points;
            const lastPoint = points[points.length - 2];
            
            // Re-use logic for style
            if (tool === 'eraser') {
                ctx.globalCompositeOperation = 'destination-out';
                ctx.lineWidth = thickness * 2;
                ctx.strokeStyle = 'rgba(0,0,0,1)';
            } else if (tool === 'highlighter') {
                ctx.globalCompositeOperation = 'source-over';
                ctx.lineWidth = thickness * 3;
                const hex = color.replace('#', '');
                const r = parseInt(hex.substring(0,2), 16);
                const g = parseInt(hex.substring(2,4), 16);
                const b = parseInt(hex.substring(4,6), 16);
                ctx.strokeStyle = `rgba(${r},${g},${b}, 0.1)`; // Very faint during draw to avoid layering artifacts
            } else {
                ctx.globalCompositeOperation = 'source-over';
                ctx.lineWidth = thickness;
                ctx.strokeStyle = color;
            }
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.beginPath();
            ctx.moveTo(lastPoint.x, lastPoint.y);
            ctx.lineTo(point.x, point.y);
            ctx.stroke();
        }
    };

    const stopDrawing = () => {
        document.body.style.overflow = 'auto'; // Restore scroll
        if (!isDrawing || !currentStroke.current) return;
        setIsDrawing(false);

        // Save Stroke to Page State
        const newStroke = currentStroke.current;
        const pageId = getActivePage().id;
        
        const updatedPages = [...pages];
        updatedPages[activePageIndex].strokes.push(newStroke);
        
        // Save to History for Undo
        const prevHistory = history[pageId] || [];
        const currentStep = historyStep[pageId] || 0;
        // Truncate history if we undid then drew
        const newHistory = prevHistory.slice(0, currentStep + 1);
        newHistory.push([...updatedPages[activePageIndex].strokes]);
        
        setHistory({ ...history, [pageId]: newHistory });
        setHistoryStep({ ...historyStep, [pageId]: newHistory.length - 1 });

        setPages(updatedPages);
        currentStroke.current = null;
        redraw(); // Redraw cleanly
    };

    // --- PAGE OPERATIONS ---

    const addPage = () => {
        const newPage: WhiteboardPage = {
            id: `p${Date.now()}`,
            strokes: []
        };
        setPages([...pages, newPage]);
        setActivePageIndex(pages.length); // Switch to new
    };

    const generateThumbnail = (): string => {
        // Generate thumb of CURRENT page or first page
        if (!canvasRef.current) return '';
        // If we want accurate thumb, we should ensure canvas has content. 
        // We will grab the current view.
        return canvasRef.current.toDataURL('image/png', 0.1); // Low quality for thumb
    };

    const handleSave = () => {
        const thumb = generateThumbnail();
        const updatedPages = [...pages];
        updatedPages[activePageIndex].thumbnail = thumb; // Update active page thumb
        // If first page has no thumb, give it one
        if (!updatedPages[0].thumbnail && activePageIndex === 0) {
            updatedPages[0].thumbnail = thumb;
        } else if (!updatedPages[0].thumbnail && updatedPages[0].strokes.length > 0) {
            // Render first page invisibly? For now, simple logic: current view is thumb
        }

        const newNote: Note = {
            id: note?.id || Date.now().toString(),
            title: title || 'Untitled Whiteboard',
            content: '', // Not used for WB
            type: 'whiteboard',
            color: 'default',
            labels: ['Whiteboard'],
            isPinned: false,
            isArchived: false,
            isStarred: false,
            createdAt: note?.createdAt || Date.now(),
            updatedAt: Date.now(),
            whiteboardPages: updatedPages
        };
        
        onSave(newNote);
    };

    const handleUndo = () => {
        const pageId = getActivePage().id;
        const currentStep = historyStep[pageId] ?? -1;
        const pageHistory = history[pageId];

        if (currentStep > 0 && pageHistory) {
            const prevStrokes = pageHistory[currentStep - 1];
            const updatedPages = [...pages];
            updatedPages[activePageIndex].strokes = [...prevStrokes];
            setPages(updatedPages);
            setHistoryStep({ ...historyStep, [pageId]: currentStep - 1 });
        } else if (currentStep === 0) {
             // Clear all
            const updatedPages = [...pages];
            updatedPages[activePageIndex].strokes = [];
            setPages(updatedPages);
            setHistoryStep({ ...historyStep, [pageId]: -1 });
        }
    };

    const handleRedo = () => {
        const pageId = getActivePage().id;
        const currentStep = historyStep[pageId] ?? -1;
        const pageHistory = history[pageId];

        if (pageHistory && currentStep < pageHistory.length - 1) {
            const nextStrokes = pageHistory[currentStep + 1];
            const updatedPages = [...pages];
            updatedPages[activePageIndex].strokes = [...nextStrokes];
            setPages(updatedPages);
            setHistoryStep({ ...historyStep, [pageId]: currentStep + 1 });
        }
    };

    const clearPage = () => {
        if(window.confirm("Clear entire page?")) {
            const updatedPages = [...pages];
            updatedPages[activePageIndex].strokes = [];
            setPages(updatedPages);
            redraw();
            // Add empty state to history
            const pageId = getActivePage().id;
            const prevHistory = history[pageId] || [];
            const newHistory = [...prevHistory, []];
            setHistory({...history, [pageId]: newHistory});
            setHistoryStep({...historyStep, [pageId]: newHistory.length - 1});
        }
    };

    return (
        <div className="fixed inset-0 z-[100] bg-[#020617] flex flex-col overflow-hidden">
            
            {/* 1. TOP TOOLBAR */}
            <div className="h-16 px-4 flex items-center justify-between bg-black/40 backdrop-blur-md border-b border-white/5 relative z-20">
                <div className="flex items-center gap-4">
                    <button onClick={onExit} className="p-2 rounded-full hover:bg-white/10 text-slate-400 hover:text-white transition-colors">
                        <ArrowLeft size={20} />
                    </button>
                    <input 
                        value={title} 
                        onChange={(e) => setTitle(e.target.value)}
                        className="bg-transparent text-white font-display font-bold text-lg outline-none w-48 placeholder-slate-600 focus:border-b border-cyber-cyan"
                        placeholder="Untitled Board"
                    />
                </div>

                {/* Desktop Tools (Center) */}
                <div className="hidden md:flex items-center gap-2 bg-white/5 p-1 rounded-xl border border-white/10">
                    <button onClick={() => setTool('pen')} className={`p-2 rounded-lg transition-all ${tool === 'pen' ? 'bg-cyber-cyan text-black shadow-[0_0_10px_#00f3ff]' : 'text-slate-400 hover:text-white'}`}><Pen size={18}/></button>
                    <button onClick={() => setTool('highlighter')} className={`p-2 rounded-lg transition-all ${tool === 'highlighter' ? 'bg-cyber-yellow text-black shadow-[0_0_10px_#fcee0a]' : 'text-slate-400 hover:text-white'}`}><Highlighter size={18}/></button>
                    <button onClick={() => setTool('eraser')} className={`p-2 rounded-lg transition-all ${tool === 'eraser' ? 'bg-cyber-pink text-white shadow-[0_0_10px_#ff003c]' : 'text-slate-400 hover:text-white'}`}><Eraser size={18}/></button>
                    <div className="w-px h-6 bg-white/10 mx-1"></div>
                    <button onClick={handleUndo} className="p-2 text-slate-400 hover:text-white"><Undo size={18}/></button>
                    <button onClick={handleRedo} className="p-2 text-slate-400 hover:text-white"><Redo size={18}/></button>
                </div>

                <div className="flex items-center gap-3">
                    <button onClick={clearPage} className="p-2 hover:bg-red-500/20 text-slate-400 hover:text-red-500 rounded-lg transition-all"><Trash2 size={20}/></button>
                    <button onClick={handleSave} className="px-5 py-2 bg-cyber-purple text-white font-bold rounded-lg shadow-[0_0_15px_#9d00ff] hover:scale-105 transition-all flex items-center gap-2">
                        <Save size={18} /> <span className="hidden sm:inline">Save</span>
                    </button>
                </div>
            </div>

            {/* 2. MAIN CANVAS AREA */}
            <div ref={containerRef} className="flex-1 relative cursor-crosshair bg-[#020617] overflow-hidden">
                {/* Grid Background */}
                <div className="absolute inset-0 pointer-events-none opacity-20" 
                     style={{ backgroundImage: 'radial-gradient(circle, #334155 1px, transparent 1px)', backgroundSize: '30px 30px' }}>
                </div>
                
                <canvas 
                    ref={canvasRef}
                    onMouseDown={startDrawing}
                    onMouseMove={draw}
                    onMouseUp={stopDrawing}
                    onMouseLeave={stopDrawing}
                    onTouchStart={startDrawing}
                    onTouchMove={draw}
                    onTouchEnd={stopDrawing}
                    className="absolute inset-0 z-10 touch-none"
                />

                {/* Floating Tool Panel (Mobile/Tablet Friendly) */}
                <div className="absolute top-4 left-4 z-20 flex flex-col gap-3">
                    {/* Color Picker */}
                    <div className="p-2 rounded-xl bg-black/60 backdrop-blur-md border border-white/10 flex flex-col gap-2 shadow-xl">
                        {COLORS.map(c => (
                            <button 
                                key={c}
                                onClick={() => { setColor(c); if(tool === 'eraser') setTool('pen'); }}
                                className={`w-6 h-6 rounded-full transition-transform ${color === c && tool !== 'eraser' ? 'scale-125 ring-2 ring-white' : ''}`}
                                style={{ backgroundColor: c }}
                            />
                        ))}
                    </div>
                    {/* Size Picker */}
                    <div className="p-2 rounded-xl bg-black/60 backdrop-blur-md border border-white/10 flex flex-col items-center gap-3 shadow-xl">
                        {THICKNESSES.map(t => (
                            <button 
                                key={t}
                                onClick={() => setThickness(t)}
                                className={`w-6 h-6 rounded-full flex items-center justify-center transition-all ${thickness === t ? 'bg-white/20' : ''}`}
                            >
                                <div className="rounded-full bg-white" style={{ width: t, height: t }}></div>
                            </button>
                        ))}
                    </div>
                </div>
            </div>

            {/* 3. BOTTOM PAGE NAVIGATOR */}
            <div className="h-20 bg-black/80 backdrop-blur-xl border-t border-white/10 flex items-center px-4 gap-4 relative z-20">
                <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-2">
                    {pages.map((p, idx) => (
                        <button
                            key={p.id}
                            onClick={() => setActivePageIndex(idx)}
                            className={`relative w-12 h-16 rounded-lg border flex items-center justify-center shrink-0 transition-all ${
                                activePageIndex === idx 
                                ? 'border-cyber-cyan bg-cyber-cyan/10 shadow-[0_0_10px_rgba(0,243,255,0.3)]' 
                                : 'border-white/10 bg-white/5 hover:border-white/30'
                            }`}
                        >
                            <span className="text-xs font-mono text-slate-400">{idx + 1}</span>
                            {/* Live mini preview could go here if we stored thumbnails per stroke update */}
                        </button>
                    ))}
                    <button 
                        onClick={addPage}
                        className="w-12 h-16 rounded-lg border border-white/10 border-dashed flex items-center justify-center shrink-0 text-slate-500 hover:text-white hover:border-white/30 transition-all"
                    >
                        <Plus size={20} />
                    </button>
                </div>
                
                {/* Mobile Tools Overlay (Visible only on small screens) */}
                <div className="md:hidden flex ml-auto gap-2">
                     <button onClick={() => setTool('pen')} className={`p-2 rounded-lg ${tool === 'pen' ? 'text-cyber-cyan bg-white/10' : 'text-slate-400'}`}><Pen size={20}/></button>
                     <button onClick={() => setTool('eraser')} className={`p-2 rounded-lg ${tool === 'eraser' ? 'text-cyber-pink bg-white/10' : 'text-slate-400'}`}><Eraser size={20}/></button>
                     <button onClick={handleUndo} className="p-2 text-slate-400"><Undo size={20}/></button>
                </div>
            </div>
        </div>
    );
};
