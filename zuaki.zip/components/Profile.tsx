
import React, { useEffect, useState } from 'react';
import { 
    User, Settings, Award, TrendingUp, Shield, Edit2, Clock, 
    Hexagon, LogOut, Copy, Check, Lock, Gift, Zap, Star, 
    Bell, MessageSquare, Users, Plus, ChevronRight, MapPin, Box, Cpu, ArrowUp, 
    Target, BookOpen, AlertTriangle, Play, Bookmark
} from 'lucide-react';
import { UserProfile, ViewState, UserStats, ChatContact } from '../types';
import { statsService } from '../services/statsService';
import { firebase } from '../services/backend';

interface ProfileProps {
  userProfile?: Partial<UserProfile>;
  onUpdateProfile?: (data: Partial<UserProfile>) => void;
  onNavigate?: (view: ViewState) => void;
  onLogout?: () => void;
}

// ... (RobotAvatarHorizontal and HorizontalLevelTrack components remain same, assuming they exist in previous scope or I re-include them if full replacement is needed. For brevity I include full content if I am replacing the file, which I am)

// --- ROBOT AVATAR (Horizontal Variant) ---
const RobotAvatarHorizontal = ({ moving }: { moving: boolean }) => (
    <div className={`relative w-12 h-12 transition-transform duration-500`}>
        {/* Thrust Effect */}
        <div className={`absolute top-1/2 -left-2 -translate-y-1/2 w-6 h-3 bg-gradient-to-r from-transparent to-cyber-cyan blur-sm transition-opacity duration-300 ${moving ? 'opacity-100' : 'opacity-50'}`}></div>
        
        <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-[0_0_10px_rgba(0,243,255,0.8)] transform -rotate-90">
            {/* Body */}
            <rect x="30" y="35" width="40" height="30" rx="5" fill="#0b0f1a" stroke="#00f3ff" strokeWidth="3" />
            
            {/* Head */}
            <path d="M30 35 L30 25 Q30 10 50 10 Q70 10 70 25 L70 35 Z" fill="#0b0f1a" stroke="#00f3ff" strokeWidth="3" />
            
            {/* Visor */}
            <path d="M35 25 L65 25" stroke="#00f3ff" strokeWidth="4" strokeLinecap="round" className="animate-pulse">
                <animate attributeName="stroke-opacity" values="1;0.5;1" dur="2s" repeatCount="indefinite" />
            </path>

            {/* Jetpack */}
            <path d="M25 40 L25 60 Q25 70 35 70 L65 70 Q75 70 75 60 L75 40" fill="none" stroke="#00f3ff" strokeWidth="2" opacity="0.5" />
        </svg>
    </div>
);

// --- HORIZONTAL XP TRACK COMPONENT ---
const HorizontalLevelTrack: React.FC<{ xp: number, level: number }> = ({ xp, level }) => {
    // XP Calculation
    const LEVEL_BASE = 500;
    const currentLevelStart = (level - 1) * LEVEL_BASE;
    const nextLevelStart = level * LEVEL_BASE;
    const xpInLevel = xp - currentLevelStart;
    const progressPercent = Math.min(100, Math.max(0, (xpInLevel / LEVEL_BASE) * 100));

    return (
        <div className="w-full glass-panel p-6 rounded-[24px] border border-white/10 relative overflow-hidden mb-6 shadow-[0_0_40px_rgba(0,0,0,0.4)]">
            {/* Ambient Background Glow */}
            <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-cyber-cyan/5 via-transparent to-cyber-purple/5 pointer-events-none"></div>
            
            {/* Header Info */}
            <div className="flex justify-between items-end mb-8 relative z-10">
                <div>
                    <div className="flex items-center gap-2 mb-1">
                        <span className="px-2 py-0.5 rounded border border-cyber-cyan/30 bg-cyber-cyan/10 text-[10px] text-cyber-cyan font-bold uppercase tracking-widest">
                            Current Rank
                        </span>
                    </div>
                    <h2 className="text-3xl font-display font-bold text-white flex items-center gap-2">
                        LEVEL {level} <span className="text-lg text-slate-500 font-normal">Scholar</span>
                    </h2>
                </div>
                <div className="text-right">
                    <p className="text-xs text-slate-400 uppercase tracking-widest mb-1">XP Progress</p>
                    <p className="text-xl font-mono font-bold text-white">
                        <span className="text-cyber-cyan">{Math.floor(xpInLevel)}</span> 
                        <span className="text-slate-600 text-sm mx-1">/</span> 
                        <span className="text-slate-500 text-lg">{LEVEL_BASE}</span>
                    </p>
                </div>
            </div>

            {/* THE TRACK */}
            <div className="relative h-16 w-full flex items-center mb-2">
                {/* Rail Background */}
                <div className="absolute w-full h-3 bg-[#020617] rounded-full border border-white/10 shadow-inner"></div>
                
                {/* Progress Fill */}
                <div 
                    className="absolute h-3 bg-gradient-to-r from-green-400 via-cyan-400 to-blue-500 rounded-full shadow-[0_0_15px_rgba(0,243,255,0.5)] transition-all duration-1000 ease-out"
                    style={{ width: `${progressPercent}%` }}
                ></div>

                {/* Milestones / Checkpoints */}
                {[33, 66, 100].map((pct, i) => (
                    <div 
                        key={pct}
                        className="absolute w-8 h-8 -ml-4 flex items-center justify-center transition-all duration-500"
                        style={{ left: `${pct}%`, top: '50%', transform: 'translateY(-50%)' }}
                    >
                        <div className={`w-3 h-3 rounded-full ${progressPercent >= pct ? 'bg-cyber-cyan shadow-[0_0_10px_#00f3ff]' : 'bg-[#0b0f1a] border border-white/20'}`}></div>
                        {/* Reward Icon for 100% */}
                        {pct === 100 && (
                            <div className="absolute -top-8 animate-bounce">
                                <Gift size={18} className={progressPercent >= 100 ? "text-cyber-pink" : "text-slate-600"} />
                            </div>
                        )}
                    </div>
                ))}

                {/* THE ROBOT (Moving Element) */}
                <div 
                    className="absolute top-1/2 -translate-y-1/2 transition-all duration-1000 ease-out z-20"
                    style={{ left: `calc(${progressPercent}% - 24px)` }}
                >
                    <div className="animate-[bounce_3s_infinite]">
                        <RobotAvatarHorizontal moving={progressPercent > 0} />
                    </div>
                    
                    {/* Tooltip */}
                    <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 bg-cyber-cyan/10 border border-cyber-cyan/30 px-2 py-0.5 rounded text-[9px] text-cyber-cyan font-bold font-mono whitespace-nowrap backdrop-blur-md opacity-0 hover:opacity-100 transition-opacity">
                        {Math.floor(progressPercent)}%
                    </div>
                </div>
            </div>

            {/* Helper Text */}
            <div className="flex justify-between text-[10px] text-slate-500 uppercase tracking-widest font-mono relative z-10">
                <span>Lvl {level}</span>
                <span>Next Reward: 500 XP</span>
                <span>Lvl {level + 1}</span>
            </div>
        </div>
    );
};

export const Profile: React.FC<ProfileProps> = ({ userProfile, onUpdateProfile, onNavigate, onLogout }) => {
  const [stats, setStats] = useState<UserStats>(statsService.getStats());
  const [zaId, setZaId] = useState(userProfile?.userId || '');
  const [copied, setCopied] = useState(false);
  const [bookmarksCount, setBookmarksCount] = useState(0);
  
  useEffect(() => {
    const unsubscribe = statsService.subscribe(setStats);
    if (!zaId && userProfile?.userId) {
        setZaId(userProfile.userId);
    }
    
    // Load bookmarks count
    const b = JSON.parse(localStorage.getItem('user_bookmarks') || '[]');
    setBookmarksCount(b.length);

    return () => { unsubscribe(); };
  }, [userProfile]);

  const copyToClipboard = () => {
      navigator.clipboard.writeText(zaId);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="h-full w-full bg-[#020617] relative overflow-hidden flex flex-col font-sans">
       {/* Deep Background Texture */}
       <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-5 pointer-events-none"></div>
       <div className="absolute top-[-20%] right-[-20%] w-[500px] h-[500px] bg-blue-900/10 rounded-full blur-[120px] pointer-events-none"></div>

       {/* 1. HERO HEADER */}
       <div className="px-6 pt-8 pb-4 flex items-center justify-between z-20">
           <div className="flex items-center gap-4">
               {/* Avatar */}
               <div className="relative group cursor-pointer" onClick={() => onNavigate?.(ViewState.EDIT_PROFILE)}>
                   <div className="w-16 h-16 rounded-full p-0.5 bg-gradient-to-br from-cyber-cyan/50 to-blue-600/50 shadow-[0_0_20px_rgba(0,243,255,0.15)]">
                       <img src={userProfile?.avatar || 'https://ui-avatars.com/api/?name=User'} className="w-full h-full rounded-full object-cover border-2 border-[#020617]" />
                   </div>
                   <div className="absolute bottom-0 right-0 px-1.5 py-0.5 bg-[#020617] rounded-full border border-green-500/30 flex items-center gap-1">
                       <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse shadow-[0_0_5px_#22c55e]"></div>
                       <span className="text-[8px] font-bold text-green-500 uppercase tracking-wide">Online</span>
                   </div>
               </div>
               
               {/* Info */}
               <div>
                   <h1 className="text-white font-display font-bold text-2xl leading-none tracking-wide">{userProfile?.name || 'Operative'}</h1>
                   <div className="flex items-center gap-2 mt-1.5">
                       <span className="px-2 py-0.5 bg-white/5 rounded text-[10px] text-cyber-cyan font-mono tracking-wider border border-white/10 flex items-center gap-1">
                           {zaId} 
                           <button onClick={copyToClipboard} className="hover:text-white transition-colors">
                               {copied ? <Check size={10} className="text-green-400"/> : <Copy size={10} />}
                           </button>
                       </span>
                       <span className="text-[10px] text-slate-500 border-l border-white/10 pl-2">
                           {userProfile?.studentClass ? `Class ${userProfile.studentClass}` : 'Class Not Set'}
                       </span>
                   </div>
               </div>
           </div>

           <div className="flex gap-2">
               <button onClick={() => onNavigate?.(ViewState.EDIT_PROFILE)} className="p-3 rounded-xl bg-white/5 border border-white/10 text-slate-400 hover:text-white hover:bg-white/10 transition-all">
                   <Settings size={20} />
               </button>
           </div>
       </div>

       <div className="flex-1 overflow-y-auto custom-scrollbar px-6 pb-24 z-10 space-y-6">
           
           {/* 2. HORIZONTAL LEVEL TRACK */}
           <HorizontalLevelTrack xp={stats.xp} level={stats.level} />

           {/* 3. XP SOURCES GRID */}
           <div className="grid grid-cols-3 gap-3">
               <div className="bg-white/5 border border-white/10 rounded-2xl p-4 flex flex-col items-center justify-center hover:bg-white/10 transition-colors">
                   <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-400 mb-2">
                       <Clock size={20} />
                   </div>
                   <span className="text-lg font-bold text-white">{Math.floor(stats.totalTime / 60)}</span>
                   <span className="text-[10px] text-slate-500 uppercase tracking-widest">Mins Study</span>
               </div>
               <div className="bg-white/5 border border-white/10 rounded-2xl p-4 flex flex-col items-center justify-center hover:bg-white/10 transition-colors">
                   <div className="w-10 h-10 rounded-full bg-yellow-500/10 flex items-center justify-center text-yellow-400 mb-2">
                       <Zap size={20} fill="currentColor" />
                   </div>
                   <span className="text-lg font-bold text-white">{stats.dailyStreak}</span>
                   <span className="text-[10px] text-slate-500 uppercase tracking-widest">Day Streak</span>
               </div>
               <div className="bg-white/5 border border-white/10 rounded-2xl p-4 flex flex-col items-center justify-center hover:bg-white/10 transition-colors">
                   <div className="w-10 h-10 rounded-full bg-purple-500/10 flex items-center justify-center text-purple-400 mb-2">
                       <Target size={20} />
                   </div>
                   <span className="text-lg font-bold text-white">{stats.quizzesAttempted}</span>
                   <span className="text-[10px] text-slate-500 uppercase tracking-widest">Quizzes</span>
               </div>
           </div>

           {/* 4. SAVED QUESTIONS (Bookmarks) */}
           <div className="glass-panel p-5 rounded-2xl border border-cyber-yellow/20 bg-cyber-yellow/5 flex items-center justify-between cursor-pointer hover:bg-cyber-yellow/10 transition-colors group">
               <div className="flex items-center gap-3">
                   <div className="w-10 h-10 rounded-full bg-cyber-yellow/10 flex items-center justify-center text-cyber-yellow group-hover:scale-110 transition-transform">
                       <Bookmark size={20} />
                   </div>
                   <div>
                       <h3 className="text-white font-bold text-sm">Saved Questions</h3>
                       <p className="text-slate-400 text-xs">{bookmarksCount} Bookmarked</p>
                   </div>
               </div>
               <ChevronRight size={18} className="text-slate-500 group-hover:text-white" />
           </div>

           {/* 5. ANALYTICS (Weak/Strong) */}
           <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
               {/* Weak Areas */}
               <div className="glass-panel p-5 rounded-2xl border border-red-500/20 bg-red-500/5">
                   <div className="flex justify-between items-center mb-4">
                       <h3 className="text-red-400 font-bold text-sm uppercase tracking-widest flex items-center gap-2">
                           <AlertTriangle size={16} /> Needs Focus
                       </h3>
                       <button onClick={() => onNavigate?.(ViewState.FLASHCARDS)} className="text-[10px] bg-red-500/20 text-red-400 px-2 py-1 rounded hover:bg-red-500 hover:text-white transition-all">
                           Fix Now
                       </button>
                   </div>
                   {stats.weakSubjects.length > 0 ? (
                       <div className="space-y-3">
                           {stats.weakSubjects.slice(0, 2).map((sub, i) => (
                               <div key={i} className="flex justify-between items-center bg-black/40 p-3 rounded-xl border border-red-500/10">
                                   <div className="flex items-center gap-3">
                                       <div className="w-8 h-8 rounded-lg bg-red-500/10 flex items-center justify-center text-red-500 font-bold text-xs">
                                           {sub[0]}
                                       </div>
                                       <div>
                                           <p className="text-white text-xs font-bold">{sub}</p>
                                           <p className="text-[10px] text-slate-500">Low Accuracy</p>
                                       </div>
                                   </div>
                                   <ArrowUp className="text-red-500 rotate-180" size={14} />
                               </div>
                           ))}
                       </div>
                   ) : (
                       <p className="text-slate-500 text-xs italic">No weak areas detected yet.</p>
                   )}
               </div>

               {/* Strong Areas */}
               <div className="glass-panel p-5 rounded-2xl border border-green-500/20 bg-green-500/5">
                   <div className="flex justify-between items-center mb-4">
                       <h3 className="text-green-400 font-bold text-sm uppercase tracking-widest flex items-center gap-2">
                           <Shield size={16} /> Stronghold
                       </h3>
                       <span className="text-[10px] text-slate-500">Keep it up</span>
                   </div>
                   {stats.strongSubjects.length > 0 ? (
                       <div className="space-y-3">
                           {stats.strongSubjects.slice(0, 2).map((sub, i) => (
                               <div key={i} className="flex justify-between items-center bg-black/40 p-3 rounded-xl border border-green-500/10">
                                   <div className="flex items-center gap-3">
                                       <div className="w-8 h-8 rounded-lg bg-green-500/10 flex items-center justify-center text-green-500 font-bold text-xs">
                                           {sub[0]}
                                       </div>
                                       <div>
                                           <p className="text-white text-xs font-bold">{sub}</p>
                                           <p className="text-[10px] text-slate-500">High Accuracy</p>
                                       </div>
                                   </div>
                                   <ArrowUp className="text-green-500" size={14} />
                               </div>
                           ))}
                       </div>
                   ) : (
                       <p className="text-slate-500 text-xs italic">Complete quizzes to analyze.</p>
                   )}
               </div>
           </div>

           {/* 6. QUICK ACTIONS */}
           <div>
               <h3 className="text-white font-bold text-sm uppercase tracking-widest mb-4 pl-1 border-l-4 border-cyber-cyan ml-1">Quick Actions</h3>
               <div className="grid grid-cols-2 gap-3">
                   <button onClick={() => onNavigate?.(ViewState.DAILY_FOCUS)} className="p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-cyber-cyan/50 hover:bg-cyber-cyan/10 transition-all flex flex-col items-center gap-2 group">
                       <Target size={24} className="text-slate-300 group-hover:text-cyber-cyan transition-colors" />
                       <span className="text-xs font-medium text-white">Start Focus</span>
                   </button>
                   <button onClick={() => onNavigate?.(ViewState.RANK_PREDICTOR)} className="p-4 rounded-2xl bg-white/5 border border-white/5 hover:border-cyber-purple/50 hover:bg-cyber-purple/10 transition-all flex flex-col items-center gap-2 group">
                       <TrendingUp size={24} className="text-slate-300 group-hover:text-cyber-purple transition-colors" />
                       <span className="text-xs font-medium text-white">Predict Rank</span>
                   </button>
               </div>
               
               <button onClick={onLogout} className="w-full mt-4 p-4 rounded-2xl border border-red-500/20 bg-red-500/5 text-red-500 flex items-center justify-center gap-2 hover:bg-red-500/10 hover:border-red-500/40 transition-all">
                   <LogOut size={16} /> <span className="font-bold text-xs uppercase tracking-wider">Logout</span>
               </button>
           </div>
           
           {/* Footer Info */}
           <div className="text-center opacity-30 pt-4">
               <p className="text-[10px] text-slate-500">Zuaki OS v2.1 • Local Storage Active</p>
           </div>
       </div>
    </div>
  );
};
