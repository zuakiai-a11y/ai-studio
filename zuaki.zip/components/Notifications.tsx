
import React, { useState, useEffect } from 'react';
import { Bell, Zap, User, BarChart2, FileText, Settings, Check, Trash2, ChevronRight, AlertCircle, Info, RefreshCw } from 'lucide-react';
import { notificationService } from '../services/notificationService';
import { ZuakiNotification, NotificationCategory } from '../types';
import { vercel } from '../services/backend';

interface NewsItem {
    id: string;
    title: string;
    date: string;
    link: string;
    source: string;
}

interface NotificationsProps {
    onChangeView?: (viewStr: string) => void;
}

export const Notifications: React.FC<NotificationsProps> = ({ onChangeView }) => {
    const [activeTab, setActiveTab] = useState<'ALL' | 'MISSION' | 'PERFORMANCE' | 'SYSTEM'>('ALL');
    const [notifications, setNotifications] = useState<ZuakiNotification[]>([]);
    const [news, setNews] = useState<NewsItem[]>([]);
    const [showSettings, setShowSettings] = useState(false);

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        // Load ZNC Notifications
        setNotifications(notificationService.getAll());

        // Load NTA News (Legacy Support)
        try {
            const data = await vercel.api.fetchNews();
            // @ts-ignore
            setNews(data);
        } catch (e) {}
    };

    const handleMarkRead = (id: string) => {
        notificationService.markAsRead(id);
        setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
    };

    const handleClearAll = () => {
        if(window.confirm("Clear all alerts?")) {
            notificationService.markAllRead(); // Or delete logic
            setNotifications(prev => prev.map(n => ({...n, read: true}))); // Visual clear or delete
        }
    };

    const handleCardClick = (n: ZuakiNotification) => {
        handleMarkRead(n.id);
        if (onChangeView && n.deepLink) {
            onChangeView(n.deepLink);
        }
    };

    const getIcon = (cat: NotificationCategory) => {
        switch(cat) {
            case 'MISSION': return <Zap size={20} className="text-cyber-yellow" />;
            case 'AVATAR': return <User size={20} className="text-cyber-purple" />;
            case 'PERFORMANCE': return <BarChart2 size={20} className="text-green-400" />;
            case 'NOTE': return <FileText size={20} className="text-cyber-cyan" />;
            case 'UPDATE': return <Info size={20} className="text-cyber-pink" />;
            default: return <Bell size={20} className="text-white" />;
        }
    };

    const filteredNotifications = activeTab === 'ALL' 
        ? notifications 
        : notifications.filter(n => {
            if (activeTab === 'SYSTEM') return n.category === 'UPDATE' || n.category === 'AVATAR';
            return n.category === activeTab;
        });

    return (
        <div className="h-full w-full bg-[#020617] overflow-y-auto custom-scrollbar p-6 relative">
            {/* Background Texture */}
            <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-5 pointer-events-none"></div>
            
            <div className="max-w-4xl mx-auto relative z-10">
                {/* Header */}
                <div className="flex justify-between items-start mb-8">
                    <div>
                        <h1 className="text-3xl font-display font-bold text-white uppercase tracking-widest flex items-center gap-3">
                            <Bell size={32} className="text-cyber-cyan" /> Notification Center
                        </h1>
                        <p className="text-slate-400 text-xs font-mono mt-1">ZNC: Mission Control & Alerts</p>
                    </div>
                    <div className="flex gap-2">
                        <button onClick={loadData} className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white"><RefreshCw size={18} /></button>
                        <button onClick={() => setShowSettings(!showSettings)} className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-white"><Settings size={18} /></button>
                    </div>
                </div>

                {/* Settings Panel Toggle */}
                {showSettings && (
                    <div className="mb-6 p-4 rounded-xl bg-white/5 border border-white/10 animate-in slide-in-from-top-2">
                        <h3 className="text-white font-bold text-sm mb-3">Notification Preferences</h3>
                        <div className="flex gap-4 text-xs text-slate-300">
                            <label className="flex items-center gap-2"><input type="checkbox" defaultChecked className="accent-cyber-cyan"/> Daily Briefing</label>
                            <label className="flex items-center gap-2"><input type="checkbox" defaultChecked className="accent-cyber-cyan"/> Streak Alerts</label>
                            <label className="flex items-center gap-2"><input type="checkbox" defaultChecked className="accent-cyber-cyan"/> Updates</label>
                        </div>
                    </div>
                )}

                {/* Tabs */}
                <div className="flex gap-2 mb-6 overflow-x-auto no-scrollbar">
                    {['ALL', 'MISSION', 'PERFORMANCE', 'SYSTEM'].map(tab => (
                        <button
                            key={tab}
                            onClick={() => setActiveTab(tab as any)}
                            className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider transition-all border ${
                                activeTab === tab 
                                ? 'bg-cyber-cyan/10 border-cyber-cyan text-cyber-cyan shadow-[0_0_10px_rgba(0,243,255,0.2)]' 
                                : 'bg-white/5 border-white/5 text-slate-400 hover:text-white'
                            }`}
                        >
                            {tab}
                        </button>
                    ))}
                    <button onClick={handleClearAll} className="ml-auto flex items-center gap-1 text-xs text-red-400 hover:text-red-300 px-3">
                        <Trash2 size={14} /> Clear
                    </button>
                </div>

                {/* Notification List */}
                <div className="space-y-4 mb-10">
                    {filteredNotifications.length === 0 ? (
                        <div className="text-center py-20 opacity-50">
                            <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-4">
                                <Check size={32} className="text-slate-500" />
                            </div>
                            <p className="text-slate-400 text-sm">All caught up, Operative.</p>
                        </div>
                    ) : (
                        filteredNotifications.map((n) => (
                            <div 
                                key={n.id} 
                                onClick={() => handleCardClick(n)}
                                className={`group relative p-5 rounded-2xl border transition-all cursor-pointer overflow-hidden ${
                                    n.read 
                                    ? 'bg-white/5 border-white/5 hover:border-white/10' 
                                    : 'bg-gradient-to-r from-cyber-cyan/5 to-transparent border-cyber-cyan/30 shadow-[0_0_15px_rgba(0,243,255,0.05)] hover:border-cyber-cyan/50'
                                }`}
                            >
                                {!n.read && <div className="absolute top-4 right-4 w-2 h-2 bg-cyber-cyan rounded-full animate-pulse shadow-[0_0_5px_#00f3ff]"></div>}
                                
                                <div className="flex gap-4">
                                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 border ${
                                        n.read ? 'bg-black/40 border-white/10' : 'bg-black/60 border-cyber-cyan/30 shadow-inner'
                                    }`}>
                                        {getIcon(n.category)}
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <div className="flex justify-between items-baseline mb-1">
                                            <span className={`text-[10px] font-bold uppercase tracking-widest ${
                                                n.category === 'MISSION' ? 'text-cyber-yellow' : n.category === 'PERFORMANCE' ? 'text-green-400' : 'text-cyber-purple'
                                            }`}>
                                                {n.category}
                                            </span>
                                            <span className="text-[10px] text-slate-500 font-mono">{new Date(n.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                                        </div>
                                        <h3 className={`text-base font-bold mb-1 ${n.read ? 'text-slate-300' : 'text-white'}`}>{n.title}</h3>
                                        <p className="text-sm text-slate-400 leading-relaxed line-clamp-2 group-hover:text-slate-200 transition-colors">{n.body}</p>
                                    </div>
                                    <div className="flex items-center self-center opacity-0 group-hover:opacity-100 transition-opacity -translate-x-2 group-hover:translate-x-0">
                                        <ChevronRight size={20} className="text-cyber-cyan" />
                                    </div>
                                </div>
                            </div>
                        ))
                    )}
                </div>

                {/* External NTA News Section */}
                {news.length > 0 && (
                    <div className="border-t border-white/10 pt-8">
                        <h2 className="text-white font-bold text-sm uppercase tracking-widest mb-4 flex items-center gap-2">
                            <AlertCircle size={16} className="text-cyber-yellow" /> NTA Live Feed
                        </h2>
                        <div className="space-y-3">
                            {news.map(item => (
                                <div key={item.id} className="p-4 bg-black/40 rounded-xl border border-white/10 flex justify-between items-center hover:bg-white/5 transition-all">
                                    <div>
                                        <h4 className="text-white font-bold text-sm mb-1">{item.title}</h4>
                                        <div className="flex gap-2 text-[10px] text-slate-500">
                                            <span className="text-cyber-yellow">{item.source}</span>
                                            <span>•</span>
                                            <span>{item.date}</span>
                                        </div>
                                    </div>
                                    <button className="text-xs text-cyber-cyan hover:underline">View</button>
                                </div>
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};
