import React, { useEffect } from 'react';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, 4000); 
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 bg-[#020617] flex flex-col items-center justify-between py-16 px-6 overflow-hidden z-[100]">
        
        {/* Subtle Background Vignette */}
        <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_center,_transparent_0%,_#000000_90%)]"></div>
        
        {/* Central Glow behind Logo */}
        <div className="absolute top-[40%] left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] bg-blue-600/10 blur-[90px] rounded-full pointer-events-none"></div>

        <div className="flex-1 flex flex-col items-center justify-center w-full relative z-10">
            
            {/* Logo Container */}
            <div className="relative w-64 h-64 mb-10 flex items-center justify-center">
                
                {/* Custom SVG Logo */}
                <svg viewBox="0 0 200 220" className="w-full h-full" style={{ filter: 'drop-shadow(0 0 10px rgba(0, 243, 255, 0.3))' }}>
                    <defs>
                        {/* Gradient for the Book/Z */}
                        <linearGradient id="neonGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                            <stop offset="0%" stopColor="#ff003c" /> {/* Neon Pink */}
                            <stop offset="45%" stopColor="#d946ef" /> 
                            <stop offset="100%" stopColor="#00f3ff" /> {/* Neon Blue */}
                        </linearGradient>
                        
                        {/* Soft Glow Filter for Neon Tubes */}
                        <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
                            <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
                            <feMerge>
                                <feMergeNode in="coloredBlur"/>
                                <feMergeNode in="SourceGraphic"/>
                            </feMerge>
                        </filter>
                    </defs>

                    {/* Robot Head Group */}
                    <g filter="url(#glow)" stroke="#00f3ff" strokeWidth="3.5" fill="none" strokeLinecap="round" strokeLinejoin="round">
                        {/* Head Outline (Rounded) */}
                        <path d="M60 50 C 60 20, 140 20, 140 50 L 140 85 C 140 105, 60 105, 60 85 Z" />
                        
                        {/* Ears (Round Side Shapes) */}
                        <path d="M50 65 C 42 65, 42 80, 50 80" />
                        <path d="M150 65 C 158 65, 158 80, 150 80" />
                        
                        {/* Eyes (Filled Circles) */}
                        <circle cx="85" cy="65" r="6" fill="#00f3ff" stroke="none" />
                        <circle cx="115" cy="65" r="6" fill="#00f3ff" stroke="none" />
                    </g>

                    {/* Z and Book Group */}
                    <g filter="url(#glow)" strokeLinecap="round" strokeLinejoin="round">
                         
                         {/* Book Pages Outline */}
                         {/* Left Page (Pink Gradient Start) */}
                         <path d="M30 135 Q 65 155 100 145" stroke="#ff003c" strokeWidth="3.5" fill="none" />
                         <path d="M30 135 L 35 165 Q 70 185 100 175" stroke="#ff003c" strokeWidth="3.5" fill="none" />
                         
                         {/* Right Page (Blue Gradient End) */}
                         <path d="M170 135 Q 135 155 100 145" stroke="#00f3ff" strokeWidth="3.5" fill="none" />
                         <path d="M170 135 L 165 165 Q 130 185 100 175" stroke="#00f3ff" strokeWidth="3.5" fill="none" />

                         {/* The Z (Integrated into the book structure) */}
                         {/* Top bar of Z */}
                         <path d="M75 125 L 125 125" stroke="url(#neonGradient)" strokeWidth="5" fill="none" />
                         {/* Diagonal of Z */}
                         <path d="M125 125 L 75 175" stroke="url(#neonGradient)" strokeWidth="5" fill="none" />
                         {/* Bottom bar of Z */}
                         <path d="M75 175 L 125 175" stroke="url(#neonGradient)" strokeWidth="5" fill="none" />
                    </g>
                </svg>
            </div>

            {/* Title */}
            <h1 className="text-6xl font-display font-bold text-[#00f3ff] mb-3 tracking-wide drop-shadow-[0_0_15px_rgba(0,243,255,0.8)]">
                Zuaki
            </h1>

            {/* Subtitle */}
            <p className="text-[#00f3ff] font-sans text-lg font-medium tracking-wide drop-shadow-[0_0_8px_rgba(0,243,255,0.5)]">
                Your JEE Study Companion
            </p>
        </div>

        {/* Footer */}
        <div className="flex flex-col items-center gap-1 z-10 mb-6">
            <span className="text-[#00f3ff] font-sans font-light text-sm tracking-widest opacity-90 drop-shadow-[0_0_5px_rgba(0,243,255,0.4)]">
                from
            </span>
            <span className="text-[#00f3ff] font-display font-medium text-xl tracking-wider drop-shadow-[0_0_8px_rgba(0,243,255,0.6)]">
                Zubair and Akhil
            </span>
        </div>
    </div>
  );
};