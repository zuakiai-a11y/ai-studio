
import React, { useState, useRef, useEffect } from 'react';
import { Send, Mic, Plus, ArrowLeft, Paperclip, Radio, X, FileText, Image as ImageIcon } from 'lucide-react';
import { getGeminiResponse } from '../services/geminiService';
import { statsService } from '../services/statsService';
import { UserProfile } from '../types';
import { imagekit, vercel } from '../services/backend';

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  content: string;
  timestamp: Date;
  attachment?: string;
  type?: 'text' | 'image' | 'file';
}

const HISTORY_KEY = 'zuaki_ai_history';

interface GeminiAssistantProps {
    userProfile?: Partial<UserProfile>;
    onBack?: () => void;
}

export const GeminiAssistant: React.FC<GeminiAssistantProps> = ({ userProfile, onBack }) => {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  
  // NTA News State
  const [showNtaModal, setShowNtaModal] = useState(false);
  const [ntaNews, setNtaNews] = useState<any[]>([]);
  const [ntaLoading, setNtaLoading] = useState(false);

  // Refs
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);
  const pressTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Initialize Speech Recognition
  useEffect(() => {
      if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
          // @ts-ignore
          const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
          recognitionRef.current = new SpeechRecognition();
          recognitionRef.current.continuous = true;
          recognitionRef.current.interimResults = true;
          
          recognitionRef.current.onresult = (event: any) => {
              let transcript = '';
              for (let i = event.resultIndex; i < event.results.length; ++i) {
                  transcript += event.results[i][0].transcript;
              }
              setInput(prev => transcript); // Live update input
          };

          recognitionRef.current.onerror = (event: any) => {
              console.error("Speech Error", event.error);
              setIsRecording(false);
          };
      }
  }, []);

  // Load history
  useEffect(() => {
    const saved = localStorage.getItem(HISTORY_KEY);
    if (saved) {
      try {
          const parsed = JSON.parse(saved).map((m: any) => ({ ...m, timestamp: new Date(m.timestamp) }));
          setMessages(parsed);
      } catch(e) { console.error(e); }
    } else {
      setMessages([{ 
        id: 'init', role: 'model', 
        content: "Hi! I'm Zuaki. I can help with JEE concepts, solve doubts, or analyze files. Hold the mic to speak!", 
        timestamp: new Date() 
      }]);
    }
  }, []);

  useEffect(() => {
    if (messages.length > 0) localStorage.setItem(HISTORY_KEY, JSON.stringify(messages));
    scrollToBottom();
  }, [messages, loading]);

  const scrollToBottom = () => messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });

  // --- Voice Handlers ---
  const startRecording = () => {
      if (!recognitionRef.current) {
          alert("Voice input not supported in this browser.");
          return;
      }
      setIsRecording(true);
      try {
          recognitionRef.current.start();
      } catch(e) { console.log("Recognition already started"); }
  };

  const stopRecording = () => {
      if (isRecording && recognitionRef.current) {
          recognitionRef.current.stop();
          setIsRecording(false);
          // Auto send after short delay if input exists
          setTimeout(() => {
              if (input.trim()) handleSend();
          }, 500);
      }
  };

  const handleMouseDown = () => {
      pressTimerRef.current = setTimeout(() => {
          startRecording();
      }, 300); // 300ms threshold for long press
  };

  const handleMouseUp = () => {
      if (pressTimerRef.current) clearTimeout(pressTimerRef.current);
      stopRecording();
  };

  const handleSend = async () => {
    if ((!input.trim() && !isRecording) || loading) return;
    const userText = input.trim();
    if (!userText) return;
    
    setInput('');

    const newUserMsg: ChatMessage = { id: Date.now().toString(), role: 'user', content: userText, timestamp: new Date() };
    setMessages(prev => [...prev, newUserMsg]);
    setLoading(true);
    statsService.askAI();

    try {
        const history = messages.slice(-10).map(m => ({ role: m.role, parts: [{ text: m.content }] }));
        const responseText = await getGeminiResponse(userText, history);
        
        // Simulate Emoji Reaction & Rich Content
        const enrichedResponse = responseText + (Math.random() > 0.7 ? " 🚀" : "");
        
        setMessages(prev => [...prev, { id: (Date.now() + 1).toString(), role: 'model', content: enrichedResponse, timestamp: new Date() }]);
    } catch (error) {
        setMessages(prev => [...prev, { id: Date.now().toString(), role: 'model', content: "Offline mode. Check connection.", timestamp: new Date() }]);
    } finally {
        setLoading(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      
      const reader = new FileReader();
      reader.onloadend = async () => {
          const base64 = reader.result as string;
          const url = await imagekit.uploadFile(base64, file.name);
          
          setMessages(prev => [...prev, {
              id: Date.now().toString(),
              role: 'user',
              content: `Uploaded: ${file.name}`,
              attachment: url,
              type: file.type.startsWith('image') ? 'image' : 'file',
              timestamp: new Date()
          }]);
          
          setLoading(true);
          setTimeout(() => {
              setMessages(prev => [...prev, { id: Date.now().toString(), role: 'model', content: `I've analyzed ${file.name}. Ask me questions about it!`, timestamp: new Date() }]);
              setLoading(false);
          }, 1500);
      };
      reader.readAsDataURL(file);
  };

  const fetchNtaUpdates = async () => {
      setShowNtaModal(true);
      setNtaLoading(true);
      try {
          const newsData = await vercel.api.fetchNews();
          setNtaNews(newsData);
      } catch (error) {
          setNtaNews([{ id: 'err', title: 'Network Error', date: 'Now', link: '#', source: 'System' }]);
      } finally {
          setNtaLoading(false);
      }
  };

  return (
    <div className="flex flex-col h-full w-full bg-[#020617] relative">
      {/* Header */}
      <div className="h-16 px-4 flex items-center justify-between border-b border-white/5 bg-[#050818]/90 backdrop-blur-xl relative z-20">
        <div className="flex items-center gap-3">
            {onBack && <button onClick={onBack} className="text-slate-400 hover:text-white"><ArrowLeft size={20} /></button>}
            <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-cyber-purple flex items-center justify-center text-white font-bold text-xs shadow-[0_0_10px_#9d00ff] animate-pulse">Z</div>
                <h1 className="font-display font-bold text-white tracking-widest">ZUAKI</h1>
            </div>
        </div>
        <button onClick={fetchNtaUpdates} className="relative p-2 rounded-full bg-cyber-cyan/10 border border-cyber-cyan/30 text-cyber-cyan">
             <Radio size={18} />
             <span className="absolute top-0 right-0 w-2 h-2 bg-cyber-cyan rounded-full animate-pulse shadow-[0_0_5px_#00f3ff]"></span>
        </button>
      </div>

      {/* Chat Area */}
      <div className="flex-1 overflow-y-auto px-4 space-y-6 custom-scrollbar relative z-10 pb-40 pt-4">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex w-full ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] md:max-w-[70%] animate-in fade-in slide-in-from-bottom-2`}>
                {msg.role === 'model' && (
                    <div className="flex items-center gap-2 mb-2 pl-1">
                        <div className="w-5 h-5 rounded-full bg-cyber-purple flex items-center justify-center text-[10px] text-white font-bold">Z</div>
                        <span className="text-xs font-bold text-white/50">Zuaki</span>
                    </div>
                )}
                
                <div className={`p-4 rounded-2xl text-sm leading-relaxed shadow-lg backdrop-blur-md border ${
                    msg.role === 'user' 
                    ? 'bg-[#1e1e2e] border-white/10 text-white rounded-tr-none' 
                    : 'bg-transparent border-none text-slate-200 pl-0 pt-0'
                }`}>
                    {msg.attachment && (
                        <div className="mb-2 p-2 bg-black/30 rounded border border-white/10 flex items-center gap-2">
                            {msg.type === 'image' ? <ImageIcon size={14}/> : <FileText size={14}/>}
                            <span className="text-xs truncate max-w-[150px]">Attachment</span>
                        </div>
                    )}
                    <div className="whitespace-pre-wrap">{msg.content}</div>
                </div>
            </div>
          </div>
        ))}
        {loading && (
             <div className="flex justify-start w-full px-4">
                 <div className="flex items-center gap-2">
                     <div className="w-5 h-5 rounded-full bg-cyber-purple flex items-center justify-center text-[10px] text-white font-bold animate-bounce">Z</div>
                     <span className="text-xs text-slate-500 animate-pulse">Processing...</span>
                 </div>
             </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Bar (Perplexity Style - Floating) */}
      <div className="absolute bottom-[90px] md:bottom-6 left-0 right-0 px-4 flex justify-center z-30">
          <div className={`w-full max-w-2xl bg-[#0b0f1a] border rounded-[32px] p-2 flex items-center shadow-2xl backdrop-blur-xl ring-1 ring-white/5 transition-all duration-300 ${isRecording ? 'border-cyber-cyan shadow-[0_0_30px_#00f3ff]' : 'border-white/10'}`}>
              <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" />
              <button onClick={() => fileInputRef.current?.click()} className="p-3 rounded-full text-slate-400 hover:text-white hover:bg-white/5 transition-colors">
                  <Plus size={20} />
              </button>
              
              {isRecording ? (
                  <div className="flex-1 h-12 flex items-center px-4 text-cyber-cyan font-mono animate-pulse">
                      Listening...
                  </div>
              ) : (
                  <textarea
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyDown={(e) => { if(e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                      placeholder="Ask anything..."
                      className="flex-1 bg-transparent border-none outline-none text-white placeholder-slate-500 px-2 py-3 h-12 max-h-32 resize-none custom-scrollbar font-sans text-sm"
                  />
              )}

              <div className="flex items-center gap-1 pr-1">
                  <button 
                    onMouseDown={handleMouseDown}
                    onMouseUp={handleMouseUp}
                    onTouchStart={handleMouseDown}
                    onTouchEnd={handleMouseUp}
                    className={`p-3 rounded-full transition-all duration-300 ${isRecording ? 'bg-cyber-cyan text-black scale-110 shadow-[0_0_15px_#00f3ff]' : 'text-slate-400 hover:text-white'}`}
                  >
                      {isRecording ? (
                          <div className="w-5 h-5 flex items-center justify-center space-x-1">
                              <div className="w-1 h-3 bg-black animate-[bounce_1s_infinite]"></div>
                              <div className="w-1 h-5 bg-black animate-[bounce_1s_infinite_0.2s]"></div>
                              <div className="w-1 h-3 bg-black animate-[bounce_1s_infinite_0.4s]"></div>
                          </div>
                      ) : (
                          <Mic size={18} />
                      )}
                  </button>
                  <button 
                    onClick={handleSend}
                    disabled={!input.trim() || loading}
                    className={`p-2 rounded-full transition-all ${input.trim() ? 'bg-cyber-purple text-white hover:scale-105 shadow-[0_0_15px_#9d00ff]' : 'bg-white/5 text-slate-600'}`}
                  >
                      <ArrowLeft size={18} className={input.trim() ? "rotate-90" : "rotate-90"} />
                  </button>
              </div>
          </div>
      </div>

      {/* Ripple Animation Overlay for Voice */}
      {isRecording && (
          <div className="absolute bottom-[90px] left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-cyber-cyan/5 rounded-full blur-3xl pointer-events-none animate-pulse"></div>
      )}

      {/* NTA Modal */}
      {showNtaModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
              <div className="w-full max-w-md bg-[#0b0f1a] border border-cyber-cyan/30 rounded-2xl p-6 shadow-2xl relative max-h-[80vh] flex flex-col">
                  <div className="flex justify-between items-center mb-4">
                      <h2 className="text-lg font-bold text-white flex items-center gap-2"><Radio size={18} className="text-cyber-cyan" /> NTA Live Feed</h2>
                      <button onClick={() => setShowNtaModal(false)}><X size={20} className="text-slate-400" /></button>
                  </div>
                  <div className="flex-1 overflow-y-auto space-y-3 custom-scrollbar">
                      {ntaLoading ? <div className="text-center py-4 text-slate-500 text-xs">Fetching...</div> : ntaNews.map((item, i) => (
                          <div key={i} className="p-3 bg-white/5 rounded-xl border border-white/10">
                              <h3 className="text-sm font-bold text-white mb-1">{item.title}</h3>
                              <div className="flex justify-between text-[10px] text-slate-400">
                                  <span>{item.date}</span>
                                  <span className="text-cyber-cyan">{item.source}</span>
                              </div>
                          </div>
                      ))}
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};
