
import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Star, ChevronLeft, ChevronRight, CheckCircle, Zap, BookOpen, Filter } from 'lucide-react';
import { FormulaTopic, FormulaCard } from '../types';
import { JEE_FORMULA_DATA } from '../data/flashcardData';

interface Props {
    onBack: () => void;
}

export const FormulaFlashcards: React.FC<Props> = ({ onBack }) => {
    // State: View Mode (HOME or VIEWER)
    const [activeTopic, setActiveTopic] = useState<FormulaTopic | null>(null);
    const [data, setData] = useState<FormulaTopic[]>([]);
    const [filterSubject, setFilterSubject] = useState<'All' | 'Physics' | 'Chemistry' | 'Maths'>('All');

    // Load initial data (simulate fetching)
    useEffect(() => {
        // In real app, load mastery state from localStorage here and merge
        const stored = localStorage.getItem('zuaki_flashcard_progress');
        if (stored) {
            const progress = JSON.parse(stored);
            // Merge progress into base data
            const merged = JEE_FORMULA_DATA.map(topic => ({
                ...topic,
                cards: topic.cards.map(card => ({
                    ...card,
                    ...(progress[card.id] || {})
                }))
            }));
            setData(merged);
        } else {
            setData(JEE_FORMULA_DATA);
        }
    }, []);

    // Save Progress
    const saveProgress = (updatedData: FormulaTopic[]) => {
        const progress: Record<string, any> = {};
        updatedData.forEach(t => {
            t.cards.forEach(c => {
                if (c.mastered || c.starred) {
                    progress[c.id] = { mastered: c.mastered, starred: c.starred };
                }
            });
        });
        localStorage.setItem('zuaki_flashcard_progress', JSON.stringify(progress));
        setData(updatedData);
    };

    if (activeTopic) {
        return (
            <FlashcardViewer 
                topic={activeTopic} 
                onClose={() => setActiveTopic(null)} 
                onUpdate={(updatedTopic) => {
                    const newData = data.map(t => t.id === updatedTopic.id ? updatedTopic : t);
                    saveProgress(newData);
                    // Update active topic reference to prevent stale state
                    setActiveTopic(updatedTopic); 
                }}
            />
        );
    }

    // --- HOME SCREEN (LIBRARY) ---
    const filteredData = data.filter(t => filterSubject === 'All' || t.subject === filterSubject);

    return (
        <div className="h-full w-full bg-slate-50 flex flex-col relative overflow-hidden">
            {/* Header */}
            <div className="px-6 py-6 bg-white border-b border-slate-200 shadow-sm flex items-center justify-between z-10">
                <div className="flex items-center gap-3">
                    <button onClick={onBack} className="p-2 rounded-full hover:bg-slate-100 text-slate-600 transition-colors">
                        <ArrowLeft size={20} />
                    </button>
                    <div>
                        <h1 className="text-xl font-display font-bold text-slate-800 uppercase tracking-wide">Formula Flashcards</h1>
                        <p className="text-slate-500 text-xs">Official JEE Syllabus</p>
                    </div>
                </div>
                <div className="flex gap-2">
                    {['P', 'C', 'M'].map(sub => (
                        <button 
                            key={sub}
                            onClick={() => setFilterSubject(sub === 'P' ? 'Physics' : sub === 'C' ? 'Chemistry' : 'Maths')}
                            className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                                (sub === 'P' && filterSubject === 'Physics') || (sub === 'C' && filterSubject === 'Chemistry') || (sub === 'M' && filterSubject === 'Maths')
                                ? 'bg-indigo-600 text-white shadow-lg' 
                                : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                            }`}
                        >
                            {sub}
                        </button>
                    ))}
                    <button onClick={() => setFilterSubject('All')} className={`px-3 h-8 rounded-full text-xs font-bold ${filterSubject === 'All' ? 'bg-slate-800 text-white' : 'bg-slate-100 text-slate-500'}`}>
                        All
                    </button>
                </div>
            </div>

            {/* Grid Content */}
            <div className="flex-1 overflow-y-auto custom-scrollbar p-6">
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {filteredData.map(topic => (
                        <div 
                            key={topic.id}
                            onClick={() => setActiveTopic(topic)}
                            className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100 hover:shadow-md transition-all cursor-pointer group relative overflow-hidden flex flex-col h-48"
                        >
                            {/* Abstract PDF Thumbnail */}
                            <div className="w-full h-24 bg-slate-100 rounded-lg mb-3 relative overflow-hidden border border-slate-200 flex items-center justify-center">
                                <div className="w-12 h-16 bg-white shadow-sm border border-slate-200 flex flex-col gap-1 p-1 items-center">
                                    <div className="w-full h-1 bg-slate-200"></div>
                                    <div className="w-full h-1 bg-slate-200"></div>
                                    <div className="w-2/3 h-1 bg-slate-200"></div>
                                    <div className="mt-auto w-4 h-4 rounded-full bg-slate-100"></div>
                                </div>
                                {/* Subject Badge */}
                                <div className={`absolute top-2 right-2 px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-wider text-white ${
                                    topic.subject === 'Physics' ? 'bg-cyan-500' : topic.subject === 'Chemistry' ? 'bg-purple-500' : 'bg-pink-500'
                                }`}>
                                    {topic.subject.substring(0,3)}
                                </div>
                            </div>

                            <div className="flex-1 flex flex-col justify-between">
                                <div>
                                    <h3 className="font-bold text-slate-800 text-sm line-clamp-2 leading-tight">{topic.topic}</h3>
                                    <p className="text-[10px] text-slate-400 mt-1 truncate">{topic.chapter}</p>
                                </div>
                                <div className="flex justify-between items-end border-b-2 border-transparent group-hover:border-cyber-purple transition-all pb-1">
                                    <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">{topic.cards.length} Cards</span>
                                    <div className="w-2 h-2 rounded-full bg-cyber-purple opacity-0 group-hover:opacity-100 transition-opacity shadow-[0_0_5px_#9d00ff]"></div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

// --- VIEWER SUB-COMPONENT ---

interface ViewerProps {
    topic: FormulaTopic;
    onClose: () => void;
    onUpdate: (topic: FormulaTopic) => void;
}

const FlashcardViewer: React.FC<ViewerProps> = ({ topic, onClose, onUpdate }) => {
    const [currentIndex, setCurrentIndex] = useState(0);
    const [isFlipped, setIsFlipped] = useState(false);
    const touchStart = useRef<number | null>(null);
    const touchEnd = useRef<number | null>(null);

    const currentCard = topic.cards[currentIndex];

    // Navigation
    const nextCard = () => {
        setIsFlipped(false);
        if (currentIndex < topic.cards.length - 1) {
            setTimeout(() => setCurrentIndex(prev => prev + 1), 150);
        }
    };

    const prevCard = () => {
        setIsFlipped(false);
        if (currentIndex > 0) {
            setTimeout(() => setCurrentIndex(prev => prev - 1), 150);
        }
    };

    // Actions
    const toggleMastered = (e: React.MouseEvent) => {
        e.stopPropagation();
        const updatedCards = [...topic.cards];
        updatedCards[currentIndex] = { ...currentCard, mastered: !currentCard.mastered };
        onUpdate({ ...topic, cards: updatedCards });
    };

    const toggleStar = (e: React.MouseEvent) => {
        e.stopPropagation();
        const updatedCards = [...topic.cards];
        updatedCards[currentIndex] = { ...currentCard, starred: !currentCard.starred };
        onUpdate({ ...topic, cards: updatedCards });
    };

    // Swipe Handling
    const handleTouchStart = (e: React.TouchEvent) => { touchStart.current = e.targetTouches[0].clientX; };
    const handleTouchMove = (e: React.TouchEvent) => { touchEnd.current = e.targetTouches[0].clientX; };
    const handleTouchEnd = () => {
        if (!touchStart.current || !touchEnd.current) return;
        const distance = touchStart.current - touchEnd.current;
        const isLeftSwipe = distance > 50;
        const isRightSwipe = distance < -50;

        if (isLeftSwipe && currentIndex < topic.cards.length - 1) nextCard();
        if (isRightSwipe && currentIndex > 0) prevCard();
        
        touchStart.current = null;
        touchEnd.current = null;
    };

    return (
        <div className="fixed inset-0 bg-[#020617] flex flex-col z-50">
            {/* Header */}
            <div className="h-16 px-6 flex items-center justify-between border-b border-white/10 bg-[#0b0f1a]">
                <button onClick={onClose} className="text-slate-400 hover:text-white flex items-center gap-2">
                    <ArrowLeft size={18} /> <span className="text-xs uppercase font-bold tracking-widest">Library</span>
                </button>
                <div className="text-center">
                    <h2 className="text-white font-bold text-sm">{topic.topic}</h2>
                    <p className="text-[10px] text-cyber-cyan font-mono">Card {currentIndex + 1} of {topic.cards.length}</p>
                </div>
                <div className="w-16"></div> {/* Spacer */}
            </div>

            {/* Card Container */}
            <div 
                className="flex-1 flex items-center justify-center p-6 perspective-1000 overflow-hidden"
                onTouchStart={handleTouchStart}
                onTouchMove={handleTouchMove}
                onTouchEnd={handleTouchEnd}
            >
                <div 
                    onClick={() => setIsFlipped(!isFlipped)}
                    className={`relative w-full max-w-md aspect-[3/4] transition-transform duration-500 transform-style-3d cursor-pointer ${isFlipped ? 'rotate-y-180' : ''}`}
                    style={{ transformStyle: 'preserve-3d', transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)' }}
                >
                    {/* FRONT */}
                    <div className="absolute inset-0 backface-hidden bg-[#0b0f1a] border border-cyber-cyan/30 rounded-3xl p-8 flex flex-col items-center justify-center text-center shadow-[0_0_40px_rgba(0,243,255,0.1)]">
                        <div className="absolute top-6 left-6 text-cyber-cyan opacity-50"><Zap size={24} /></div>
                        {currentCard.starred && <div className="absolute top-6 right-6 text-cyber-yellow"><Star size={24} fill="currentColor"/></div>}
                        
                        <h3 className="text-3xl font-display font-bold text-white leading-snug">{currentCard.front}</h3>
                        <p className="text-slate-500 text-xs mt-8 font-mono animate-pulse uppercase tracking-widest">Tap to Flip</p>
                    </div>

                    {/* BACK */}
                    <div 
                        className="absolute inset-0 backface-hidden bg-[#0b0f1a] border border-cyber-purple/30 rounded-3xl p-8 flex flex-col items-center justify-center text-center shadow-[0_0_40px_rgba(157,0,255,0.1)]"
                        style={{ transform: 'rotateY(180deg)' }}
                    >
                        <div className="mb-6 p-4 bg-white/5 rounded-xl border border-white/10 w-full">
                            <p className="text-2xl font-mono text-cyber-purple font-bold">{currentCard.back}</p>
                        </div>
                        <p className="text-slate-300 text-sm leading-relaxed mb-4">{currentCard.explanation}</p>
                        {currentCard.example && (
                            <div className="text-xs text-slate-400 border-t border-white/10 pt-4 mt-2 w-full">
                                <strong className="text-cyber-pink block mb-1">Example:</strong> {currentCard.example}
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Controls */}
            <div className="h-24 px-6 pb-6 pt-2 flex items-center justify-center gap-6">
                <button 
                    onClick={prevCard} 
                    disabled={currentIndex === 0}
                    className="w-14 h-14 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white disabled:opacity-30 hover:bg-white/10 transition-all active:scale-95"
                >
                    <ChevronLeft size={24} />
                </button>

                <button 
                    onClick={toggleStar}
                    className={`w-16 h-16 rounded-2xl flex items-center justify-center border transition-all active:scale-95 ${currentCard.starred ? 'bg-cyber-yellow/20 border-cyber-yellow text-cyber-yellow shadow-[0_0_20px_rgba(252,238,10,0.3)]' : 'bg-white/5 border-white/10 text-slate-400'}`}
                >
                    <Star size={28} fill={currentCard.starred ? "currentColor" : "none"} />
                </button>

                <button 
                    onClick={toggleMastered}
                    className={`w-16 h-16 rounded-2xl flex items-center justify-center border transition-all active:scale-95 ${currentCard.mastered ? 'bg-green-500 text-black border-green-500 shadow-[0_0_20px_rgba(34,197,94,0.5)]' : 'bg-white/5 border-white/10 text-slate-400'}`}
                >
                    <CheckCircle size={28} />
                </button>

                <button 
                    onClick={nextCard} 
                    disabled={currentIndex === topic.cards.length - 1}
                    className="w-14 h-14 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-white disabled:opacity-30 hover:bg-white/10 transition-all active:scale-95"
                >
                    <ChevronRight size={24} />
                </button>
            </div>
        </div>
    );
};
