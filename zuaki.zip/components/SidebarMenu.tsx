
import React, { useState, useEffect } from 'react';
import { 
  Home, MessageSquare, Bot, Calendar, ClipboardList, PenTool, Users, 
  Target, FileText, Brain, Trophy, BarChart2, Calculator, 
  TrendingUp, Bell, Settings, LogOut, Search, X, ChevronRight, Menu,
  Info, Mail, MessageSquarePlus, Award, ClipboardCheck, Swords, Youtube, Music, BookOpen, Library, Beaker, StickyNote, Zap, Clock
} from 'lucide-react';
import { ViewState, UserProfile } from '../types';
import { timerService } from '../services/timerService';

interface SidebarMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onChangeView: (view: ViewState) => void;
  userProfile?: Partial<UserProfile>;
}

export const SidebarMenu: React.FC<SidebarMenuProps> = ({ isOpen, onClose, onChangeView, userProfile }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isTimerLive, setIsTimerLive] = useState(false);

  // Subscribe to Timer Service
  useEffect(() => {
      const unsub = timerService.subscribe((state) => {
          setIsTimerLive(state.isActive);
      });
      return () => { unsub(); };
  }, []);

  const menuItems = [
    { id: ViewState.DASHBOARD, icon: Home, label: 'Home' },
    { id: ViewState.CHAT, icon: MessageSquare, label: 'Chats' },
    { id: ViewState.AI_ASSISTANT, icon: Bot, label: 'GenZ AI Assistant' },
    { id: ViewState.PLANNER, icon: Calendar, label: 'Planner & Schedule' },
    { id: ViewState.STUDY_HUB, icon: Users, label: 'Study Hub' },
    
    // Notes & Content
    { id: ViewState.SHORT_NOTES, icon: FileText, label: 'Short Notes' }, // NEW
    { id: ViewState.STRENGTH_NOTES, icon: StickyNote, label: 'Zuaki Strength Notes' },

    // Test Engine
    { id: ViewState.TEST_LAB_HOME, icon: Beaker, label: 'Zuaki Test Lab' }, 
    { id: ViewState.MAKE_TEST, icon: ClipboardCheck, label: 'Custom Test' },
    { id: ViewState.PYQ_PAPERS, icon: BookOpen, label: 'PYQ Papers' },
    { id: ViewState.QUIZ_CHALLENGE, icon: Swords, label: 'Quiz Challenge' },
    
    // Resources
    { id: ViewState.FORMULA_FLASHCARDS, icon: Zap, label: 'Formula Flashcards' },
    { id: ViewState.FORMULA_VAULT, icon: Library, label: 'Formula Vault' },
    { id: ViewState.ZUKAI_TUBE, icon: Youtube, label: 'ZukaiTube' },
    { id: ViewState.MOTIVATION, icon: Music, label: 'Motivational Zone' },

    { id: ViewState.TASKS, icon: ClipboardList, label: 'To-Do List' },
    { id: ViewState.WHITEBOARD, icon: PenTool, label: 'Whiteboard' },
    { id: ViewState.DAILY_FOCUS, icon: Target, label: 'Daily Focus Mode' },
    { id: ViewState.QUIZ_GENERATOR, icon: Brain, label: 'Quick Quiz' },
    { id: ViewState.LEADERBOARD, icon: Trophy, label: 'Leaderboard' },
    { id: ViewState.ACHIEVEMENTS, icon: Award, label: 'Achievements' }, 
    { id: ViewState.ANALYSIS, icon: BarChart2, label: 'Analysis' },
    { id: ViewState.CALCULATOR, icon: Calculator, label: 'Calculator' },
    { id: ViewState.RANK_PREDICTOR, icon: TrendingUp, label: 'Rank Predictor' },
    { id: ViewState.NOTIFICATIONS, icon: Bell, label: 'Notifications' },
    { id: ViewState.SETTINGS, icon: Settings, label: 'Settings' },
    
    { id: ViewState.ABOUT_US, icon: Info, label: 'About Us' },
    { id: ViewState.CONTACT_US, icon: Mail, label: 'Contact Us' },
    { id: ViewState.FEEDBACK, icon: MessageSquarePlus, label: 'Feedback' },
    
    // NEW: Neo Timer (Added at bottom of features as requested)
    { id: ViewState.NEO_TIMER, icon: Clock, label: 'Zuaki Neo Timer' },
  ];

  const filteredItems = menuItems.filter(item => 
    item.label.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleNavigate = (view: ViewState) => {
    onChangeView(view);
    onClose();
  };

  return (
    <>
      {/* Backdrop */}
      <div 
        className={`fixed inset-0 bg-black/60 backdrop-blur-sm z-[60] transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
      ></div>

      {/* Sidebar Drawer */}
      <div className={`fixed top-0 left-0 h-full w-[300px] bg-gradient-to-b from-[#05061A] to-[#0B0720] border-r border-white/10 z-[70] shadow-[0_0_50px_rgba(0,0,0,0.5)] transform transition-transform duration-300 flex flex-col ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        
        {/* Glow Border */}
        <div className="absolute top-0 right-0 w-[1px] h-full bg-gradient-to-b from-cyber-cyan via-cyber-purple to-cyber-pink opacity-50"></div>

        {/* Header */}
        <div className="p-6 pb-2">
            <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-display font-bold text-white tracking-widest">ZUAKI</h2>
                <button onClick={onClose} className="p-2 rounded-full hover:bg-white/10 text-slate-400 hover:text-white transition-colors">
                    <X size={20} />
                </button>
            </div>

            {/* Profile Snippet */}
            <div className="flex items-center gap-3 p-3 rounded-xl bg-white/5 border border-white/5 mb-4">
                <div className="relative">
                    <img src={userProfile?.avatar || "https://ui-avatars.com/api/?name=User&background=00f3ff&color=000"} alt="User" className="w-10 h-10 rounded-full border border-cyber-cyan/50 object-cover" />
                    <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-cyber-cyan rounded-full border border-black shadow-[0_0_5px_#00f3ff]"></div>
                </div>
                <div className="flex-1 min-w-0">
                    <h3 className="text-white font-bold text-sm truncate">{userProfile?.name}</h3>
                    <p className="text-cyber-purple text-[10px] font-mono tracking-wider truncate">{userProfile?.userId}</p>
                </div>
            </div>

            {/* Search */}
            <div className="relative group">
                <Search className="absolute left-3 top-2.5 text-slate-500 group-focus-within:text-cyber-cyan transition-colors" size={16} />
                <input 
                    type="text" 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search features..." 
                    className="w-full bg-black/30 border border-white/10 rounded-full py-2 pl-10 pr-4 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-cyber-cyan/50 focus:shadow-[0_0_15px_rgba(0,243,255,0.1)] transition-all font-sans"
                />
            </div>
        </div>

        {/* Menu Items */}
        <div className="flex-1 overflow-y-auto custom-scrollbar px-4 pb-4 space-y-1">
            {filteredItems.map((item) => {
                const isTimer = item.id === ViewState.NEO_TIMER;
                const isLive = isTimer && isTimerLive;

                return (
                    <button
                        key={item.id}
                        onClick={() => handleNavigate(item.id)}
                        className={`w-full flex items-center justify-between p-3 rounded-xl hover:bg-white/5 border border-transparent hover:pl-4 transition-all duration-300 group ${isLive ? 'bg-green-900/20 border-green-500/30' : ''}`}
                    >
                        <div className="flex items-center gap-3 relative">
                            <item.icon size={18} className={`transition-colors ${isLive ? 'text-green-400 animate-pulse' : 'text-slate-400 group-hover:text-cyber-cyan'}`} />
                            <span className={`text-xs font-medium tracking-wide ${isLive ? 'text-green-400 font-bold' : 'text-slate-400 group-hover:text-white'}`}>
                                {item.label}
                            </span>
                            {isLive && (
                                <span className="absolute -top-1 -right-8 flex h-2 w-2">
                                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                                    <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                                </span>
                            )}
                        </div>
                        <ChevronRight size={14} className="text-white/0 group-hover:text-white/30 transition-all -translate-x-2 group-hover:translate-x-0" />
                    </button>
                );
            })}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/5 bg-black/20 backdrop-blur-sm">
             <button onClick={() => { onChangeView(ViewState.LOGIN); onClose(); }} className="w-full flex items-center gap-3 p-3 rounded-xl text-slate-400 hover:text-cyber-pink hover:bg-cyber-pink/10 transition-all">
                <LogOut size={18} />
                <span className="text-xs font-bold uppercase tracking-widest">Logout</span>
             </button>
        </div>

      </div>
    </>
  );
};
