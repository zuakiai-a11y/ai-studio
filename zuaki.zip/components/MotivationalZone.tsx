
import React from 'react';
import { Music, Play, Zap } from 'lucide-react';

export const MotivationalZone: React.FC = () => {
    const items = [
        { title: "Study With Me - 4 Hours", category: "Focus", thumbnail: "https://picsum.photos/300/200?random=10" },
        { title: "Unstoppable Motivation Speech", category: "Speech", thumbnail: "https://picsum.photos/300/200?random=11" },
        { title: "Lofi Beats for Deep Work", category: "Music", thumbnail: "https://picsum.photos/300/200?random=12" },
        { title: "You Can Do It - JEE Special", category: "Motivation", thumbnail: "https://picsum.photos/300/200?random=13" },
    ];

    return (
        <div className="h-full w-full bg-[#020617] p-6 overflow-y-auto custom-scrollbar">
            <div className="max-w-5xl mx-auto">
                <div className="flex items-center gap-4 mb-8">
                    <div className="w-12 h-12 rounded-full bg-cyber-yellow/20 flex items-center justify-center text-cyber-yellow">
                        <Zap size={24} fill="currentColor" />
                    </div>
                    <h1 className="text-3xl font-display font-bold text-white uppercase tracking-widest">Motivational Zone</h1>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {items.map((item, i) => (
                        <div key={i} className="glass-panel p-4 rounded-2xl border border-white/10 flex gap-4 items-center hover:bg-white/5 transition-all cursor-pointer group">
                            <div className="w-32 h-20 rounded-lg overflow-hidden relative shrink-0">
                                <img src={item.thumbnail} className="w-full h-full object-cover" />
                                <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                    <Play size={24} className="text-white fill-current" />
                                </div>
                            </div>
                            <div>
                                <span className="text-[10px] text-cyber-yellow uppercase tracking-widest">{item.category}</span>
                                <h3 className="text-white font-bold">{item.title}</h3>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};
