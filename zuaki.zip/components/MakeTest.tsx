
import React, { useState, useEffect } from 'react';
import { ArrowLeft, Clock, AlertTriangle, CheckCircle, BarChart2, Share2, Play, ChevronRight, Check } from 'lucide-react';
import { ViewState } from '../types';

interface MakeTestProps {
    onBack?: () => void;
    onChallenge?: (code: string) => void;
}

const CHAPTERS = {
    Physics: ['Kinematics', 'Laws of Motion', 'Work Energy Power', 'Rotational Motion', 'Gravitation', 'Thermodynamics', 'Electrostatics', 'Optics'],
    Chemistry: ['Atomic Structure', 'Chemical Bonding', 'Thermodynamics', 'Equilibrium', 'GOC', 'Hydrocarbons', 'Solutions', 'Electrochemistry'],
    Maths: ['Sets & Relations', 'Quadratic Equations', 'Complex Numbers', 'Permutations & Combinations', 'Binomial Theorem', 'Calculus', 'Vectors', 'Probability']
};

export const MakeTest: React.FC<MakeTestProps> = ({ onBack, onChallenge }) => {
    const [step, setStep] = useState<'SETUP' | 'TAKING' | 'ANALYSIS'>('SETUP');
    const [config, setConfig] = useState({ subject: 'Physics', chapter: '', count: 10, time: 30 });
    const [timeLeft, setTimeLeft] = useState(0);
    const [answers, setAnswers] = useState<Record<number, number>>({});
    const [submitted, setSubmitted] = useState(false);

    // Mock Questions Data
    const questions = Array.from({ length: config.count }).map((_, i) => ({
        id: i + 1,
        text: `Sample Question ${i + 1} regarding ${config.chapter || config.subject} concepts. Calculate the net value if X = ${i * 5}?`,
        options: ['45', '90', '120', 'Zero'],
        correct: 1 // Always B for mock
    }));

    useEffect(() => {
        let timer: any;
        if (step === 'TAKING' && timeLeft > 0 && !submitted) {
            timer = setInterval(() => setTimeLeft(p => p - 1), 1000);
        } else if (timeLeft === 0 && step === 'TAKING') {
            handleSubmit();
        }
        return () => clearInterval(timer);
    }, [timeLeft, step, submitted]);

    const startTest = () => {
        if (!config.chapter) return;
        setTimeLeft(config.time * 60);
        setStep('TAKING');
    };

    const handleSubmit = () => {
        setSubmitted(true);
        setStep('ANALYSIS');
    };

    const calculateScore = () => {
        let score = 0;
        let correct = 0;
        let wrong = 0;
        Object.entries(answers).forEach(([qId, ansIdx]) => {
            if (questions[Number(qId) - 1].correct === ansIdx) {
                score += 4;
                correct++;
            } else {
                score -= 1;
                wrong++;
            }
        });
        return { score, correct, wrong, skipped: config.count - (correct + wrong) };
    };

    const results = calculateScore();

    return (
        <div className="h-full w-full bg-[#020617] flex flex-col overflow-hidden relative">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_#0f172a_0%,_#020617_70%)]"></div>

            {/* SETUP STEP */}
            {step === 'SETUP' && (
                <div className="flex-1 overflow-y-auto custom-scrollbar p-6 relative z-10">
                    <div className="flex items-center gap-4 mb-8">
                        {onBack && <button onClick={onBack} className="p-2 rounded-full hover:bg-white/10 text-white"><ArrowLeft size={20} /></button>}
                        <h1 className="text-3xl font-display font-bold text-white tracking-widest uppercase">Custom Test</h1>
                    </div>

                    <div className="max-w-2xl mx-auto space-y-8">
                        {/* Subject Selection */}
                        <div className="glass-panel p-6 rounded-2xl border border-white/10">
                            <h3 className="text-cyber-cyan font-bold text-sm uppercase tracking-widest mb-4">1. Select Subject</h3>
                            <div className="flex gap-4">
                                {Object.keys(CHAPTERS).map(sub => (
                                    <button 
                                        key={sub}
                                        onClick={() => setConfig({ ...config, subject: sub, chapter: '' })}
                                        className={`flex-1 py-4 rounded-xl font-bold border transition-all ${config.subject === sub ? 'bg-cyber-cyan text-black border-cyber-cyan shadow-[0_0_15px_#00f3ff]' : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'}`}
                                    >
                                        {sub}
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Chapter Selection */}
                        <div className="glass-panel p-6 rounded-2xl border border-white/10">
                            <h3 className="text-cyber-purple font-bold text-sm uppercase tracking-widest mb-4">2. Select Chapter</h3>
                            <div className="grid grid-cols-2 gap-3">
                                {CHAPTERS[config.subject as keyof typeof CHAPTERS].map(chap => (
                                    <button 
                                        key={chap}
                                        onClick={() => setConfig({ ...config, chapter: chap })}
                                        className={`p-3 rounded-lg text-left text-sm border transition-all ${config.chapter === chap ? 'bg-cyber-purple/20 border-cyber-purple text-white' : 'bg-white/5 border-transparent text-slate-400 hover:border-white/20'}`}
                                    >
                                        {chap}
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* Config */}
                        <div className="glass-panel p-6 rounded-2xl border border-white/10">
                            <h3 className="text-cyber-pink font-bold text-sm uppercase tracking-widest mb-4">3. Test Parameters</h3>
                            <div className="grid grid-cols-2 gap-6">
                                <div>
                                    <label className="text-xs text-slate-400 mb-2 block">Questions</label>
                                    <div className="flex gap-2">
                                        {[10, 20, 30, 50].map(n => (
                                            <button 
                                                key={n} 
                                                onClick={() => setConfig({ ...config, count: n })}
                                                className={`flex-1 py-2 rounded-lg border text-sm font-mono ${config.count === n ? 'bg-cyber-pink text-white border-cyber-pink' : 'bg-white/5 border-white/10 text-slate-500'}`}
                                            >
                                                {n}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                                <div>
                                    <label className="text-xs text-slate-400 mb-2 block">Time (Minutes)</label>
                                    <input 
                                        type="number" 
                                        value={config.time} 
                                        onChange={(e) => setConfig({ ...config, time: Number(e.target.value) })}
                                        className="w-full bg-black/40 border border-white/10 rounded-lg p-2 text-white font-mono text-center focus:border-cyber-pink outline-none"
                                    />
                                </div>
                            </div>
                        </div>

                        <button 
                            onClick={startTest}
                            disabled={!config.chapter}
                            className="w-full py-5 bg-gradient-to-r from-cyber-cyan to-cyber-purple rounded-xl font-display font-bold text-xl uppercase tracking-widest text-white shadow-[0_0_30px_rgba(0,243,255,0.3)] hover:shadow-[0_0_50px_rgba(0,243,255,0.5)] transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3"
                        >
                            Start Test <Play fill="currentColor" />
                        </button>
                    </div>
                </div>
            )}

            {/* TAKING STEP */}
            {step === 'TAKING' && (
                <div className="flex-1 flex flex-col relative z-10">
                    {/* Header */}
                    <div className="h-16 border-b border-white/10 bg-black/40 backdrop-blur-md flex items-center justify-between px-6">
                        <div>
                            <h2 className="text-white font-bold">{config.subject} Test</h2>
                            <p className="text-slate-400 text-xs">{config.chapter}</p>
                        </div>
                        <div className={`px-4 py-2 rounded-full border flex items-center gap-2 font-mono font-bold ${timeLeft < 60 ? 'bg-red-500/20 border-red-500 text-red-500 animate-pulse' : 'bg-white/5 border-white/10 text-cyber-cyan'}`}>
                            <Clock size={16} />
                            {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}
                        </div>
                        <button onClick={handleSubmit} className="px-6 py-2 bg-green-500 text-black font-bold rounded-lg hover:bg-green-400 transition-colors">
                            Submit
                        </button>
                    </div>

                    {/* Question Area */}
                    <div className="flex-1 overflow-y-auto custom-scrollbar p-6">
                        <div className="max-w-3xl mx-auto space-y-8">
                            {questions.map((q, idx) => (
                                <div key={q.id} className="glass-panel p-6 rounded-2xl border border-white/10">
                                    <div className="flex gap-4 mb-4">
                                        <div className="w-8 h-8 rounded-full bg-cyber-purple/20 border border-cyber-purple flex items-center justify-center text-cyber-purple font-bold shrink-0">
                                            {idx + 1}
                                        </div>
                                        <p className="text-lg text-white font-medium leading-relaxed">{q.text}</p>
                                    </div>
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pl-12">
                                        {q.options.map((opt, oIdx) => (
                                            <button 
                                                key={oIdx}
                                                onClick={() => setAnswers(prev => ({ ...prev, [q.id]: oIdx }))}
                                                className={`p-4 rounded-xl border text-left transition-all flex items-center gap-3 ${answers[q.id] === oIdx ? 'bg-cyber-cyan/10 border-cyber-cyan text-cyber-cyan shadow-[0_0_10px_rgba(0,243,255,0.1)]' : 'bg-white/5 border-transparent text-slate-300 hover:border-white/20'}`}
                                            >
                                                <div className={`w-5 h-5 rounded-full border flex items-center justify-center ${answers[q.id] === oIdx ? 'border-cyber-cyan' : 'border-slate-500'}`}>
                                                    {answers[q.id] === oIdx && <div className="w-3 h-3 rounded-full bg-cyber-cyan"></div>}
                                                </div>
                                                {opt}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            )}

            {/* ANALYSIS STEP */}
            {step === 'ANALYSIS' && (
                <div className="flex-1 overflow-y-auto custom-scrollbar p-6 relative z-10 flex flex-col items-center">
                    <div className="max-w-4xl w-full">
                        <div className="text-center mb-8">
                            <h1 className="text-4xl font-display font-bold text-white mb-2">Test Analysis</h1>
                            <p className="text-slate-400">{config.chapter} • {config.subject}</p>
                        </div>

                        {/* Score Cards */}
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                            <div className="glass-panel p-6 rounded-2xl border border-cyber-cyan/30 text-center">
                                <p className="text-slate-400 text-xs uppercase tracking-widest mb-2">Score</p>
                                <h2 className="text-4xl font-bold text-cyber-cyan">{results.score} <span className="text-sm text-slate-500">/ {config.count * 4}</span></h2>
                            </div>
                            <div className="glass-panel p-6 rounded-2xl border border-white/10 text-center">
                                <p className="text-slate-400 text-xs uppercase tracking-widest mb-2">Percentile</p>
                                <h2 className="text-4xl font-bold text-white">{(85 + Math.random() * 14).toFixed(1)}%</h2>
                            </div>
                            <div className="glass-panel p-6 rounded-2xl border border-white/10 text-center">
                                <p className="text-slate-400 text-xs uppercase tracking-widest mb-2">Rank</p>
                                <h2 className="text-4xl font-bold text-cyber-yellow">#4,201</h2>
                            </div>
                            <div className="glass-panel p-6 rounded-2xl border border-white/10 flex flex-col justify-center gap-2">
                                <div className="flex justify-between text-xs"><span className="text-green-400">Correct</span> <span>{results.correct}</span></div>
                                <div className="flex justify-between text-xs"><span className="text-red-400">Wrong</span> <span>{results.wrong}</span></div>
                                <div className="flex justify-between text-xs"><span className="text-slate-400">Skipped</span> <span>{results.skipped}</span></div>
                            </div>
                        </div>

                        {/* Detailed Solutions */}
                        <div className="glass-panel rounded-2xl border border-white/10 overflow-hidden mb-8">
                            <div className="p-4 border-b border-white/10 bg-white/5 flex justify-between items-center">
                                <h3 className="font-bold text-white">Question Analysis</h3>
                                <button className="text-xs text-cyber-cyan flex items-center gap-1 hover:underline"><BarChart2 size={14} /> Full Report</button>
                            </div>
                            <div className="divide-y divide-white/5">
                                {questions.map((q, idx) => {
                                    const status = answers[q.id] === undefined ? 'skipped' : answers[q.id] === q.correct ? 'correct' : 'wrong';
                                    return (
                                        <div key={q.id} className="p-4 flex items-center gap-4 hover:bg-white/5">
                                            <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 font-bold ${
                                                status === 'correct' ? 'bg-green-500/20 text-green-500' :
                                                status === 'wrong' ? 'bg-red-500/20 text-red-500' : 'bg-slate-500/20 text-slate-500'
                                            }`}>
                                                {idx + 1}
                                            </div>
                                            <div className="flex-1">
                                                <p className="text-white text-sm line-clamp-1">{q.text}</p>
                                                <p className={`text-xs mt-1 ${status === 'correct' ? 'text-green-400' : status === 'wrong' ? 'text-red-400' : 'text-slate-500'}`}>
                                                    {status.toUpperCase()}
                                                </p>
                                            </div>
                                            <button className="text-xs text-cyber-purple hover:text-white border border-cyber-purple/30 px-3 py-1 rounded-full">View Solution</button>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>

                        {/* Challenge Friend */}
                        <div className="bg-gradient-to-r from-cyber-purple/20 to-cyber-pink/20 border border-cyber-purple/50 rounded-2xl p-6 flex items-center justify-between">
                            <div>
                                <h3 className="text-xl font-bold text-white mb-1">Think you can do better?</h3>
                                <p className="text-sm text-slate-300">Challenge a friend to take this exact test and compare scores.</p>
                            </div>
                            <button 
                                onClick={() => {
                                    alert("Challenge Link Copied! Share it with your friend.");
                                    if(onChallenge) onChallenge('TEST-' + Math.floor(Math.random()*10000));
                                }}
                                className="px-6 py-3 bg-white text-black font-bold rounded-xl flex items-center gap-2 hover:scale-105 transition-transform"
                            >
                                <Share2 size={18} /> Challenge Friend
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};
