
import React, { useState } from 'react';
import { Send, Bug, Lightbulb, MessageSquare } from 'lucide-react';

export const Feedback: React.FC = () => {
  const [message, setMessage] = useState('');

  const sendMail = (subject: string) => {
      const body = encodeURIComponent(message || 'Detailed feedback...');
      window.location.href = `mailto:zuaki.AI@gmail.com?subject=${encodeURIComponent(subject)}&body=${body}`;
  };

  return (
    <div className="h-full w-full bg-[#0B0F1A] p-6 flex flex-col items-center">
      <div className="max-w-md w-full">
         <h1 className="text-2xl font-bold text-white mb-2 text-center">Feedback</h1>
         <p className="text-slate-400 text-xs text-center mb-8">Direct line to founders.</p>

         <textarea 
            value={message} onChange={e => setMessage(e.target.value)}
            className="w-full h-32 bg-black/30 border border-white/10 rounded-xl p-4 text-white text-sm mb-6 outline-none focus:border-cyber-cyan"
            placeholder="Describe your issue or idea..."
         />

         <div className="grid gap-3">
             <button onClick={() => sendMail('Feature Request')} className="p-4 bg-white/5 border border-white/10 rounded-xl flex items-center gap-3 hover:bg-white/10 text-white transition-all">
                 <Lightbulb className="text-cyber-yellow" size={20} /> Feature Request
             </button>
             <button onClick={() => sendMail('Bug Report')} className="p-4 bg-white/5 border border-white/10 rounded-xl flex items-center gap-3 hover:bg-white/10 text-white transition-all">
                 <Bug className="text-red-500" size={20} /> Bug Report
             </button>
             <button onClick={() => sendMail('General Feedback')} className="p-4 bg-cyber-cyan text-black font-bold rounded-xl flex items-center justify-center gap-2 hover:shadow-[0_0_15px_#00f3ff]">
                 <Send size={18} /> Send via Email
             </button>
         </div>
      </div>
    </div>
  );
};
