
import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Lock, Zap, Clock, History, LayoutGrid, CheckCircle } from 'lucide-react';
import { timerService, TimerState, TimerSession } from '../services/timerService';

export const ZuakiNeoTimer: React.FC = () => {
    const [timer, setTimer] = useState<TimerState>(timerService.getState());
    const [history, setHistory] = useState<TimerSession[]>([]);
    const [isLocked, setIsLocked] = useState(false);
    const [showCustom, setShowCustom] = useState(false);
    const [customMins, setCustomMins] = useState(25);

    useEffect(() => {
        const unsubscribe = timerService.subscribe((state) => {
            setTimer(state);
            // If timer hits 0 and was active, update history
            if (state.timeLeft === 0 && !state.isActive) {
                setHistory(timerService.getHistory());
            }
        });
        setHistory(timerService.getHistory());
        return () => { unsubscribe(); };
    }, []);

    // Color Logic
    const progress = timer.duration > 0 ? (timer.timeLeft / timer.duration) : 0;
    const isLow = timer.timeLeft < 60 && timer.timeLeft > 0;
    const isMid = timer.timeLeft < (timer.duration * 0.5) && !isLow;
    
    const strokeColor = isLow ? '#ef4444' : isMid ? '#eab308' : '#22c55e';
    const glowColor = isLow ? 'rgba(239, 68, 68, 0.5)' : isMid ? 'rgba(234, 179, 8, 0.5)' : 'rgba(34, 197, 94, 0.5)';

    // SVG Specs
    const radius = 120;
    const circumference = 2 * Math.PI * radius;
    const strokeDashoffset = circumference - progress * circumference;

    const formatTime = (s: number) => {
        const m = Math.floor(s / 60);
        const sec = s % 60;
        return `${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
    };

    const handleToggle = () => {
        if (timer.isActive) timerService.pause();
        else timerService.start();
    };

    const handleMode = (mins: number, name: string) => {
        timerService.setMode(mins, name);
    };

    return (
        <div className={`h-full w-full bg-[#020617] flex flex-col relative overflow-hidden ${isLocked ? 'fixed inset-0 z-[200]' : ''}`}>
            {/* Ambient Background */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#0f172a_0%,_#020617_80%)] pointer-events-none"></div>
            <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full blur-[100px] pointer-events-none transition-colors duration-1000 ${isLow ? 'bg-red-900/20' : timer.isActive ? 'bg-green-900/20' : 'bg-blue-900/10'}`}></div>

            {/* Header */}
            <div className="p-6 flex justify-between items-center relative z-20">
                <div>
                    <h1 className="text-3xl font-display font-bold text-white uppercase tracking-widest flex items-center gap-2">
                        <Clock className="text-cyber-cyan" /> Neo Timer
                    </h1>
                    <p className="text-slate-400 text-xs font-mono flex items-center gap-2">
                        {timer.isActive ? <span className="text-green-400 animate-pulse">● LIVE SESSION</span> : 'READY'}
                    </p>
                </div>
                
                <button 
                    onClick={() => setIsLocked(!isLocked)}
                    className={`p-3 rounded-xl border transition-all flex items-center gap-2 ${isLocked ? 'bg-red-500/20 border-red-500 text-red-500' : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'}`}
                >
                    <Lock size={18} /> {isLocked ? 'UNLOCK' : 'LOCK MODE'}
                </button>
            </div>

            {/* Main Timer Display */}
            <div className="flex-1 flex flex-col items-center justify-center relative z-10">
                <div className="relative w-80 h-80 flex items-center justify-center mb-8">
                    {/* Background Ring */}
                    <svg className="absolute inset-0 w-full h-full -rotate-90">
                        <circle cx="160" cy="160" r={radius} stroke="rgba(255,255,255,0.05)" strokeWidth="12" fill="none" />
                        <circle 
                            cx="160" cy="160" r={radius} 
                            stroke={strokeColor} 
                            strokeWidth="12" 
                            fill="none" 
                            strokeDasharray={circumference} 
                            strokeDashoffset={strokeDashoffset}
                            strokeLinecap="round"
                            className="transition-all duration-1000 ease-linear"
                            style={{ filter: `drop-shadow(0 0 15px ${glowColor})` }}
                        />
                    </svg>
                    
                    {/* Time Text */}
                    <div className="text-center">
                        <div className="text-7xl font-mono font-bold text-white tracking-widest drop-shadow-lg">
                            {formatTime(timer.timeLeft)}
                        </div>
                        <div className="text-cyber-cyan text-sm uppercase tracking-[0.3em] mt-2 font-bold">{timer.mode}</div>
                    </div>
                </div>

                {/* Controls */}
                <div className="flex items-center gap-6 mb-10">
                    <button 
                        onClick={() => timerService.reset()} 
                        className="p-4 rounded-full border border-white/10 bg-white/5 text-slate-400 hover:text-white hover:bg-white/10 transition-all"
                    >
                        <RotateCcw size={24} />
                    </button>
                    
                    <button 
                        onClick={handleToggle}
                        className={`w-24 h-24 rounded-[30px] flex items-center justify-center shadow-[0_0_40px_rgba(0,0,0,0.3)] transition-all hover:scale-105 active:scale-95 ${
                            timer.isActive 
                            ? 'bg-cyber-yellow text-black shadow-[0_0_30px_#fcee0a]' 
                            : 'bg-cyber-cyan text-black shadow-[0_0_30px_#00f3ff]'
                        }`}
                    >
                        {timer.isActive ? <Pause size={40} fill="currentColor" /> : <Play size={40} fill="currentColor" className="ml-1" />}
                    </button>

                    <button 
                        onClick={() => setShowCustom(!showCustom)} 
                        className="p-4 rounded-full border border-white/10 bg-white/5 text-slate-400 hover:text-white hover:bg-white/10 transition-all"
                    >
                        <LayoutGrid size={24} />
                    </button>
                </div>

                {/* Modes Scroller */}
                {showCustom ? (
                    <div className="bg-black/40 border border-white/10 p-4 rounded-2xl flex items-center gap-4 animate-in fade-in slide-in-from-bottom-4">
                        <input 
                            type="range" min="1" max="120" 
                            value={customMins} 
                            onChange={(e) => setCustomMins(Number(e.target.value))}
                            className="accent-cyber-cyan w-48 h-2 bg-white/10 rounded-lg appearance-none cursor-pointer" 
                        />
                        <span className="text-white font-mono w-12 text-center">{customMins}m</span>
                        <button 
                            onClick={() => { handleMode(customMins, 'Custom'); setShowCustom(false); }}
                            className="px-4 py-2 bg-cyber-cyan text-black font-bold rounded-lg text-xs"
                        >
                            SET
                        </button>
                    </div>
                ) : (
                    <div className="flex gap-4 overflow-x-auto max-w-full px-6 pb-4 no-scrollbar">
                        <ModeCard label="Focus" time="25" active={timer.mode === 'Focus'} onClick={() => handleMode(25, 'Focus')} />
                        <ModeCard label="Deep" time="45" active={timer.mode === 'Deep'} onClick={() => handleMode(45, 'Deep')} />
                        <ModeCard label="Sprint" time="10" active={timer.mode === 'Sprint'} onClick={() => handleMode(10, 'Sprint')} />
                        <ModeCard label="Marathon" time="60" active={timer.mode === 'Marathon'} onClick={() => handleMode(60, 'Marathon')} />
                    </div>
                )}
            </div>

            {/* Mini History (Bottom Sheet) */}
            <div className="bg-black/40 border-t border-white/10 p-4 backdrop-blur-md">
                <div className="flex items-center gap-2 mb-3 text-slate-400 text-xs font-bold uppercase tracking-widest">
                    <History size={14} /> Recent Sessions
                </div>
                <div className="flex gap-3 overflow-x-auto no-scrollbar">
                    {history.length === 0 ? (
                        <span className="text-slate-500 text-xs italic">No sessions recorded yet. Start focusing!</span>
                    ) : (
                        history.map((h) => (
                            <div key={h.id} className="bg-white/5 border border-white/5 rounded-lg p-3 min-w-[120px] flex flex-col">
                                <div className="flex justify-between items-start mb-1">
                                    <span className="text-[10px] text-cyber-cyan font-bold">{h.mode}</span>
                                    <span className="text-[10px] text-yellow-400 font-mono">+{h.xp} XP</span>
                                </div>
                                <span className="text-white font-bold text-sm">{h.duration} Mins</span>
                                <span className="text-[9px] text-slate-500">{new Date(h.date).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})}</span>
                            </div>
                        ))
                    )}
                </div>
            </div>
        </div>
    );
};

const ModeCard = ({ label, time, active, onClick }: any) => (
    <button 
        onClick={onClick}
        className={`flex flex-col items-center justify-center w-24 h-24 rounded-2xl border transition-all shrink-0 ${
            active 
            ? 'bg-cyber-cyan/10 border-cyber-cyan shadow-[0_0_15px_rgba(0,243,255,0.2)]' 
            : 'bg-white/5 border-white/5 hover:bg-white/10 hover:border-white/20'
        }`}
    >
        <span className={`text-2xl font-bold font-mono mb-1 ${active ? 'text-white' : 'text-slate-300'}`}>{time}</span>
        <span className={`text-[10px] uppercase tracking-wider font-bold ${active ? 'text-cyber-cyan' : 'text-slate-500'}`}>{label}</span>
    </button>
);
