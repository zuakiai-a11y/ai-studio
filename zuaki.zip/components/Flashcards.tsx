
import React, { useState, useEffect } from 'react';
import { BookOpen, RefreshCw, Check, X, RotateCcw } from 'lucide-react';
import { MOCK_FLASHCARDS } from '../data/flashcards';
import { Flashcard, UserProfile } from '../types';

export const Flashcards: React.FC = () => {
    const [filterClass, setFilterClass] = useState<string>('12'); // Default to 12
    const [filterSubject, setFilterSubject] = useState<string>('Physics');
    const [cards, setCards] = useState<Flashcard[]>([]);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [isFlipped, setIsFlipped] = useState(false);
    
    // Load persisted progress or init
    useEffect(() => {
        // In a real app, load 'mastered' status from localStorage
        const filtered = MOCK_FLASHCARDS.filter(c => c.classLevel === filterClass && c.subject === filterSubject);
        setCards(filtered);
        setCurrentIndex(0);
        setIsFlipped(false);
    }, [filterClass, filterSubject]);

    const handleNext = () => {
        if (currentIndex < cards.length - 1) {
            setIsFlipped(false);
            setTimeout(() => setCurrentIndex(prev => prev + 1), 200);
        } else {
            alert("Set completed! Good job.");
            setCurrentIndex(0);
        }
    };

    const handleMark = (mastered: boolean) => {
        // Logic to update local storage progress would go here
        handleNext();
    };

    const currentCard = cards[currentIndex];

    return (
        <div className="h-full w-full bg-[#020617] p-6 flex flex-col items-center relative overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_#0f172a_0%,_#020617_80%)]"></div>

            <div className="z-10 w-full max-w-md flex flex-col h-full">
                <div className="flex items-center justify-between mb-6">
                    <h1 className="text-2xl font-display font-bold text-white uppercase tracking-widest flex items-center gap-2">
                        <BookOpen className="text-cyber-pink" /> Flashcards
                    </h1>
                </div>

                {/* Filters */}
                <div className="flex gap-2 mb-6">
                    <select 
                        value={filterClass} 
                        onChange={e => setFilterClass(e.target.value)}
                        className="bg-white/5 border border-white/10 rounded-lg text-white text-xs p-2 outline-none"
                    >
                        <option value="11">Class 11</option>
                        <option value="12">Class 12</option>
                    </select>
                    <select 
                        value={filterSubject} 
                        onChange={e => setFilterSubject(e.target.value)}
                        className="flex-1 bg-white/5 border border-white/10 rounded-lg text-white text-xs p-2 outline-none"
                    >
                        <option>Physics</option>
                        <option>Chemistry</option>
                        <option>Maths</option>
                    </select>
                </div>

                {/* Card Display */}
                <div className="flex-1 flex flex-col justify-center perspective-1000 relative">
                    {currentCard ? (
                        <div 
                            onClick={() => setIsFlipped(!isFlipped)}
                            className={`w-full aspect-[4/5] relative preserve-3d transition-transform duration-500 cursor-pointer ${isFlipped ? 'rotate-y-180' : ''}`}
                            style={{ transformStyle: 'preserve-3d', transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)' }}
                        >
                            {/* Front */}
                            <div className="absolute inset-0 backface-hidden bg-black/40 backdrop-blur-xl border border-cyber-cyan/30 rounded-3xl p-8 flex flex-col items-center justify-center text-center shadow-[0_0_30px_rgba(0,243,255,0.1)]">
                                <div className="text-cyber-cyan text-xs font-mono mb-4 uppercase tracking-widest">{currentCard.chapter}</div>
                                <h2 className="text-2xl font-bold text-white">{currentCard.front}</h2>
                                <p className="text-slate-500 text-xs mt-8 animate-pulse">Tap to Flip</p>
                            </div>

                            {/* Back */}
                            <div className="absolute inset-0 backface-hidden bg-black/40 backdrop-blur-xl border border-cyber-pink/30 rounded-3xl p-8 flex flex-col items-center justify-center text-center shadow-[0_0_30px_rgba(255,0,60,0.1)]" style={{ transform: 'rotateY(180deg)' }}>
                                <div className="text-cyber-pink text-xs font-mono mb-4 uppercase tracking-widest">Answer</div>
                                <h2 className="text-xl font-medium text-white leading-relaxed">{currentCard.back}</h2>
                            </div>
                        </div>
                    ) : (
                        <div className="text-center text-slate-500">No cards found for this selection.</div>
                    )}
                </div>

                {/* Controls */}
                {currentCard && (
                    <div className="mt-8 grid grid-cols-3 gap-4">
                        <button onClick={() => handleMark(false)} className="py-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-500 flex flex-col items-center justify-center hover:bg-red-500 hover:text-white transition-all">
                            <X size={24} />
                            <span className="text-[10px] uppercase font-bold mt-1">Don't Know</span>
                        </button>
                        <button onClick={() => setIsFlipped(!isFlipped)} className="py-4 rounded-xl bg-white/5 border border-white/10 text-white flex flex-col items-center justify-center hover:border-white/30 transition-all">
                            <RotateCcw size={24} />
                            <span className="text-[10px] uppercase font-bold mt-1">Flip</span>
                        </button>
                        <button onClick={() => handleMark(true)} className="py-4 rounded-xl bg-green-500/10 border border-green-500/30 text-green-500 flex flex-col items-center justify-center hover:bg-green-500 hover:text-white transition-all">
                            <Check size={24} />
                            <span className="text-[10px] uppercase font-bold mt-1">Mastered</span>
                        </button>
                    </div>
                )}
                
                <div className="mt-4 text-center text-slate-500 text-xs font-mono">
                    Card {currentIndex + 1} / {cards.length}
                </div>
            </div>
        </div>
    );
};
