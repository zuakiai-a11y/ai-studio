
import React from 'react';
import { FileText, Calendar, Download } from 'lucide-react';

export const PYQPapers: React.FC = () => {
    const papers = [
        { year: 2024, shift: 'Jan 27 Shift 1', difficulty: 'Moderate' },
        { year: 2024, shift: 'Jan 27 Shift 2', difficulty: 'Hard' },
        { year: 2023, shift: 'Jan 24 Shift 1', difficulty: 'Easy' },
        { year: 2023, shift: 'April 6 Shift 1', difficulty: 'Moderate' },
        { year: 2022, shift: 'June 24 Shift 2', difficulty: 'Hard' },
    ];

    return (
        <div className="h-full w-full bg-[#020617] p-6 overflow-y-auto custom-scrollbar">
            <div className="max-w-4xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-3xl font-display font-bold text-white uppercase tracking-widest flex items-center gap-3">
                        <FileText size={32} className="text-cyber-cyan" /> PYQ Archives
                    </h1>
                    <p className="text-slate-400 text-xs font-mono">Real Exam Papers from 2019-2024</p>
                </div>

                <div className="space-y-4">
                    {papers.map((paper, i) => (
                        <div key={i} className="glass-panel p-5 rounded-2xl border border-white/10 hover:border-cyber-cyan/50 transition-all flex items-center justify-between group">
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 rounded-xl bg-white/5 flex flex-col items-center justify-center border border-white/10 font-bold text-white">
                                    <span className="text-xs text-cyber-cyan">{paper.year}</span>
                                    <FileText size={16} />
                                </div>
                                <div>
                                    <h3 className="text-white font-bold">{paper.shift}</h3>
                                    <span className={`text-[10px] px-2 py-0.5 rounded ${paper.difficulty === 'Hard' ? 'bg-red-500/20 text-red-400' : paper.difficulty === 'Moderate' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-green-500/20 text-green-400'}`}>
                                        {paper.difficulty}
                                    </span>
                                </div>
                            </div>
                            <button className="px-6 py-2 rounded-lg border border-white/20 text-white text-xs font-bold hover:bg-white/10 transition-all">
                                Attempt Now
                            </button>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};
