
import React, { useRef, useState, useEffect } from 'react';
import { X, Pen, Eraser, Cloud } from 'lucide-react';
import { vercel } from '../services/backend';

interface WhiteboardSessionProps {
  groupId: string;
  onClose: () => void;
}

export const WhiteboardSession: React.FC<WhiteboardSessionProps> = ({ groupId, onClose }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [tool, setTool] = useState<'pen' | 'eraser'>('pen');
  const [color, setColor] = useState('#00f3ff');
  const [activeUsers, setActiveUsers] = useState(['You']);
  
  // Simulation for remote users
  useEffect(() => {
    // Simulate connecting to Vercel socket
    const socketUrl = vercel.api.whiteboardSocket(groupId);
    console.log(`Connecting to ${socketUrl}`);

    // Simulate another user joining
    const timer = setTimeout(() => {
        setActiveUsers(prev => [...prev, 'Unit 734']);
    }, 2000);

    return () => clearTimeout(timer);
  }, [groupId]);

  // Simulate remote drawing
  useEffect(() => {
     if (!canvasRef.current) return;
     const ctx = canvasRef.current.getContext('2d');
     if (!ctx) return;

     // Simulate a "ghost" drawing every 5 seconds to show collaboration
     const ghostInterval = setInterval(() => {
         const startX = Math.random() * 500;
         const startY = Math.random() * 500;
         
         ctx.beginPath();
         ctx.strokeStyle = '#9d00ff'; // Purple for remote user
         ctx.lineWidth = 2;
         ctx.moveTo(startX, startY);
         ctx.lineTo(startX + 50, startY + 50);
         ctx.stroke();
         
         // Add name tag
         ctx.font = '10px sans-serif';
         ctx.fillStyle = '#9d00ff';
         ctx.fillText('Unit 734', startX, startY - 5);
     }, 5000);

     return () => clearInterval(ghostInterval);
  }, []);

  const startDrawing = (e: React.MouseEvent) => {
    setIsDrawing(true);
    draw(e);
  };

  const stopDrawing = () => {
    setIsDrawing(false);
    const canvas = canvasRef.current;
    if (canvas) {
        const ctx = canvas.getContext('2d');
        ctx?.beginPath();
    }
  };

  const draw = (e: React.MouseEvent) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    ctx.lineWidth = tool === 'eraser' ? 20 : 3;
    ctx.lineCap = 'round';
    ctx.strokeStyle = tool === 'eraser' ? '#000000' : color; // Assuming black bg
    
    // Eraser hack for demo: painting black. 
    // Real impl would use globalCompositeOperation = 'destination-out'
    if (tool === 'eraser') {
         ctx.globalCompositeOperation = 'destination-out';
    } else {
         ctx.globalCompositeOperation = 'source-over';
    }

    ctx.lineTo(x, y);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const handleResize = () => {
     if (canvasRef.current) {
         // Keep content logic would be needed here (save to temp canvas)
         canvasRef.current.width = canvasRef.current.parentElement?.clientWidth || 800;
         canvasRef.current.height = canvasRef.current.parentElement?.clientHeight || 600;
     }
  };

  useEffect(() => {
      window.addEventListener('resize', handleResize);
      handleResize();
      return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="absolute inset-4 z-50 rounded-[30px] overflow-hidden glass-panel border border-cyber-cyan/30 shadow-2xl flex flex-col bg-black/90 backdrop-blur-xl animate-in zoom-in-95 duration-300">
        
        {/* Header */}
        <div className="h-14 border-b border-white/10 flex items-center justify-between px-6 bg-white/5">
            <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                    <Cloud size={16} className="text-cyber-cyan" />
                    <span className="text-white font-bold text-sm">Session: {groupId}</span>
                </div>
                <div className="h-4 w-px bg-white/10"></div>
                <div className="flex -space-x-2">
                    {activeUsers.map((u, i) => (
                        <div key={i} className="w-8 h-8 rounded-full border-2 border-black bg-cyber-purple/20 flex items-center justify-center text-xs text-white" title={u}>
                            {u[0]}
                        </div>
                    ))}
                </div>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-red-500/20 hover:text-red-500 rounded-full transition-colors text-slate-400">
                <X size={20} />
            </button>
        </div>

        {/* Toolbar */}
        <div className="absolute top-20 left-4 flex flex-col gap-2 bg-black/60 p-2 rounded-xl border border-white/10 z-10">
            <button onClick={() => setTool('pen')} className={`p-3 rounded-lg transition-all ${tool === 'pen' ? 'bg-cyber-cyan text-black' : 'text-slate-400 hover:text-white'}`}>
                <Pen size={20} />
            </button>
            <button onClick={() => setTool('eraser')} className={`p-3 rounded-lg transition-all ${tool === 'eraser' ? 'bg-cyber-pink text-white' : 'text-slate-400 hover:text-white'}`}>
                <Eraser size={20} />
            </button>
            <div className="h-px w-full bg-white/10 my-1"></div>
            {['#00f3ff', '#9d00ff', '#fcee0a', '#ff003c'].map(c => (
                <button 
                    key={c}
                    onClick={() => { setColor(c); setTool('pen'); }}
                    className={`w-6 h-6 rounded-full border-2 transition-transform ${color === c && tool === 'pen' ? 'border-white scale-110' : 'border-transparent'}`}
                    style={{ backgroundColor: c }}
                />
            ))}
        </div>

        {/* Canvas */}
        <div className="flex-1 relative cursor-crosshair bg-[#050818]">
            {/* Grid */}
            <div className="absolute inset-0 opacity-20 pointer-events-none" style={{backgroundImage: 'radial-gradient(#475569 1px, transparent 1px)', backgroundSize: '20px 20px'}}></div>
            <canvas
                ref={canvasRef}
                onMouseDown={startDrawing}
                onMouseMove={draw}
                onMouseUp={stopDrawing}
                onMouseLeave={stopDrawing}
                className="block w-full h-full"
            />
        </div>
    </div>
  );
};
