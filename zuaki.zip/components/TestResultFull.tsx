
import React, { useState } from 'react';
import { BarChart2, CheckCircle, XCircle, Clock, Award, ArrowRight, Share2, Layers, Zap, Brain, TrendingUp, AlertTriangle, MessageSquare, Bookmark } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, Tooltip, CartesianGrid, PieChart, Pie, Cell } from 'recharts';
import { TestResult, Question } from '../types';
import { getGeminiResponse } from '../services/geminiService';

interface TestResultFullProps {
    result: TestResult;
    onExit: () => void;
}

export const TestResultFull: React.FC<TestResultFullProps> = ({ result, onExit }) => {
    const [tab, setTab] = useState<'OVERVIEW' | 'AI_INSIGHTS' | 'SOLUTIONS'>('OVERVIEW');
    const [explainingId, setExplainingId] = useState<string | null>(null);
    const [aiExplanations, setAiExplanations] = useState<Record<string, string>>({});

    // Chart Data
    const subjectData = [
        { name: 'Physics', score: result.subjectWise.Physics.score, total: 100, fill: '#00f3ff' },
        { name: 'Chemistry', score: result.subjectWise.Chemistry.score, total: 100, fill: '#9d00ff' },
        { name: 'Maths', score: result.subjectWise.Maths.score, total: 100, fill: '#ff003c' },
    ];

    const pieData = [
        { name: 'Correct', value: result.correctCount, color: '#22c55e' },
        { name: 'Wrong', value: result.wrongCount, color: '#ef4444' },
        { name: 'Skipped', value: result.skippedCount, color: '#64748b' }
    ];

    const handleExplainAI = async (q: Question, userAnswer: any) => {
        setExplainingId(q.id);
        const prompt = `Explain this JEE Main question step by step.
        Question: ${q.text}
        User Answer: ${userAnswer !== undefined ? userAnswer : 'Skipped'}
        Correct Answer: ${q.type === 'MCQ' ? q.options?.[q.correctAnswer as number] : q.correctAnswer}
        Chapter: ${q.chapter}
        Explain why the user answer is wrong/right (if attempted).
        Include formulas (${q.formulaUsed?.join(', ')}) and exam tips.`;

        try {
            const response = await getGeminiResponse(prompt);
            setAiExplanations(prev => ({ ...prev, [q.id]: response }));
        } catch (e) {
            setAiExplanations(prev => ({ ...prev, [q.id]: "AI Connection Failed. Please try again." }));
        } finally {
            setExplainingId(null);
        }
    };

    const toggleBookmark = (qId: string) => {
        // Logic to save bookmark to local storage 'user_bookmarks'
        // Simulating toggle for UI state if we had local state, but usually handled by parent or service
        const saved = JSON.parse(localStorage.getItem('user_bookmarks') || '[]');
        if (saved.includes(qId)) {
            const newSaved = saved.filter((id: string) => id !== qId);
            localStorage.setItem('user_bookmarks', JSON.stringify(newSaved));
            alert("Bookmark removed");
        } else {
            saved.push(qId);
            localStorage.setItem('user_bookmarks', JSON.stringify(saved));
            alert("Question bookmarked");
        }
    };

    return (
        <div className="h-full w-full bg-[#020617] overflow-y-auto custom-scrollbar p-6">
            <div className="max-w-6xl mx-auto">
                {/* Header */}
                <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
                    <div>
                        <h1 className="text-3xl font-display font-bold text-white uppercase tracking-widest flex items-center gap-3">
                            <Award size={32} className="text-cyber-yellow" /> Analysis Report
                        </h1>
                        <p className="text-slate-400 text-sm font-mono mt-1">{result.testTitle} • {new Date(result.date).toLocaleDateString()}</p>
                    </div>
                    <div className="flex gap-3">
                        <button className="px-6 py-2 bg-white/5 border border-white/10 rounded-xl text-white hover:bg-white/10 flex items-center gap-2">
                            <Share2 size={16} /> Share
                        </button>
                        <button onClick={onExit} className="px-6 py-2 bg-cyber-cyan text-black font-bold rounded-xl hover:shadow-[0_0_15px_#00f3ff]">
                            Back to Lab
                        </button>
                    </div>
                </div>

                {/* Tabs */}
                <div className="flex justify-center mb-8">
                    <div className="bg-white/5 p-1 rounded-xl border border-white/10 flex">
                        <button onClick={() => setTab('OVERVIEW')} className={`px-6 md:px-8 py-2 rounded-lg text-sm font-bold transition-all ${tab === 'OVERVIEW' ? 'bg-cyber-cyan text-black shadow-[0_0_10px_#00f3ff]' : 'text-slate-400 hover:text-white'}`}>Overview</button>
                        <button onClick={() => setTab('AI_INSIGHTS')} className={`px-6 md:px-8 py-2 rounded-lg text-sm font-bold transition-all ${tab === 'AI_INSIGHTS' ? 'bg-cyber-purple text-white shadow-[0_0_10px_#9d00ff]' : 'text-slate-400 hover:text-white'}`}>AI Insights</button>
                        <button onClick={() => setTab('SOLUTIONS')} className={`px-6 md:px-8 py-2 rounded-lg text-sm font-bold transition-all ${tab === 'SOLUTIONS' ? 'bg-cyber-pink text-white shadow-[0_0_10px_#ff003c]' : 'text-slate-400 hover:text-white'}`}>Solutions</button>
                    </div>
                </div>

                {tab === 'OVERVIEW' && (
                    <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4">
                        {/* KPI Grid */}
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <div className="glass-panel p-6 rounded-2xl border border-cyber-cyan/30 text-center relative overflow-hidden">
                                <div className="absolute inset-0 bg-cyber-cyan/5"></div>
                                <p className="text-slate-400 text-xs uppercase tracking-widest mb-1">Total Score</p>
                                <h2 className="text-5xl font-display font-bold text-white drop-shadow-[0_0_10px_rgba(0,243,255,0.5)]">
                                    {result.score} <span className="text-lg text-slate-500 font-sans">/ {result.totalMarks}</span>
                                </h2>
                            </div>
                            <div className="glass-panel p-6 rounded-2xl border border-white/10 text-center">
                                <p className="text-slate-400 text-xs uppercase tracking-widest mb-1">Rank</p>
                                <h2 className="text-4xl font-bold text-cyber-yellow">#{result.rank}</h2>
                                <p className="text-[10px] text-green-400">Top 12%</p>
                            </div>
                            <div className="glass-panel p-6 rounded-2xl border border-white/10 text-center">
                                <p className="text-slate-400 text-xs uppercase tracking-widest mb-1">Accuracy</p>
                                <h2 className="text-4xl font-bold text-white">{result.accuracy}%</h2>
                            </div>
                            <div className="glass-panel p-6 rounded-2xl border border-white/10 text-center">
                                <p className="text-slate-400 text-xs uppercase tracking-widest mb-1">Percentile</p>
                                <h2 className="text-4xl font-bold text-cyber-pink">{result.percentile.toFixed(2)}</h2>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            {/* Subject Performance */}
                            <div className="glass-panel p-6 rounded-2xl border border-white/10 md:col-span-2">
                                <h3 className="text-white font-bold mb-6 flex items-center gap-2"><Layers size={18} className="text-cyber-purple"/> Subject Breakdown</h3>
                                <div className="h-64 w-full">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <BarChart data={subjectData} layout="vertical">
                                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" horizontal={false} />
                                            <XAxis type="number" domain={[0, 100]} hide />
                                            <Tooltip cursor={{fill: 'rgba(255,255,255,0.05)'}} contentStyle={{backgroundColor: '#000', border: '1px solid #333', borderRadius: '8px'}} />
                                            <Bar dataKey="score" barSize={30} radius={[0, 6, 6, 0]} />
                                        </BarChart>
                                    </ResponsiveContainer>
                                </div>
                            </div>

                            {/* Question Distribution */}
                            <div className="glass-panel p-6 rounded-2xl border border-white/10 flex flex-col items-center justify-center">
                                <h3 className="text-white font-bold mb-4 w-full text-left">Attempts</h3>
                                <div className="h-48 w-48 relative">
                                    <ResponsiveContainer width="100%" height="100%">
                                        <PieChart>
                                            <Pie data={pieData} innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="value">
                                                {pieData.map((entry, index) => (
                                                    <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                                                ))}
                                            </Pie>
                                        </PieChart>
                                    </ResponsiveContainer>
                                    <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                                        <span className="text-2xl font-bold text-white">{result.correctCount + result.wrongCount + result.skippedCount}</span>
                                        <span className="text-[10px] text-slate-500 uppercase">Total Qs</span>
                                    </div>
                                </div>
                                <div className="flex gap-4 mt-6 text-xs">
                                    <div className="flex items-center gap-1"><div className="w-2 h-2 bg-green-500 rounded-full"></div> Correct</div>
                                    <div className="flex items-center gap-1"><div className="w-2 h-2 bg-red-500 rounded-full"></div> Wrong</div>
                                    <div className="flex items-center gap-1"><div className="w-2 h-2 bg-slate-600 rounded-full"></div> Skipped</div>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {tab === 'AI_INSIGHTS' && (
                    <div className="space-y-6 animate-in fade-in">
                        <div className="glass-panel p-8 rounded-2xl border border-cyber-purple/30 bg-cyber-purple/5">
                            <div className="flex items-center gap-4 mb-6">
                                <div className="p-3 bg-cyber-purple/20 rounded-xl text-cyber-purple border border-cyber-purple/30">
                                    <Brain size={32} />
                                </div>
                                <div>
                                    <h2 className="text-2xl font-bold text-white">Zuaki Neural Analysis</h2>
                                    <p className="text-slate-400 text-sm">AI-driven breakdown of your performance patterns.</p>
                                </div>
                            </div>

                            {/* Chapter Analysis Table */}
                            {result.chapterAnalysis && result.chapterAnalysis.length > 0 ? (
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="p-5 bg-black/40 rounded-xl border border-red-500/20">
                                        <h3 className="text-red-400 font-bold mb-3 flex items-center gap-2"><AlertTriangle size={18}/> Critical Weaknesses</h3>
                                        <div className="space-y-2">
                                            {result.chapterAnalysis.filter(c => c.status === 'Weak').map((c, i) => (
                                                <div key={i} className="flex justify-between text-sm p-2 rounded bg-red-500/5">
                                                    <span className="text-slate-300">{c.name}</span>
                                                    <span className="text-red-400 font-bold">{c.accuracy.toFixed(0)}% Acc</span>
                                                </div>
                                            ))}
                                            {result.chapterAnalysis.filter(c => c.status === 'Weak').length === 0 && (
                                                <p className="text-slate-500 text-sm italic">No critical weaknesses detected!</p>
                                            )}
                                        </div>
                                    </div>
                                    <div className="p-5 bg-black/40 rounded-xl border border-green-500/20">
                                        <h3 className="text-green-400 font-bold mb-3 flex items-center gap-2"><Zap size={18}/> Core Strengths</h3>
                                        <div className="space-y-2">
                                            {result.chapterAnalysis.filter(c => c.status === 'Strong').map((c, i) => (
                                                <div key={i} className="flex justify-between text-sm p-2 rounded bg-green-500/5">
                                                    <span className="text-slate-300">{c.name}</span>
                                                    <span className="text-green-400 font-bold">{c.accuracy.toFixed(0)}% Acc</span>
                                                </div>
                                            ))}
                                            {result.chapterAnalysis.filter(c => c.status === 'Strong').length === 0 && (
                                                <p className="text-slate-500 text-sm italic">Keep practicing to build strengths.</p>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            ) : (
                                <p className="text-slate-400 italic">Analysis available after attempt.</p>
                            )}

                            <div className="mt-6 p-5 bg-cyber-cyan/10 border border-cyber-cyan/20 rounded-xl">
                                <h3 className="text-cyber-cyan font-bold mb-2 flex items-center gap-2"><TrendingUp size={18}/> Predicted Rank Trajectory</h3>
                                <p className="text-slate-300 text-sm mb-4">Based on this test, your potential rank is <strong>14,000 - 16,000</strong>. Improving Chemistry accuracy by 15% can push this to <strong>Under 8,000</strong>.</p>
                                <div className="w-full bg-black/50 h-2 rounded-full overflow-hidden">
                                    <div className="bg-gradient-to-r from-red-500 via-yellow-500 to-green-500 h-full w-[70%]"></div>
                                </div>
                                <div className="flex justify-between text-[10px] text-slate-500 mt-1 uppercase tracking-widest">
                                    <span>Current</span>
                                    <span>Target</span>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {tab === 'SOLUTIONS' && (
                    <div className="space-y-4 animate-in fade-in">
                        {/* Detailed Question Review */}
                        {result.questions?.map((q, i) => {
                            const userAnswer = result.answers[q.id];
                            const isCorrect = q.type === 'MCQ' ? userAnswer === q.correctAnswer : Number(userAnswer) === Number(q.correctAnswer);
                            const isSkipped = userAnswer === undefined || userAnswer === '';
                            const time = result.questionTime[q.id] || 0;

                            return (
                                <div key={q.id} className="glass-panel p-6 rounded-2xl border border-white/5 hover:border-white/20 transition-all">
                                    <div className="flex justify-between items-start mb-4">
                                        <div className="flex items-center gap-3">
                                            <div className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center font-bold text-white">{i+1}</div>
                                            <span className="text-[10px] px-2 py-1 bg-cyber-purple/20 text-cyber-purple rounded uppercase font-bold">{q.subject}</span>
                                            <span className="text-[10px] text-slate-500 flex items-center gap-1"><Clock size={12}/> {time}s</span>
                                        </div>
                                        <div className="flex gap-2">
                                            <button onClick={() => toggleBookmark(q.id)} className="text-slate-400 hover:text-cyber-yellow"><Bookmark size={16} /></button>
                                            <div className={`text-xs font-bold px-3 py-1 rounded-full ${isCorrect ? 'bg-green-500/20 text-green-500' : isSkipped ? 'bg-slate-500/20 text-slate-400' : 'bg-red-500/20 text-red-500'}`}>
                                                {isCorrect ? 'Correct (+4)' : isSkipped ? 'Skipped (0)' : 'Wrong (-1)'}
                                            </div>
                                        </div>
                                    </div>
                                    <p className="text-white text-sm mb-4 leading-relaxed">{q.text}</p>
                                    
                                    <div className="grid grid-cols-2 gap-4 mb-4 text-xs">
                                        <div className="p-3 rounded bg-white/5 border border-white/10">
                                            <span className="text-slate-400 block mb-1">Your Answer</span>
                                            <span className={`font-bold ${isCorrect ? 'text-green-400' : 'text-red-400'}`}>
                                                {q.type === 'MCQ' ? (q.options?.[userAnswer as number] || 'Not Answered') : (userAnswer || 'Not Answered')}
                                            </span>
                                        </div>
                                        <div className="p-3 rounded bg-green-500/10 border border-green-500/30">
                                            <span className="text-slate-400 block mb-1">Correct Answer</span>
                                            <span className="text-green-400 font-bold">
                                                {q.type === 'MCQ' ? q.options?.[q.correctAnswer as number] : q.correctAnswer}
                                            </span>
                                        </div>
                                    </div>

                                    {/* Static Explanation */}
                                    <div className="bg-black/40 p-4 rounded-xl border border-white/5 mb-4">
                                        <h4 className="text-cyber-cyan text-xs font-bold uppercase mb-2">Solution</h4>
                                        <p className="text-slate-300 text-sm whitespace-pre-wrap">{q.solutionSteps || q.explanation}</p>
                                    </div>

                                    {/* AI Explanation Toggle */}
                                    {aiExplanations[q.id] ? (
                                        <div className="bg-cyber-purple/10 p-4 rounded-xl border border-cyber-purple/30 animate-in fade-in">
                                            <h4 className="text-cyber-purple text-xs font-bold uppercase mb-2 flex items-center gap-2"><Brain size={14}/> Zuaki AI Analysis</h4>
                                            <div className="text-slate-200 text-sm whitespace-pre-wrap">{aiExplanations[q.id]}</div>
                                        </div>
                                    ) : (
                                        <button 
                                            onClick={() => handleExplainAI(q, userAnswer)}
                                            disabled={explainingId === q.id}
                                            className="text-xs text-cyber-purple hover:text-white border border-cyber-purple/30 px-3 py-2 rounded-lg flex items-center gap-2 transition-all hover:bg-cyber-purple/20"
                                        >
                                            {explainingId === q.id ? <span className="animate-pulse">Analyzing...</span> : <><MessageSquare size={14}/> Explain with AI</>}
                                        </button>
                                    )}
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>
        </div>
    );
};
