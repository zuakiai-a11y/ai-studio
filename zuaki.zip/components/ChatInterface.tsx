
import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, Smile, PenTool, Check, AlertTriangle, Search, Plus, 
  Users, UserPlus, Bell, X, Mic, Paperclip, Image as ImageIcon,
  MoreVertical, Phone, Video, ArrowLeft, Copy, Share2, Trash2, VolumeX, MessageCircle, LogIn
} from 'lucide-react';
import { Message, ChatContact, Group, FriendRequest } from '../types';
import { WhiteboardSession } from './WhiteboardSession';
import { firebase } from '../services/backend';

// --- CONSTANTS ---
const STICKERS = ['🔥', '🚀', '💯', '📚', '⚡', '🧠', '✅', '🛑', '👽', '🧪'];

export const ChatInterface: React.FC = () => {
  // Navigation State
  const [activeChat, setActiveChat] = useState<(ChatContact | Group) | null>(null);
  const [activeTab, setActiveTab] = useState<'FRIENDS' | 'GROUPS'>('FRIENDS');
  
  // Data State
  const [friends, setFriends] = useState<ChatContact[]>([]);
  const [groups, setGroups] = useState<Group[]>([]);
  const [requests, setRequests] = useState<FriendRequest[]>([]);
  
  // Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResult, setSearchResult] = useState<any | null>(null);
  const [searchError, setSearchError] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  
  // Group UI State
  const [showGroupModal, setShowGroupModal] = useState(false);
  const [groupModalMode, setGroupModalMode] = useState<'CREATE' | 'JOIN'>('CREATE');
  const [newGroupName, setNewGroupName] = useState('');
  const [joinCode, setJoinCode] = useState('ZA-GROUP-');
  const [generatedCode, setGeneratedCode] = useState('');

  // Active Chat State
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [showWhiteboard, setShowWhiteboard] = useState(false);
  const [showAttachments, setShowAttachments] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const currentUser = localStorage.getItem('zuaki_google_uid') || '';

  // --- INITIAL DATA FETCH ---
  useEffect(() => {
      loadData();
  }, []);

  const loadData = async () => {
      if (!currentUser) return;
      
      const loadedFriends = await firebase.firestore().friends.list(currentUser);
      setFriends(loadedFriends);

      const loadedGroups = await firebase.firestore().groups.list(currentUser);
      setGroups(loadedGroups);
  };

  // --- PERSISTENCE FOR CHAT ---
  useEffect(() => {
      if (activeChat) {
          const stored = localStorage.getItem(`chat_msg_${activeChat.id}`);
          if (stored) setMessages(JSON.parse(stored));
          else setMessages([]);
      }
  }, [activeChat]);

  useEffect(() => {
      if (activeChat && messages.length > 0) {
          localStorage.setItem(`chat_msg_${activeChat.id}`, JSON.stringify(messages));
      }
  }, [messages, activeChat]);

  useEffect(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, activeChat]);

  // Reset Search when switching tabs
  useEffect(() => {
      setSearchQuery('');
      setSearchResult(null);
      setSearchError(false);
      // Autofill prefix if focused (optional, logic handled in onFocus/onChange)
  }, [activeTab]);

  // --- HANDLERS ---

  // Strict Search Masking
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      let val = e.target.value.toUpperCase();
      const prefix = activeTab === 'FRIENDS' ? 'ZA-' : 'ZA-GROUP-';
      
      // Ensure prefix integrity
      if (!val.startsWith(prefix)) {
          // If they delete part of the prefix, restore it
          val = prefix; 
      }
      
      // Clean and Limit digits
      const suffix = val.slice(prefix.length).replace(/[^0-9]/g, '');
      const limitedSuffix = suffix.slice(0, 5); // Max 5 digits
      
      setSearchQuery(prefix + limitedSuffix);
      setSearchError(false);
      setSearchResult(null); // Clear previous results on type
  };

  // Execute Search
  const handleSearchSubmit = async () => {
      setIsSearching(true);
      setSearchResult(null);
      setSearchError(false);

      if (activeTab === 'FRIENDS') {
          // STRICT Format: ZA-XXXXX
          if (!/^ZA-\d{5}$/.test(searchQuery)) {
              setSearchError(true);
              setIsSearching(false);
              return;
          }

          const user = await firebase.firestore().friends.findUserByZaId(searchQuery);
          if (user) {
              setSearchResult(user);
          } else {
              setSearchResult('NOT_FOUND');
          }
      } else {
          // GROUPS Search (Filter local or find global?)
          // Prompt says "The search bar in the Groups tab must only accept Group Code... If no group matches -> Show 'No groups found'"
          // Assuming this filters the JOINED groups list for now, as joining is separate button
          if (!/^ZA-GROUP-\d{5}$/.test(searchQuery)) {
              setSearchError(true);
              setIsSearching(false);
              return;
          }
          
          const foundGroup = groups.find(g => g.inviteCode === searchQuery);
          if (foundGroup) {
              setSearchResult(foundGroup);
          } else {
              setSearchResult('NOT_FOUND');
          }
      }
      setIsSearching(false);
  };

  const handleAddFriend = async () => {
      if (searchResult && searchResult !== 'NOT_FOUND') {
          await firebase.firestore().friends.addConnection(currentUser, searchResult.id);
          alert("Friend Added!");
          setSearchQuery('ZA-');
          setSearchResult(null);
          loadData(); // Refresh list
      }
  };

  // Group Handlers
  const handleJoinCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      let val = e.target.value.toUpperCase();
      const prefix = 'ZA-GROUP-';
      if (!val.startsWith(prefix)) val = prefix;
      const suffix = val.slice(prefix.length).replace(/[^0-9]/g, '').slice(0, 5);
      setJoinCode(prefix + suffix);
  };

  const handleCreateGroup = async () => {
      if (!newGroupName.trim()) return;
      const newGroup = await firebase.firestore().groups.create(
          newGroupName, 
          'Study Group', 
          `https://ui-avatars.com/api/?name=${newGroupName}&background=random`,
          currentUser
      );
      setGeneratedCode(newGroup.inviteCode);
      loadData();
  };

  const handleJoinGroup = async () => {
      if (!/^ZA-GROUP-\d{5}$/.test(joinCode)) {
          alert("Invalid Group Code Format");
          return;
      }
      try {
          const group = await firebase.firestore().groups.join(joinCode, currentUser);
          if (group) {
              alert(`Joined ${group.name} successfully!`);
              setShowGroupModal(false);
              loadData();
          }
      } catch (error) {
          alert("Group not found or invalid code.");
      }
  };

  const handleSendMessage = (text = inputText, type: 'text'|'image'|'voice' = 'text', isEmergency = false) => {
      if (!text.trim() && type === 'text') return;
      
      const newMessage: Message = {
          id: Date.now().toString(),
          sender: 'me',
          text: text,
          timestamp: new Date(),
          type: type,
          isEmergency
      };
      
      setMessages(prev => [...prev, newMessage]);
      setInputText('');
      
      // Update local preview immediately
      if (activeChat?.type === 'group') {
          // Persist to backend
          firebase.firestore().groups.sendMessage(activeChat.id, { text, senderName: 'You', type });
          loadData();
      } 
  };

  const renderBubble = (msg: Message) => {
      const isMe = msg.sender === 'me';
      return (
          <div className={`flex w-full mb-4 ${isMe ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2`}>
              <div className={`max-w-[75%] rounded-2xl p-3 relative shadow-lg backdrop-blur-md border ${
                  msg.isEmergency 
                  ? 'bg-red-900/40 border-red-500 animate-pulse shadow-[0_0_20px_rgba(239,68,68,0.4)]'
                  : isMe 
                    ? 'bg-cyber-cyan/10 border-cyber-cyan/50 rounded-tr-none text-white shadow-[0_0_15px_rgba(0,243,255,0.1)]' 
                    : 'bg-[#1e1e2e]/80 border-cyber-purple/50 rounded-tl-none text-white shadow-[0_0_15px_rgba(157,0,255,0.1)]'
              }`}>
                  <p className="text-sm font-sans leading-relaxed">{msg.text}</p>
              </div>
          </div>
      );
  };

  // ----------------------------------------------------------------------------------
  // VIEW: CHAT WINDOW
  // ----------------------------------------------------------------------------------
  if (activeChat) {
      return (
          <div className="h-full w-full flex flex-col bg-[#020617] relative">
              {/* Top Bar */}
              <div className="h-16 px-4 flex items-center justify-between bg-black/40 backdrop-blur-xl border-b border-white/10 relative z-20">
                  <div className="flex items-center gap-3">
                      <button onClick={() => setActiveChat(null)} className="p-2 -ml-2 rounded-full hover:bg-white/10 text-white"><ArrowLeft size={20} /></button>
                      <img src={(activeChat as any).avatar || (activeChat as any).icon} className="w-10 h-10 rounded-full border border-white/20" />
                      <div>
                          <h3 className="text-white font-bold text-sm">{activeChat.name}</h3>
                          {activeChat.type === 'group' ? (
                              <p className="text-xs text-cyber-purple font-mono">{(activeChat as Group).inviteCode}</p>
                          ) : (
                              <p className="text-xs text-slate-400">Online</p>
                          )}
                      </div>
                  </div>
                  <div className="flex gap-2">
                        {activeChat.type === 'group' && (
                            <button onClick={() => handleSendMessage("🚨 EMERGENCY!", 'text', true)} className="text-red-500 hover:bg-red-500/10 p-2 rounded-full"><AlertTriangle size={20}/></button>
                        )}
                  </div>
              </div>

              {/* Chat Area */}
              <div className="flex-1 overflow-y-auto p-4 custom-scrollbar relative z-10">
                  {messages.map(msg => renderBubble(msg))}
                  <div ref={messagesEndRef} />
              </div>

              {/* Bottom Input */}
              <div className="p-3 bg-black/60 backdrop-blur-xl border-t border-white/10 relative z-20">
                  <div className="flex items-center gap-2">
                      <div className="flex-1 bg-white/5 border border-white/10 rounded-2xl flex items-center px-2">
                          <input 
                              type="text" 
                              value={inputText}
                              onChange={(e) => setInputText(e.target.value)}
                              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                              placeholder="Message..."
                              className="flex-1 bg-transparent border-none py-3 px-2 text-white placeholder-slate-500 focus:outline-none font-sans text-sm"
                          />
                          <button onClick={() => setShowWhiteboard(true)} className="p-2 text-slate-400 hover:text-cyber-yellow transition-colors"><PenTool size={18} /></button>
                      </div>
                      <button onClick={() => handleSendMessage()} className="p-3 bg-cyber-cyan text-black rounded-full hover:shadow-[0_0_15px_#00f3ff] transition-all">
                          <Send size={20} fill="currentColor" />
                      </button>
                  </div>
              </div>
              {showWhiteboard && activeChat.type === 'group' && <WhiteboardSession groupId={activeChat.id} onClose={() => setShowWhiteboard(false)} />}
          </div>
      );
  }

  // ----------------------------------------------------------------------------------
  // VIEW: LISTS (FRIENDS / GROUPS)
  // ----------------------------------------------------------------------------------
  return (
    <div className="h-full w-full bg-[#020617] relative overflow-hidden flex flex-col">
        {/* Background Ambience */}
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyber-cyan via-cyber-purple to-cyber-pink opacity-50"></div>
        
        {/* Header */}
        <div className="p-6 pb-2 flex items-center justify-between">
            <h1 className="text-3xl font-display font-bold text-white tracking-widest uppercase">Chat</h1>
        </div>

        {/* Group Actions (Only in Groups Tab) */}
        {activeTab === 'GROUPS' && (
            <div className="px-6 pb-4 flex gap-3">
                <button 
                    onClick={() => { setShowGroupModal(true); setGroupModalMode('CREATE'); }}
                    className="flex-1 py-3 bg-cyber-cyan text-black font-bold text-xs uppercase tracking-widest rounded-xl hover:shadow-[0_0_15px_#00f3ff] transition-all flex items-center justify-center gap-2"
                >
                    <Plus size={16} /> Create Group
                </button>
                <button 
                    onClick={() => { setShowGroupModal(true); setGroupModalMode('JOIN'); }}
                    className="flex-1 py-3 bg-cyber-purple text-white font-bold text-xs uppercase tracking-widest rounded-xl hover:shadow-[0_0_15px_#9d00ff] transition-all flex items-center justify-center gap-2"
                >
                    <LogIn size={16} /> Join Group
                </button>
            </div>
        )}

        {/* Strict Search Bar */}
        <div className="px-6 py-4">
            <div className="relative group">
                <Search className={`absolute left-4 top-3 transition-colors ${searchError ? 'text-red-500' : 'text-slate-500'}`} size={18} />
                <input 
                    type="text" 
                    value={searchQuery}
                    onChange={handleSearchChange}
                    onFocus={() => { if(!searchQuery) setSearchQuery(activeTab === 'FRIENDS' ? 'ZA-' : 'ZA-GROUP-'); }}
                    onKeyDown={(e) => e.key === 'Enter' && handleSearchSubmit()}
                    placeholder={activeTab === 'FRIENDS' ? "Enter ZA-ID to search a friend" : "Enter Group Code to search"} 
                    className={`w-full bg-white/5 border rounded-2xl py-3 pl-12 pr-4 text-white outline-none transition-all font-mono tracking-wider ${searchError ? 'border-red-500 shadow-[0_0_10px_rgba(239,68,68,0.3)]' : 'border-white/10 focus:border-cyber-cyan/50'}`}
                />
            </div>
            {searchError && <p className="text-red-500 text-[10px] mt-1 ml-4">Invalid Format. Use {activeTab === 'FRIENDS' ? 'ZA-XXXXX' : 'ZA-GROUP-XXXXX'}</p>}
        </div>

        {/* Tabs */}
        <div className="px-6 mb-4">
            <div className="flex bg-white/5 rounded-xl p-1 border border-white/10">
                <button onClick={() => setActiveTab('FRIENDS')} className={`flex-1 py-3 rounded-lg text-xs font-bold uppercase tracking-widest transition-all ${activeTab === 'FRIENDS' ? 'bg-cyber-cyan text-black shadow-[0_0_15px_#00f3ff]' : 'text-slate-400 hover:text-white'}`}>Friends</button>
                <button onClick={() => setActiveTab('GROUPS')} className={`flex-1 py-3 rounded-lg text-xs font-bold uppercase tracking-widest transition-all ${activeTab === 'GROUPS' ? 'bg-cyber-purple text-white shadow-[0_0_15px_#9d00ff]' : 'text-slate-400 hover:text-white'}`}>My Groups</button>
            </div>
        </div>

        {/* Content Lists */}
        <div className="flex-1 overflow-y-auto custom-scrollbar px-4 pb-20 space-y-2">
            
            {/* SEARCH RESULTS */}
            {searchResult ? (
                <div className="p-4 bg-white/5 border border-white/10 rounded-2xl animate-in fade-in">
                    <h3 className="text-xs text-slate-400 uppercase tracking-widest mb-4">Search Result</h3>
                    {searchResult === 'NOT_FOUND' ? (
                        <div className="text-center text-slate-500 text-sm">
                            {activeTab === 'FRIENDS' ? "No friends found." : "No groups found."}
                        </div>
                    ) : (
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                <img src={searchResult.avatar || searchResult.icon} className="w-12 h-12 rounded-full border border-white/20" />
                                <div>
                                    <h4 className="text-white font-bold">{searchResult.name}</h4>
                                    <p className="text-cyber-cyan text-xs font-mono">{activeTab === 'FRIENDS' ? searchResult.zaId : searchResult.inviteCode}</p>
                                </div>
                            </div>
                            {activeTab === 'FRIENDS' ? (
                                <button onClick={handleAddFriend} className="p-2 bg-green-500 text-black rounded-lg font-bold text-xs hover:scale-105 transition-transform"><UserPlus size={16}/></button>
                            ) : (
                                <button onClick={() => setActiveChat(searchResult)} className="p-2 bg-cyber-purple text-white rounded-lg font-bold text-xs">View</button>
                            )}
                        </div>
                    )}
                </div>
            ) : (
                /* MAIN LISTS */
                <>
                    {activeTab === 'FRIENDS' && (
                        friends.length === 0 ? (
                            <div className="flex flex-col items-center justify-center h-48 opacity-50 text-center">
                                <MessageCircle size={48} className="text-slate-500 mb-4" />
                                <p className="text-slate-400 text-sm">No friends yet.<br/>Add friends using their ZA-ID.</p>
                            </div>
                        ) : (
                            friends.map(friend => (
                                <div key={friend.id} onClick={() => setActiveChat(friend)} className="flex items-center gap-4 p-4 rounded-2xl hover:bg-white/5 border border-transparent hover:border-white/5 transition-all cursor-pointer">
                                    <div className="relative">
                                        <img src={friend.avatar} className="w-14 h-14 rounded-full border border-white/10 object-cover" />
                                        {friend.isOnline && <div className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-green-500 rounded-full border-2 border-[#020617] shadow-[0_0_5px_#22c55e]"></div>}
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <h3 className="text-white font-bold text-base truncate">{friend.name}</h3>
                                        <p className="text-slate-400 text-sm truncate">{friend.lastMessage}</p>
                                    </div>
                                </div>
                            ))
                        )
                    )}

                    {activeTab === 'GROUPS' && (
                        groups.length === 0 ? (
                            <div className="flex flex-col items-center justify-center h-48 opacity-50 text-center">
                                <Users size={48} className="text-slate-500 mb-4" />
                                <p className="text-slate-400 text-sm">No groups joined yet.</p>
                            </div>
                        ) : (
                            groups.map(group => (
                                <div key={group.id} onClick={() => setActiveChat(group)} className="flex items-center gap-4 p-4 rounded-2xl hover:bg-white/5 border border-transparent hover:border-white/5 transition-all cursor-pointer">
                                    <img src={group.icon} className="w-14 h-14 rounded-full border border-white/10 object-cover" />
                                    <div className="flex-1 min-w-0">
                                        <div className="flex justify-between items-baseline mb-1">
                                            <h3 className="text-white font-bold text-base truncate">{group.name}</h3>
                                            <span className="text-[10px] font-mono text-cyber-purple bg-cyber-purple/10 px-1 rounded">{group.inviteCode}</span>
                                        </div>
                                        <p className="text-sm text-slate-400 truncate"><span className="text-white/70">{group.lastMessage?.sender}:</span> {group.lastMessage?.text}</p>
                                    </div>
                                </div>
                            ))
                        )
                    )}
                </>
            )}
        </div>

        {/* Group Management Modal */}
        {showGroupModal && (
            <div className="absolute inset-0 z-50 flex items-end">
                <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowGroupModal(false)}></div>
                <div className="w-full bg-[#0b0f1a] border-t border-cyber-cyan/30 rounded-t-[30px] p-6 relative z-10 animate-in slide-in-from-bottom duration-300 shadow-[0_-10px_40px_rgba(0,0,0,0.5)]">
                    {groupModalMode === 'CREATE' ? (
                        <div className="space-y-4">
                            {!generatedCode ? (
                                <>
                                    <h3 className="text-white font-bold mb-4">Create New Group</h3>
                                    <input 
                                        type="text" 
                                        value={newGroupName}
                                        onChange={(e) => setNewGroupName(e.target.value)}
                                        placeholder="Group Name" 
                                        className="w-full bg-black/40 border border-white/10 rounded-xl p-4 text-white focus:border-cyber-cyan outline-none"
                                    />
                                    <button onClick={handleCreateGroup} className="w-full py-4 bg-cyber-cyan text-black font-bold rounded-xl uppercase tracking-widest hover:shadow-[0_0_20px_#00f3ff] transition-all">
                                        Initialize Group
                                    </button>
                                </>
                            ) : (
                                <div className="text-center py-6">
                                    <div className="w-16 h-16 bg-green-500/20 text-green-500 rounded-full flex items-center justify-center mx-auto mb-4 border border-green-500 shadow-[0_0_20px_rgba(34,197,94,0.4)]">
                                        <Check size={32} />
                                    </div>
                                    <h3 className="text-white font-bold text-xl mb-2">Group Created!</h3>
                                    <div className="flex items-center justify-between bg-white/5 border border-white/10 p-4 rounded-xl mb-6">
                                        <span className="text-2xl font-mono font-bold text-cyber-purple tracking-widest">{generatedCode}</span>
                                        <button className="text-slate-400 hover:text-white"><Copy size={20} /></button>
                                    </div>
                                    <button onClick={() => { setShowGroupModal(false); setGeneratedCode(''); }} className="text-slate-500 hover:text-white text-sm">Close</button>
                                </div>
                            )}
                        </div>
                    ) : (
                        <div className="space-y-4">
                            <h3 className="text-white font-bold mb-4">Join Group</h3>
                            <input 
                                type="text" 
                                value={joinCode}
                                onChange={handleJoinCodeChange}
                                placeholder="ZA-GROUP-XXXXX" 
                                className="w-full bg-black/40 border border-white/10 rounded-xl p-4 text-white text-center font-mono text-lg uppercase tracking-widest focus:border-cyber-purple outline-none"
                            />
                            <button onClick={handleJoinGroup} className="w-full py-4 bg-cyber-purple text-white font-bold rounded-xl uppercase tracking-widest hover:shadow-[0_0_20px_#9d00ff] transition-all">
                                Join Operation
                            </button>
                        </div>
                    )}
                </div>
            </div>
        )}
    </div>
  );
};
