
/**
 * Backend Service Modules for Zuaki (Local-First Architecture)
 * Handles integrations with LocalStorage (simulating Cloud DB), Firebase (Mock/Config), ImageKit, and YouTube Data API.
 */

import { Group, GroupMessage, FriendRequest, Friend, UserProfile, FormulaChapter, TestConfig, Question, Note, ShortNote } from "../types";
import { JEE_DATASET } from "../data/jee_2025"; // Import dataset

// --- CONFIGURATION (SECURE PLACEHOLDERS) ---
const CONFIG = {
    USE_CLOUD_SYNC: true,
    CLOUD_AUTO_DELETE_TTL: 7, // days
    IMAGEKIT: {
        PUBLIC_KEY: "public_To5u1iaTrs3bBtQSXSF6JcJg+CQ=",
        URL_ENDPOINT: "https://ik.imagekit.io/dbv0fxymy",
    },
    FIREBASE: {
        apiKey: "AIzaSyA5NEIGLqIAbra6Z7f5z4ysvr5reSjV4Og",
        authDomain: "zuaki-dev.firebaseapp.com",
        projectId: "zuaki-dev",
        storageBucket: "zuaki-dev.firebasestorage.app",
        messagingSenderId: "250198718111",
        appId: "1:250198718111:android:89d4eb6f9bbd47365094aa"
    }
};

// --- MOCK FORMULA DATA ---
const FORMULA_DB: FormulaChapter[] = [
    // Physics
    { id: 'phy-1', subject: 'Physics', title: 'Kinematics', sections: [
        { title: 'Equations of Motion', content: ['v = u + at', 's = ut + ½at²', 'v² = u² + 2as'] },
        { title: 'Projectile Motion', content: ['T = (2u sinθ)/g', 'H = (u² sin²θ)/2g', 'R = (u² sin2θ)/g'] }
    ]},
    { id: 'phy-2', subject: 'Physics', title: 'Work, Power & Energy', sections: [] },
    { id: 'phy-3', subject: 'Physics', title: 'Rotational Motion', sections: [] },
    // ... (Keep existing chapters if needed, or reduce for brevity)
];

// --- LocalStorage Database Simulator ---
const DB = {
    get: (collection: string) => {
        try {
            return JSON.parse(localStorage.getItem(`zuaki_${collection}`) || '[]');
        } catch { return []; }
    },
    set: (collection: string, data: any[]) => {
        localStorage.setItem(`zuaki_${collection}`, JSON.stringify(data));
        DB.notify(collection);
    },
    add: (collection: string, item: any) => {
        const data = DB.get(collection);
        data.push(item);
        DB.set(collection, data);
        return item;
    },
    update: (collection: string, idField: string, idValue: string, updates: any) => {
        const data = DB.get(collection);
        const index = data.findIndex((item: any) => item[idField] === idValue);
        if (index !== -1) {
            data[index] = { ...data[index], ...updates };
            DB.set(collection, data);
            return data[index];
        }
        return null;
    },
    find: (collection: string, predicate: (item: any) => boolean) => {
        return DB.get(collection).find(predicate);
    },
    filter: (collection: string, predicate: (item: any) => boolean) => {
        return DB.get(collection).filter(predicate);
    },
    listeners: {} as Record<string, Array<() => void>>,
    subscribe: (collection: string, callback: () => void) => {
        if (!DB.listeners[collection]) DB.listeners[collection] = [];
        DB.listeners[collection].push(callback);
        return () => {
            DB.listeners[collection] = DB.listeners[collection].filter(cb => cb !== callback);
        };
    },
    notify: (collection: string) => {
        if (DB.listeners[collection]) {
            DB.listeners[collection].forEach(cb => cb());
        }
    },
    delete: (collection: string, idField: string, idValue: string) => {
        const data = DB.get(collection);
        const filtered = data.filter((item: any) => item[idField] !== idValue);
        DB.set(collection, filtered);
    }
};

// --- 1. Firebase Interface (Simulated/Mocks) ---
export const firebase = {
  config: CONFIG.FIREBASE,
  auth: () => ({
    // Legacy Google Sign In (Mock with New User Check)
    signInWithGoogle: async (emailHint?: string) => {
      await new Promise(r => setTimeout(r, 1500)); 
      
      const email = emailHint || 'student.zuaki@gmail.com';
      const namePart = email.split('@')[0];
      const googleUid = `google-uid-${Math.random().toString(36).substr(2, 9)}`;
      const photoUrl = `https://ui-avatars.com/api/?name=${namePart.substring(0,2)}&background=00f3ff&color=000&rounded=true`;

      // Check if user exists in DB
      const existingUser = DB.find('users', (u: any) => u.email === email);
      
      if (existingUser) {
          const token = `auth_token_${existingUser.userId}_${Date.now()}`;
          return {
              user: existingUser,
              token: token,
              isNewUser: false,
              googleUid: existingUser.googleUid || googleUid,
              email: existingUser.email,
              photoUrl: existingUser.avatar
          };
      }

      // If new, create basic structure but return isNewUser: true to trigger avatar selection
      const randomId = Math.floor(10000 + Math.random() * 90000);
      const userId = `ZA-${randomId}`;
      const newUser = {
          userId,
          email: email,
          name: namePart.charAt(0).toUpperCase() + namePart.slice(1),
          createdAt: new Date().toISOString(),
          xp: 0,
          level: 1,
          avatar: photoUrl, // Use Google Photo initially
          googleUid: googleUid
      };
      
      // We assume the user profile will be finalized in the app flow, but we can save the stub now
      // so backend is consistent.
      DB.add('users', newUser);
      
      const token = `auth_token_${userId}_${Date.now()}`;

      return {
          user: newUser,
          token: token,
          isNewUser: true,
          googleUid: googleUid,
          email: email,
          photoUrl: photoUrl
      };
    },

    // New Credentials Signup
    signUp: async (userData: any) => {
        await new Promise(r => setTimeout(r, 1500)); // Simulate network

        const users = DB.get('users');
        
        // 1. Check Duplicates
        const emailExists = users.find((u: any) => u.email === userData.email);
        if (emailExists) throw new Error("Email already exists");

        // 2. Generate UserID
        const randomId = Math.floor(10000 + Math.random() * 90000);
        const userId = `ZA-${randomId}`;

        // 3. Encrypt Password (Mock: Base64)
        const encryptedPassword = btoa(userData.password);

        // 4. Create User Object
        const newUser = {
            ...userData,
            password: encryptedPassword, // Storing encrypted
            userId: userId,
            createdAt: new Date().toISOString(),
            xp: 0,
            level: 1,
            stats: { xp: 0, level: 1 } // Init stats
        };

        // 5. Save to Users Collection
        DB.add('users', newUser);

        const token = `auth_token_${userId}_${Date.now()}`;
        return { success: true, user: newUser, token };
    },

    // New Credentials Login
    signInWithCredentials: async (identifier: string, password: string) => {
        await new Promise(r => setTimeout(r, 1000));

        const users = DB.get('users');
        
        // 1. Find User
        const user = users.find((u: any) => u.email === identifier || u.phone === identifier);
        if (!user) throw new Error("User not found");

        // 2. Check Password
        const encryptedPassword = btoa(password);
        if (user.password !== encryptedPassword) throw new Error("Wrong password");

        // 3. Generate Token (Mock)
        const token = `auth_token_${user.userId}_${Date.now()}`;
        
        // 4. Save Token (Simulating server-side session store)
        // In real firebase, this is internal. Here we simulate 'auth/tokens' path.
        const tokens = DB.get('auth_tokens');
        tokens.push({ userId: user.userId, token });
        DB.set('auth_tokens', tokens);

        return {
            user: user,
            token: token
        };
    },

    logout: async () => {
        // Clear tokens handled by frontend usually
        return true;
    }
  }),
  firestore: () => ({
    doc: (path: string) => ({
      get: async () => {
        const [col, id] = path.split('/');
        const doc = DB.find(col, (d) => d.userId === id || d.id === id);
        return { exists: !!doc, data: () => doc || {} };
      },
      set: async (data: any) => {
        const [col, id] = path.split('/');
        const idField = col === 'users' ? 'userId' : 'id';
        const existing = DB.find(col, (d) => d[idField] === id);
        if (existing) {
            DB.update(col, idField, id, data);
        } else {
            DB.add(col, { [idField]: id, ...data });
        }
        return true;
      },
      update: async (updates: any) => {
        const [col, id] = path.split('/');
        const idField = col === 'users' ? 'userId' : 'id';
        DB.update(col, idField, id, updates);
        return true;
      }
    }),
    collection: (path: string) => ({
      get: async () => {
        // Only return real data from DB
        const docs = DB.get(path).map((d: any) => ({ data: () => d }));
        return { docs };
      }
    }),
    groups: {
        create: async (name: string, description: string, icon: string, creatorId: string) => {
            const randomCode = Math.floor(10000 + Math.random() * 90000);
            const inviteCode = `ZA-GROUP-${randomCode}`;
            const groupId = `group-${Date.now()}`;
            const newGroup = {
              id: groupId,
              name,
              description,
              icon,
              inviteCode, 
              members: [creatorId],
              creatorId,
              createdAt: Date.now(),
              memberCount: 1,
              messages: [],
              lastMessage: { text: 'Group created', sender: 'System', timestamp: Date.now() },
              type: 'group'
            };
            DB.add('groups', newGroup);
            return newGroup;
        },
        join: async (inviteCode: string, userId: string) => {
            if (!/^ZA-GROUP-\d{5}$/.test(inviteCode)) {
                throw new Error("Invalid Group Code Format");
            }

            const group = DB.find('groups', (g) => g.inviteCode === inviteCode);
            if (group) {
                if (!group.members.includes(userId)) {
                    group.members.push(userId);
                    group.memberCount++;
                    DB.update('groups', 'id', group.id, group);
                }
                return group;
            }
            throw new Error("Group not found");
        },
        list: async (userId: string) => {
            return DB.filter('groups', (g) => g.members.includes(userId));
        },
        sendMessage: async (groupId: string, message: Partial<GroupMessage>) => {
            const group = DB.find('groups', (g) => g.id === groupId);
            if (group) {
                const msg = {
                    id: `msg-${Date.now()}`,
                    type: 'text',
                    ...message,
                    timestamp: new Date().toISOString()
                };
                group.messages = group.messages || [];
                group.messages.push(msg);
                group.lastMessage = {
                    text: msg.type === 'image' ? 'Sent an image' : msg.text,
                    timestamp: Date.now(),
                    sender: msg.senderName
                };
                DB.update('groups', 'id', groupId, group);
                return msg;
            }
            throw new Error("Group not found");
        }
    },
    friends: {
        findUserByZaId: async (zaId: string) => {
            if (!/^ZA-\d{5}$/.test(zaId)) return null;
            
            // Search in users collection
            const user = DB.find('users', (u: any) => u.userId === zaId);
            if (user) return {
                id: user.userId,
                name: user.name,
                avatar: user.avatar,
                zaId: user.userId,
                isOnline: false // Mock status
            };
            
            return null;
        },
        // For demo purposes, we will treat 'connections' as a field in user profile or a separate collection
        list: async (userId: string) => {
            // In a real app, this would query a connections subcollection
            // Here we simulate by checking a 'connections' collection in LocalStorage
            const connections = DB.filter('connections', (c: any) => c.userId === userId || c.friendId === userId);
            
            // Map to friend objects
            const friends = connections.map((c: any) => {
                const targetId = c.userId === userId ? c.friendId : c.userId;
                const targetUser = DB.find('users', (u: any) => u.userId === targetId);
                if (!targetUser) return null;
                return {
                    id: targetUser.userId,
                    name: targetUser.name,
                    avatar: targetUser.avatar,
                    lastMessage: 'Connected', 
                    unread: 0,
                    isOnline: false,
                    type: 'dm'
                };
            }).filter(Boolean);
            
            return friends;
        },
        addConnection: async (userId: string, friendId: string) => {
            DB.add('connections', { id: `${userId}-${friendId}`, userId, friendId, status: 'accepted' });
        }
    },
    formulas: {
        getChapters: async (subject?: string) => {
            if (subject) {
                return FORMULA_DB.filter(c => c.subject === subject);
            }
            return FORMULA_DB;
        },
        generateShareLink: (chapterId: string) => {
            return `https://zuaki.app/share/f/${chapterId}-${Math.random().toString(36).substring(7)}`;
        }
    },
    shortNotes: {
        // Fetch mapped notes from local storage (backend simulation)
        getAll: async () => {
            return DB.get('shortNotes');
        },
        // Save new note mapping
        upload: async (note: ShortNote) => {
            const existing = DB.find('shortNotes', (n: any) => n.subject === note.subject && n.chapter === note.chapter);
            if (existing) {
                DB.update('shortNotes', 'id', existing.id, note);
            } else {
                DB.add('shortNotes', note);
            }
            return true;
        },
        getBySubject: async (subject: string) => {
            return DB.filter('shortNotes', (n: any) => n.subject === subject);
        }
    },
    tests: {
        // New JEE 2025 Test Generator reading from strict dataset
        generateJEE2025Test: async (shift: 1 | 2): Promise<TestConfig> => {
            const shiftData = JEE_DATASET.tests.find(t => t.shift === shift);
            if (!shiftData) throw new Error("Shift not found in dataset");

            return {
                id: `JEE-2025-S${shift}-${Date.now()}`,
                title: `JEE Main 2025 Shift ${shift}`,
                type: 'MOCK',
                subjects: ['Physics', 'Chemistry', 'Maths'],
                duration: 180, // 3 hours
                questionCount: shiftData.questions.length,
                // Cast to Question type (assuming dataset matches structure, which it does)
                questions: shiftData.questions.map(q => ({
                    ...q,
                    // Ensure required fields exist or map them
                    subject: q.subject as any,
                    difficulty: q.difficulty as any,
                    type: q.type as any,
                    // Initialize tracker fields
                    timeSpent: 0,
                    isBookmarked: false
                }))
            };
        },
        generateTest: async (config: { type: string, subject?: string, chapter?: string, count: number }): Promise<TestConfig> => {
             // For CHAPTER WISE tests, try to pull from JEE_DATASET if matching chapter found
             // Otherwise fallback to generation logic (since dataset is small sample in this code)
             
             let questions: Question[] = [];
             
             // Extract all available questions from dataset
             const allQuestions = JEE_DATASET.tests.flatMap(t => t.questions.map(q => ({
                 ...q,
                 subject: q.subject as any,
                 difficulty: q.difficulty as any,
                 type: q.type as any,
                 timeSpent: 0,
                 isBookmarked: false
             })));

             if (config.type === 'CHAPTER' && config.chapter) {
                 questions = allQuestions.filter(q => q.chapter === config.chapter);
             } 
             else if (config.type === 'SUBJECT' && config.subject) {
                 questions = allQuestions.filter(q => q.subject === config.subject);
             }

             // If not enough questions in dataset (since it's a sample), perform backup generation
             // In full prod, dataset would be huge.
             if (questions.length < config.count) {
                 const remaining = config.count - questions.length;
                 const subjects = config.type === 'MOCK' ? ['Physics', 'Chemistry', 'Maths'] : [config.subject || 'Physics'];
                 
                 subjects.forEach(sub => {
                     for (let i = 0; i < Math.ceil(remaining / subjects.length); i++) {
                         const isNumerical = i % 5 === 0;
                         questions.push({
                             id: `gen-${sub}-${Date.now()}-${i}`,
                             text: `Generated Practice Question for ${sub} (${config.chapter || 'General'}). Calculates basics of...`,
                             type: isNumerical ? 'NUMERICAL' : 'MCQ',
                             options: isNumerical ? undefined : ['Option A', 'Option B', 'Option C', 'Option D'],
                             correctAnswer: isNumerical ? 5 : 1,
                             explanation: `Standard solution for generated question.`,
                             solutionSteps: "1. Apply formula\n2. Solve",
                             subject: sub as any,
                             chapter: config.chapter || 'General',
                             difficulty: 'Medium',
                             timeSpent: 0,
                             isBookmarked: false
                         });
                     }
                 });
             }

             // Limit to count
             questions = questions.slice(0, config.count);

             return {
                id: `test-${Date.now()}`,
                title: config.type === 'MOCK' ? 'Grand Mock Test' : `${config.subject || 'Mixed'} Practice`,
                type: config.type as any,
                subjects: config.type === 'MOCK' ? ['Physics', 'Chemistry', 'Maths'] : [config.subject || 'Physics'],
                duration: Math.ceil(config.count * 2.5), // Approx time
                questionCount: questions.length,
                questions
            };
        },
        saveResult: async (result: any) => {
            DB.add('test_results', result);
        },
        getHistory: async () => {
            return DB.get('test_results').sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime());
        }
    },
    notes: {
        getAll: async (): Promise<Note[]> => {
            return DB.get('notes').sort((a: any, b: any) => b.createdAt - a.createdAt);
        },
        save: async (note: Note) => {
            const existing = DB.find('notes', n => n.id === note.id);
            if (existing) {
                DB.update('notes', 'id', note.id, note);
            } else {
                DB.add('notes', note);
            }
        },
        delete: async (noteId: string) => {
            DB.delete('notes', 'id', noteId);
        }
    }
  })
};

// ... other exports (vercel, imagekit, youtube) remain same
export const vercel = {
  api: {
    rankPredictor: async (userStats: any) => {
      return { estimatedRank: 1000, percentile: '99.00', trend: 'up' };
    },
    fetchNews: async () => [],
    whiteboardSocket: (groupId: string) => `wss://mock/${groupId}`
  }
};

export const imagekit = {
  uploadFile: async (base64: string, name: string) => base64
};

export const youtube = {
  searchVideos: async (query: string, apiKey?: string) => []
};
