
import { statsService } from './statsService';

const STORAGE_KEY = 'zuaki_neo_timer';
const HISTORY_KEY = 'zuaki_timer_history';

export interface TimerState {
    timeLeft: number;
    duration: number;
    isActive: boolean;
    mode: string;
    startTime: number | null;
    endTime: number | null;
}

export interface TimerSession {
    id: string;
    date: string;
    duration: number; // minutes
    mode: string;
    xp: number;
}

type TimerListener = (state: TimerState) => void;

class TimerService {
    private state: TimerState = {
        timeLeft: 25 * 60,
        duration: 25 * 60,
        isActive: false,
        mode: 'Focus',
        startTime: null,
        endTime: null
    };
    
    private listeners: Set<TimerListener> = new Set();
    private interval: any = null;

    constructor() {
        this.loadState();
        if (this.state.isActive) {
            this.startTicker();
        }
    }

    private loadState() {
        try {
            const saved = localStorage.getItem(STORAGE_KEY);
            if (saved) {
                const parsed = JSON.parse(saved);
                this.state = parsed;
                
                // Background Recovery Logic
                if (this.state.isActive && this.state.endTime) {
                    const now = Date.now();
                    const remaining = Math.ceil((this.state.endTime - now) / 1000);
                    
                    if (remaining <= 0) {
                        this.completeSession();
                    } else {
                        this.state.timeLeft = remaining;
                    }
                }
            }
        } catch (e) { console.error("Timer load failed", e); }
    }

    private saveState() {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
        this.notify();
    }

    private notify() {
        this.listeners.forEach(cb => cb({ ...this.state }));
    }

    public subscribe(cb: TimerListener) {
        this.listeners.add(cb);
        cb({ ...this.state });
        return () => this.listeners.delete(cb);
    }

    public getState() {
        return { ...this.state };
    }

    public start(durationSeconds?: number, modeName?: string) {
        if (durationSeconds) {
            this.state.duration = durationSeconds;
            this.state.timeLeft = durationSeconds;
        }
        if (modeName) {
            this.state.mode = modeName;
        }

        const now = Date.now();
        this.state.isActive = true;
        this.state.startTime = now;
        this.state.endTime = now + (this.state.timeLeft * 1000);
        
        this.saveState();
        this.startTicker();
    }

    public pause() {
        this.state.isActive = false;
        this.state.endTime = null; // Clear end time as we are pausing
        this.stopTicker();
        this.saveState();
    }

    public reset() {
        this.pause();
        this.state.timeLeft = this.state.duration;
        this.state.startTime = null;
        this.state.endTime = null;
        this.saveState();
    }

    public setMode(durationMinutes: number, modeName: string) {
        this.pause();
        this.state.duration = durationMinutes * 60;
        this.state.timeLeft = durationMinutes * 60;
        this.state.mode = modeName;
        this.saveState();
    }

    private startTicker() {
        if (this.interval) clearInterval(this.interval);
        this.interval = setInterval(() => {
            if (!this.state.isActive) return;

            // Recalculate based on endTime for accuracy
            if (this.state.endTime) {
                const now = Date.now();
                const remaining = Math.ceil((this.state.endTime - now) / 1000);
                
                if (remaining <= 0) {
                    this.completeSession();
                } else {
                    this.state.timeLeft = remaining;
                    this.notify();
                    // Save less frequently to avoid IO thrashing, or save on unload?
                    // For now, save every tick is safer for sudden closes, but maybe every 5s is better
                    if (remaining % 5 === 0) localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
                }
            }
        }, 1000);
    }

    private stopTicker() {
        if (this.interval) clearInterval(this.interval);
        this.interval = null;
    }

    private completeSession() {
        this.stopTicker();
        this.state.isActive = false;
        this.state.timeLeft = 0;
        this.saveState();

        // Award XP
        const minutes = Math.floor(this.state.duration / 60);
        const xpEarned = minutes; // 1 XP per minute
        statsService.addStudyTime(this.state.duration, 'Neo Timer'); // Handles stats + XP
        
        // Add to History
        const history = this.getHistory();
        const newSession: TimerSession = {
            id: Date.now().toString(),
            date: new Date().toISOString(),
            duration: minutes,
            mode: this.state.mode,
            xp: xpEarned
        };
        history.unshift(newSession);
        localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, 20))); // Keep last 20

        // Notify (UI will handle showing modal)
        this.notify();
    }

    public getHistory(): TimerSession[] {
        try {
            return JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
        } catch { return []; }
    }
}

export const timerService = new TimerService();
