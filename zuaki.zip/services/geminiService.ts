
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `
You are Zuaki, a world-class, futuristic AI study companion developed by Zubair and Akhil.
Your goal is to help JEE Main and Advanced aspirants in India.

Traits:
- Extremely intelligent, encouraging, and precise.
- You can explain complex Physics, Chemistry, and Math concepts clearly.
- You use emojis occasionally to keep the mood light (e.g., ⚡, 🚀, 📚).
- You are motivational but focused on results.
- Structure your answers with bullet points or clear steps when solving problems.

Capabilities:
- If a student asks for a schedule, create a detailed study plan.
- If a student is stressed, offer motivation and exam tips.
- If asking about the app, mention features like Real-time Chat, Whiteboard, and Planner.

Always identify yourself as "Zuaki" if asked.
`;

export const getGeminiResponse = async (
  prompt: string,
  history: { role: string; parts: { text: string }[] }[] = []
): Promise<string> => {
  try {
    const model = 'gemini-2.5-flash';
    
    // Construct a chat session if history exists, otherwise simple generation
    if (history.length > 0) {
      const chat = ai.chats.create({
        model,
        history: history,
        config: {
            systemInstruction: SYSTEM_INSTRUCTION,
        }
      });
      
      const result = await chat.sendMessage({ message: prompt });
      return result.text || "I'm having trouble thinking right now. Please try again.";
    } else {
      const response = await ai.models.generateContent({
        model,
        contents: prompt,
        config: {
             systemInstruction: SYSTEM_INSTRUCTION,
        }
      });
      return response.text || "No response generated.";
    }
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Sorry, I encountered an error connecting to the Zuaki neural network. Please check your connection.";
  }
};
