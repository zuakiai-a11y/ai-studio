
import { UserStats, StudyDay } from '../types';

const STORAGE_KEY = 'zuakiUserStats';

// Helper to get current day name
const getDayName = (date = new Date()) => {
  return date.toLocaleDateString('en-US', { weekday: 'short' });
};

// Initialize empty week for chart
const generateEmptyWeek = (): StudyDay[] => {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  return days.map(d => ({ day: d, date: new Date().toISOString(), seconds: 0, subjectBreakdown: {} }));
};

export const INITIAL_STATS: UserStats = {
  level: 1, 
  xp: 0,    
  dailyStreak: 0,
  lastStudyDate: null,
  
  dailyTime: 0,
  weeklyTime: 0,
  totalTime: 0,
  studyTimeHours: 0,
  
  studyHistory: generateEmptyWeek(),
  subjectTimes: { 'Physics': 0, 'Chemistry': 0, 'Maths': 0 },
  avgFocusSession: 0,
  avgBreakLength: 0,
  sessionsCount: 0,
  
  weeklyProgress: 0,
  quizzesAttempted: 0,
  accuracy: 0,
  aiDoubtsAsked: 0,
  rankEstimate: 0,
  tasksCompleted: 0,
  
  rewardsTotal: 0,
  rewardsClaimed: 0,
  
  weakSubjects: [],
  strongSubjects: []
};

type Listener = (stats: UserStats) => void;
const listeners: Set<Listener> = new Set();

export const statsService = {
  // Load from Local Storage or return Initial Zero State
  getStats: (): UserStats => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return { ...INITIAL_STATS, ...parsed, subjectTimes: { ...INITIAL_STATS.subjectTimes, ...parsed.subjectTimes } };
      }
    } catch (e) {
      console.error('Failed to load stats from local storage', e);
    }
    return { ...INITIAL_STATS };
  },

  // Calculate XP required for next level (Non-linear curve)
  // Formula: 100 * (Level ^ 1.5)
  getLevelThreshold: (level: number) => {
      return Math.floor(100 * Math.pow(level, 1.5));
  },

  // Save updates to Local Storage and notify listeners
  updateStats: (updates: Partial<UserStats>) => {
    const current = statsService.getStats();
    const updated = { ...current, ...updates };
    
    // Auto-calculate derived fields
    if (updates.totalTime !== undefined) {
        updated.studyTimeHours = parseFloat((updated.totalTime / 3600).toFixed(1));
    }

    // Dynamic Level Up Logic
    // Check if current XP exceeds threshold for current level
    let nextThreshold = statsService.getLevelThreshold(updated.level);
    
    // Level up loop (in case massive XP gain jumps multiple levels)
    while (updated.xp >= nextThreshold) {
        updated.xp -= nextThreshold; // Option A: Reset XP (Prestige style) OR Option B: Keep accumulating. 
        // Let's go with Option B (Accumulating Total XP) but for the UI we need 'XP within level'.
        // Actually, easiest for display is: Level is calculated from Total XP.
        // Let's change strategy: Level = (XP / 100)^(1/1.5) roughly.
        // To keep it simple with existing structure: We increment level and keep XP as "Total Earned".
        // Wait, standard RPG: XP resets or threshold increases. Let's stick to simple "Level increases when threshold met" 
        // but since we store Total XP, we need to calculate level derived from Total XP to be robust.
        
        // Revised: We will just increment level if we cross the threshold calculated for current level.
        // Note: Ideally XP shouldn't reset, the threshold just gets higher.
        // Implementation: We store Total XP. We calculate Level dynamically.
    }
    
    // Simplified Level Calculation based on Total XP
    // Level 1: 0-100
    // Level 2: 101-300 (Need 200)
    // Level 3: 301-600 (Need 300)
    // This effectively means Level ~ sqrt(XP). 
    // Let's stick to the previous simple logic but make it robust:
    
    // Let's just use a simple lookup for this demo to ensure stability
    // 0, 500, 1500, 3000, 5000, 7500, 10500...
    let calculatedLevel = 1;
    let xpIterator = updated.xp;
    while (xpIterator >= (calculatedLevel * 500)) {
        xpIterator -= (calculatedLevel * 500);
        calculatedLevel++;
    }
    
    if (calculatedLevel !== updated.level) {
        updated.level = calculatedLevel;
        // Trigger Level Up Event (could be handled by UI listening to level change)
    }

    // Streak Logic
    const today = new Date().toDateString();
    if (updates.dailyTime && updates.dailyTime > 0) {
        if (updated.lastStudyDate !== today) {
            const yesterday = new Date();
            yesterday.setDate(yesterday.getDate() - 1);
            
            if (updated.lastStudyDate === yesterday.toDateString()) {
                updated.dailyStreak += 1;
            } else if (updated.lastStudyDate !== today) {
                updated.dailyStreak = 1; // Reset if day skipped
            }
            updated.lastStudyDate = today;
        }
    }

    // Calculate Weak/Strong Subjects based on time
    const subjects = ['Physics', 'Chemistry', 'Maths'];
    const sortedSubjects = subjects.sort((a, b) => (updated.subjectTimes[b] || 0) - (updated.subjectTimes[a] || 0));
    updated.strongSubjects = [sortedSubjects[0]];
    updated.weakSubjects = [sortedSubjects[sortedSubjects.length - 1]];

    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    
    // Emit change
    listeners.forEach(l => l(updated));
    return updated;
  },

  // Add study seconds (used by timer/tracker)
  addStudyTime: (seconds: number, subject: string = 'General') => {
      const current = statsService.getStats();
      const newDaily = (current.dailyTime || 0) + seconds;
      const newTotal = (current.totalTime || 0) + seconds;
      
      // Update Subject Stats
      const currentSubjectTime = current.subjectTimes[subject] || 0;
      const newSubjectTimes = { ...current.subjectTimes, [subject]: currentSubjectTime + seconds };

      // Update Chart History
      const dayName = getDayName();
      const history = current.studyHistory.map(d => {
          if (d.day === dayName) {
              const prevSub = d.subjectBreakdown || {};
              return { 
                  ...d, 
                  seconds: d.seconds + seconds,
                  subjectBreakdown: { ...prevSub, [subject]: (prevSub[subject] || 0) + seconds }
              };
          }
          return d;
      });

      // XP Reward: 1 XP per minute (Standard)
      // Boost: +5 XP bonus every 20 mins is handled in ActiveTimeTracker
      const xpGained = Math.floor(seconds / 60);

      statsService.updateStats({
          dailyTime: newDaily,
          totalTime: newTotal,
          xp: (current.xp || 0) + xpGained,
          studyHistory: history,
          subjectTimes: newSubjectTimes,
      });
  },
  
  completeTask: () => {
      const current = statsService.getStats();
      statsService.updateStats({
          tasksCompleted: (current.tasksCompleted || 0) + 1,
          xp: (current.xp || 0) + 15 
      });
  },

  completeQuiz: (score: number, subject: string) => {
      const current = statsService.getStats();
      statsService.updateStats({
          quizzesAttempted: (current.quizzesAttempted || 0) + 1,
          xp: (current.xp || 0) + 50
      });
  },

  askAI: () => {
      const current = statsService.getStats();
      statsService.updateStats({
          aiDoubtsAsked: (current.aiDoubtsAsked || 0) + 1,
          xp: (current.xp || 0) + 5
      });
  },

  subscribe: (listener: Listener) => {
    listeners.add(listener);
    return () => listeners.delete(listener);
  }
};
