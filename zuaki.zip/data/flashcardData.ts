
import { FormulaTopic } from "../types";

export const JEE_FORMULA_DATA: FormulaTopic[] = [
    // PHYSICS
    {
        id: 'phy-electro-1',
        subject: 'Physics',
        chapter: 'Electrostatics',
        topic: 'Coulomb\'s Law & Field',
        cards: [
            {
                id: 'coulomb',
                front: 'Coulomb\'s Law',
                back: 'F = k * (|q1*q2|) / r²',
                explanation: 'Force between two point charges. k = 1/(4πε₀) ≈ 9×10⁹ N·m²/C².',
                example: 'If r doubles, Force becomes F/4.',
                mastered: false,
                starred: false
            },
            {
                id: 'elec-field-pt',
                front: 'Electric Field (Point Charge)',
                back: 'E = k * q / r²',
                explanation: 'Electric field intensity at distance r from charge q.',
                mastered: false,
                starred: false
            },
            {
                id: 'dipole-axial',
                front: 'Field due to Dipole (Axial)',
                back: 'E = (2kp) / r³',
                explanation: 'For short dipole where r >> a. Direction is along dipole moment.',
                mastered: false,
                starred: false
            }
        ]
    },
    {
        id: 'phy-current-1',
        subject: 'Physics',
        chapter: 'Current Electricity',
        topic: 'Grouping of Cells',
        cards: [
            {
                id: 'cells-series',
                front: 'Cells in Series',
                back: 'E_eq = E1 + E2 + ... + En',
                explanation: 'Total EMF is sum of individual EMFs. r_eq = r1 + r2 + ...',
                mastered: false,
                starred: false
            },
            {
                id: 'cells-parallel',
                front: 'Cells in Parallel',
                back: 'E_eq = (E1/r1 + E2/r2) / (1/r1 + 1/r2)',
                explanation: 'Equivalent EMF for parallel combination of two cells.',
                mastered: false,
                starred: false
            }
        ]
    },
    // CHEMISTRY
    {
        id: 'chem-sol-1',
        subject: 'Chemistry',
        chapter: 'Solutions',
        topic: 'Colligative Properties',
        cards: [
            {
                id: 'rlvp',
                front: 'Relative Lowering of Vapor Pressure',
                back: '(P⁰ - P) / P⁰ = x_solute',
                explanation: 'Raoult\'s Law for non-volatile solute.',
                mastered: false,
                starred: false
            },
            {
                id: 'elev-bp',
                front: 'Elevation in Boiling Point',
                back: 'ΔTb = Kb * m',
                explanation: 'm is molality. Kb is ebullioscopic constant.',
                mastered: false,
                starred: false
            }
        ]
    },
    {
        id: 'chem-atomic-1',
        subject: 'Chemistry',
        chapter: 'Atomic Structure',
        topic: 'Bohr Model',
        cards: [
            {
                id: 'bohr-radius',
                front: 'Radius of nth Orbit',
                back: 'r_n = 0.529 * (n² / Z) Å',
                explanation: 'Radius depends directly on n² and inversely on Z.',
                mastered: false,
                starred: false
            },
            {
                id: 'bohr-energy',
                front: 'Energy of nth Orbit',
                back: 'E_n = -13.6 * (Z² / n²) eV',
                explanation: 'Total energy of electron in hydrogen-like species.',
                mastered: false,
                starred: false
            }
        ]
    },
    // MATHS
    {
        id: 'math-trig-1',
        subject: 'Maths',
        chapter: 'Trigonometry',
        topic: 'Compound Angles',
        cards: [
            {
                id: 'sin-a-b',
                front: 'sin(A + B)',
                back: 'sinA cosB + cosA sinB',
                explanation: 'Expansion formula for sine sum.',
                mastered: false,
                starred: false
            },
            {
                id: 'tan-a-b',
                front: 'tan(A + B)',
                back: '(tanA + tanB) / (1 - tanA tanB)',
                explanation: 'Tangent sum formula.',
                mastered: false,
                starred: false
            }
        ]
    },
    {
        id: 'math-conic-1',
        subject: 'Maths',
        chapter: 'Conic Sections',
        topic: 'Parabola',
        cards: [
            {
                id: 'parabola-tangent',
                front: 'Tangent at (x1, y1) for y²=4ax',
                back: 'yy1 = 2a(x + x1)',
                explanation: 'Equation of tangent using T=0 method.',
                mastered: false,
                starred: false
            },
            {
                id: 'parabola-normal',
                front: 'Slope form of Normal',
                back: 'y = mx - 2am - am³',
                explanation: 'Equation of normal to y²=4ax with slope m.',
                mastered: false,
                starred: false
            }
        ]
    }
];
