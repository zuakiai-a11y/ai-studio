
export const jeeChapters = [
  // Physics
  "Physics: Units & Dimensions – Oneshot: Units and Dimensions One Shot | JEE Mains – https://youtu.be/video_id_1",
  "Physics: Kinematics – Oneshot: Kinematics 1D & 2D One Shot | Physics Wallah – https://youtu.be/video_id_2",
  "Physics: Laws of Motion – Oneshot: Laws of Motion Complete Chapter | Unacademy JEE – https://youtu.be/video_id_3",
  "Physics: Work, Energy & Power – Oneshot: Work Energy Power One Shot | Mohit Tyagi – https://youtu.be/video_id_4",
  "Physics: Rotational Motion – Oneshot: Rotational Motion Best One Shot | Physics Galaxy – https://youtu.be/video_id_5",
  "Physics: Gravitation – Oneshot: Gravitation Full Chapter | Aakash Digital – https://youtu.be/video_id_6",
  "Physics: Properties of Solids & Fluids – Oneshot: Fluid Mechanics One Shot | JEE Wallah – https://youtu.be/video_id_7",
  "Physics: Thermodynamics – Oneshot: Thermodynamics & KTG One Shot | Unacademy JEE – https://youtu.be/video_id_8",
  "Physics: Oscillations & Waves – Oneshot: SHM and Waves Complete | Apni Kaksha – https://youtu.be/video_id_9",
  "Physics: Electrostatics – Oneshot: Electrostatics Full Chapter Revision | Physics Wallah – https://youtu.be/video_id_10",
  "Physics: Current Electricity – Oneshot: Current Electricity One Shot | Mohit Tyagi – https://youtu.be/video_id_11",
  "Physics: Magnetic Effects of Current – Oneshot: Magnetism One Shot | Unacademy JEE – https://youtu.be/video_id_12",
  "Physics: EMI & AC – Oneshot: EMI and AC Complete Chapter | Physics Galaxy – https://youtu.be/video_id_13",
  "Physics: Optics – Oneshot: Ray and Wave Optics One Shot | Aakash Digital – https://youtu.be/video_id_14",
  "Physics: Modern Physics – Oneshot: Dual Nature & Atoms Nuclei | JEE Wallah – https://youtu.be/video_id_15",
  "Physics: Semiconductors – Oneshot: Semiconductors Logic Gates | Apni Kaksha – https://youtu.be/video_id_16",

  // Chemistry (Physical)
  "Chemistry: Mole Concept – Oneshot: Mole Concept One Shot | Unacademy JEE – https://youtu.be/video_id_17",
  "Chemistry: Atomic Structure – Oneshot: Atomic Structure Complete | Physics Wallah – https://youtu.be/video_id_18",
  "Chemistry: Chemical Kinetics – Oneshot: Chemical Kinetics One Shot | Mohit Tyagi – https://youtu.be/video_id_19",
  "Chemistry: Electrochemistry – Oneshot: Electrochemistry Full Chapter | Aakash Digital – https://youtu.be/video_id_20",
  "Chemistry: Thermodynamics – Oneshot: Chemical Thermodynamics One Shot | Unacademy JEE – https://youtu.be/video_id_21",
  "Chemistry: Equilibrium – Oneshot: Chemical & Ionic Equilibrium | JEE Wallah – https://youtu.be/video_id_22",
  "Chemistry: Solid State – Oneshot: Solid State One Shot | Apni Kaksha – https://youtu.be/video_id_23",
  "Chemistry: Solutions – Oneshot: Solutions Complete Chapter | Physics Galaxy – https://youtu.be/video_id_24",

  // Chemistry (Inorganic)
  "Chemistry: Periodic Table – Oneshot: Periodic Properties One Shot | Mohit Tyagi – https://youtu.be/video_id_25",
  "Chemistry: Chemical Bonding – Oneshot: Chemical Bonding Full Chapter | Unacademy JEE – https://youtu.be/video_id_26",
  "Chemistry: Coordination Compounds – Oneshot: Coordination Compounds One Shot | Physics Wallah – https://youtu.be/video_id_27",
  "Chemistry: p-Block Elements – Oneshot: p-Block (Group 13-18) One Shot | Aakash Digital – https://youtu.be/video_id_28",
  "Chemistry: d and f Block – Oneshot: d & f Block Elements | JEE Wallah – https://youtu.be/video_id_29",

  // Chemistry (Organic)
  "Chemistry: GOC – Oneshot: General Organic Chemistry One Shot | Physics Wallah – https://youtu.be/video_id_30",
  "Chemistry: Hydrocarbons – Oneshot: Hydrocarbons Complete Chapter | Mohit Tyagi – https://youtu.be/video_id_31",
  "Chemistry: Haloalkanes & Haloarenes – Oneshot: Haloalkanes One Shot | Unacademy JEE – https://youtu.be/video_id_32",
  "Chemistry: Alcohols, Phenols & Ethers – Oneshot: Alcohols Phenols One Shot | Apni Kaksha – https://youtu.be/video_id_33",
  "Chemistry: Aldehydes, Ketones & Carboxylic Acids – Oneshot: Aldehydes Ketones One Shot | JEE Wallah – https://youtu.be/video_id_34",
  "Chemistry: Amines – Oneshot: Amines Full Chapter | Aakash Digital – https://youtu.be/video_id_35",
  "Chemistry: Biomolecules – Oneshot: Biomolecules One Shot | Physics Galaxy – https://youtu.be/video_id_36",

  // Mathematics
  "Mathematics: Sets, Relations & Functions – Oneshot: Sets Relations Functions | Unacademy JEE – https://youtu.be/video_id_37",
  "Mathematics: Quadratic Equations – Oneshot: Quadratic Equations One Shot | Mohit Tyagi – https://youtu.be/video_id_38",
  "Mathematics: Matrices & Determinants – Oneshot: Matrices Determinants Full | Physics Wallah – https://youtu.be/video_id_39",
  "Mathematics: Complex Numbers – Oneshot: Complex Numbers One Shot | Apni Kaksha – https://youtu.be/video_id_40",
  "Mathematics: Binomial Theorem – Oneshot: Binomial Theorem Complete | JEE Wallah – https://youtu.be/video_id_41",
  "Mathematics: Sequence & Series – Oneshot: Sequence and Series One Shot | Aakash Digital – https://youtu.be/video_id_42",
  "Mathematics: Permutations & Combinations – Oneshot: P&C Full Chapter | Unacademy JEE – https://youtu.be/video_id_43",
  "Mathematics: Probability – Oneshot: Probability One Shot | Mohit Tyagi – https://youtu.be/video_id_44",
  "Mathematics: Trigonometry – Oneshot: Trigonometry Ratios & Equations | Physics Galaxy – https://youtu.be/video_id_45",
  "Mathematics: Straight Lines – Oneshot: Straight Lines One Shot | Physics Wallah – https://youtu.be/video_id_46",
  "Mathematics: Circles – Oneshot: Circles Complete Chapter | JEE Wallah – https://youtu.be/video_id_47",
  "Mathematics: Conic Sections – Oneshot: Parabola Ellipse Hyperbola | Unacademy JEE – https://youtu.be/video_id_48",
  "Mathematics: Limits, Continuity & Differentiability – Oneshot: LCD One Shot | Apni Kaksha – https://youtu.be/video_id_49",
  "Mathematics: Differentiation – Oneshot: Methods of Differentiation | Mohit Tyagi – https://youtu.be/video_id_50",
  "Mathematics: Application of Derivatives – Oneshot: AOD Full Chapter | Aakash Digital – https://youtu.be/video_id_51",
  "Mathematics: Indefinite Integration – Oneshot: Indefinite Integration One Shot | Physics Wallah – https://youtu.be/video_id_52",
  "Mathematics: Definite Integration – Oneshot: Definite Integration One Shot | Unacademy JEE – https://youtu.be/video_id_53",
  "Mathematics: Differential Equations – Oneshot: Differential Equations Complete | JEE Wallah – https://youtu.be/video_id_54",
  "Mathematics: Vector Algebra – Oneshot: Vectors One Shot | Physics Galaxy – https://youtu.be/video_id_55",
  "Mathematics: 3D Geometry – Oneshot: 3D Geometry Full Chapter | Mohit Tyagi – https://youtu.be/video_id_56"
];
